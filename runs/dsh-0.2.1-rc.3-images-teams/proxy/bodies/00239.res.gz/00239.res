data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342547460}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342575627}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differs!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342575751}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342575847}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342610956}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342611072}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page's world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342611177}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was mutated by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342611481}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342634321}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342634408}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342634470}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" e.g., at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342635725}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier controls calls `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342731259}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ctx.setParam('speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342731414}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"', ...)` or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342731482}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" others"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342731923}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", altering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342779240}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342779353}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342779430}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but only speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342779793}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342849583}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Engine world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342849698}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is created"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342849905}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342849945}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls mount;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342922816}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls maybe call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342922859}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" setParam('cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342923016}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes', true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342923067}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") or '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342992345}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"trails', no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342992436}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effect on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342992742}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics. Could call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124342992791}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `ctx"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343068611}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343068729}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actions.recast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343068770}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` on mount"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343069601}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with seed?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343137676}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm.\n\nOr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343137839}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the page's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343137913}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rendering loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343138315}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343198861}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343199019}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick` calls happen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343199071}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343199388}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343265339}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343265440}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343265497}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343266276}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reported tick 1200."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343427245}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hash?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343427437}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Page's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343427490}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343427782}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343451969}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343452089}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could compare page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343452349}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343452557}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to expected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343483795}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via evaluate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343483894}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also compare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343485209}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343486022}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343560603}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343560753}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me evaluate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343560804}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343561734}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343591869}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events, hash at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343591963}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343592218}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343592273}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343662691}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343662860}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=1859"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343663028}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"&gens=40&speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343663248}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=8`, and maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343776855}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stop before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343776958}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finishing?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343777044}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343777230}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CDP with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343801830}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343801923}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343801996}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" program"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343802143}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"matically run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343867756}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343867887}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343867955}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343868172}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343950524}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; evaluate."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343950667}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also compare `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343950799}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"window.__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124343951037}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIVARI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344025499}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UM__.getWorld"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344025576}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"().config` and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344025783}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344026067}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s do a quick CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344085132}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344085275}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at completion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344085379}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344086547}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also check whether"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344140151}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls mutate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344140278}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" params at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344140331}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount: inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344140804}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344235350}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount for set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344235438}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param calls. Search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344235601}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nActually likely culprit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344235846}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": atelier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344275523}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s controls,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344275629}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on mount, might call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344275878}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `ctx.setParam('"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344276100}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344348190}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ations', value)` from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344348281}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" its default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344348435}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (40),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344348479}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344413461}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ctx.setParam('m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344413555}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utation', "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344413787}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.06)` etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344413830}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344482553}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344482648}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But speed?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344483017}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no.\n\nWait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344483091}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": page's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344577684}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344577767}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 84"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344577880}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/215/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344577919}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20 vs expected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344601913}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 447/212"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344602051}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/47. Could be because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344602096}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344602392}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes happened"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344669231}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344669306}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344669464}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s query events."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344669928}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe page schedule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344739985}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differs due to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344740127}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344740188}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"interval` control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344740297}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" setParam"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344807057}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344807151}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount reset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344807242}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ting `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344807524}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"nextEventGen = generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344868992}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + interval`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344869681}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344869748}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344869786}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8, same."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344943773}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm.\n\nCould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344943899}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it be because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344944053}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page's engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124344944092}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345029010}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345029157}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345029462}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345029499}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" called while `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345096424}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345096497}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345096539}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inished`?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345096889}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no.\n\nCould world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345175279}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be accidentally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345175365}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modified"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345175417}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345175533}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er? Renderer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345240277}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only reads;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345240346}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345240434}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"drawTra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345240995}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ils` stores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345316873}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345316983}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" WeakMap. Controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345317028}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345317371}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345377720}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345377815}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345377892}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345378269}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls update reads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345442589}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345442932}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".config`;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345442980}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe no mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345443573}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345521003}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345521248}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345521323}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UI`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345522431}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345608054}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"CONTROLS.update(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345608194}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"orld, 16)` every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345608455}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame; if controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345608531}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345674250}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345674331}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" setParam"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345674403}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345674469}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"n't"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345745438}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAnother possibility: **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345745539}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345745764}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345745839}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345816743}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345816840}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345817001}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345817042}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" URL `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345895988}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed=1859` parsed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345896276}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345896516}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345896581}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345959446}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345959496}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differ due to engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345959685}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124345960418}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" version assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346043712}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".**"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346043889}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346043933}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346044469}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"shots/preview-le"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346091044}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ad.html` after engine changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346091138}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346091335}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346091411}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346151943}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" src/engine.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346152020}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Same.\n\nWait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346152175}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": our page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346152475}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346224720}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `?seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346224800}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=1859&gens="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346224962}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40&speed=8`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346225607}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346295145}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parseQuery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346295241}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", `seed`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346295440}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numeric"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346295491}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346369919}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gens` numeric 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346370014}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", `speed`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346370326}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8. Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346370364}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `ENG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346487834}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"INE.createWorld(query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346487895}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".config)`. Then controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346488049}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346488732}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could controls initialize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346519962}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `gener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346520031}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ations` to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346520083}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 and call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346520606}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `setParam"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346675089}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"('generations', "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346675164}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40)`?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346706216}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fine."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346706280}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346706318}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initialize `cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346706352}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes` toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346706388}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by calling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346706423}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `ctx.setParam('"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346749127}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"catastrophes', true)`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346749175}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? That res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346892479}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ets `next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346892564}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EventGen = generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346892622}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + interval` ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346892688}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346892741}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346892790}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0; same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346892837}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346892897}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initialize `interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346893001}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` by calling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346893067}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `setParam('interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346947150}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"', 8)`? That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346947273}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets nextEventGen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346947339}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346947404}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+8 = 8;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346999371}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same. All"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346999489}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346999706}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWhat about controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124346999772}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calling `ctx"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347070533}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347070651}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actions.recast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347070692}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347070936}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed)` on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347142398}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" init"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347142465}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347142524}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would reset world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347142714}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with same seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347197487}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347197620}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe screen wipe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347197745}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; still same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347198864}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nHmm,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347256608}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" difference might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347256704}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be because the page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347256821}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s **sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347257203}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ulation was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347371116}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347371172}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls mounted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347371338}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347371416}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" triggered"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347396676}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347396786}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**—"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347397029}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"no.\n\nMaybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347397109}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our CSS/re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347455589}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"nderer code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347455740}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" invokes `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347455791}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Math.random`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347456437}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347552257}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `Date"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347552356}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`, but not engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347552487}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347553204}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347616774}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347616912}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"events/hash mid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347616952}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347617479}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at end."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347678231}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also compare page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347678268}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347678456}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347678507}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g. gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347738621}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5 against"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347738727}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347738939}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347739015}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe divergence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347821104}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" begins early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347821255}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due to a control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347821340}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calling mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347821565}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347909837}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347909934}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let's debug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347910168}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with CDP"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347910810}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nUse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347952900}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347953014}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347953055}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=1859&gens="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124347953456}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40&auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348011586}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=0`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348011744}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to pause at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348011821}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348012597}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then evaluate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348074945}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348075167}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348075223}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348075619}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARIUM__.getWorld"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348143572}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"().config` and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348143753}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash.\n- Call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348143807}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `ENG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348144072}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"INE.runGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348211984}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348212175}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348212259}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" times via `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348212562}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"__VIVARI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348269910}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UM__.engine.runGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348270016}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(world)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348270246}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`, then hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348270305}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348343424}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ounts. Compare node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348343544}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348343857}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nThen check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348343904}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348423972}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348424045}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348424083}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already computed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348424262}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348494889}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount. This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348494986}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" isolates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348495206}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348495256}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s do."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348631786}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yl6xgc8ga3yi1rgofywd3uqu","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348631911}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348632185}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348632234}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348632884}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348632951}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348633021}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348633081}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348633122}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348633173}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348633210}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348633274}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348635031}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348635110}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348635167}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348635235}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348635294}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348635341}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348635403}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348635479}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348636925}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348636983}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348637036}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348637114}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348637215}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348637282}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348637340}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348637382}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348638618}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348638666}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348638710}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348638751}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348653277}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348653373}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348653450}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348653580}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348681629}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348681708}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348681768}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348681872}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348704593}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348704638}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348704871}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348704958}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348705059}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348705109}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348705403}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348705457}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348713319}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348713504}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348713586}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348714085}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348714735}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348714812}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348714907}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348714955}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348727558}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348727833}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348727892}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348728016}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348748446}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348748729}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348748781}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348749013}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348749445}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348749561}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348749674}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348749718}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348764285}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348764620}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348764684}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348764981}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348776604}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348776725}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348776819}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348777147}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348778794}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348778845}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348778990}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348779499}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348791430}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348791571}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348791649}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348791752}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348810601}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348810834}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348810922}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348811422}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348811574}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348811679}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348811846}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348811910}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348826202}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348826277}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348826349}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348826511}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348840418}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348840540}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348840699}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348840884}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348841424}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348841547}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348841655}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348841731}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348855308}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348855387}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348855480}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348855532}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348872248}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348872381}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348872451}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348872602}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348872714}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348872817}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348872905}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348873197}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348887299}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348887436}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348887483}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348887910}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348912273}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348912749}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348912801}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348912884}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348915980}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348916147}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348916220}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"auto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348916481}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348932822}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348933211}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348933302}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348933569}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348948647}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348948700}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348948746}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348949397}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348963827}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348963943}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348964127}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348964189}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348979717}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348979881}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348979934}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348980580}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348995757}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348996052}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348996123}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124348996201}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349009899}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349009978}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" base"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349010198}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349010288}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349031149}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349031281}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349031410}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349031499}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'''\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349031705}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(async"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349031912}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349031974}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349032150}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349050682}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349050935}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349050990}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349052440}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349062811}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349063096}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349063330}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349063401}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349082502}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349082556}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349082681}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349082731}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349114965}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349115050}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349115118}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349115228}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349127830}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349128009}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349128216}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349128303}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENG"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349145000}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349145138}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349145266}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349175688}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349175756}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349175816}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349175898}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349176003}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349176196}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349176271}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349176336}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349176385}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" before"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349198433}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349198606}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349198697}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349198840}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349213757}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349213839}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349214201}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349214263}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349214428}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349214497}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349214559}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349214683}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349229770}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349229868}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349229951}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349230355}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349268688}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349269032}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349269078}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349269706}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349278194}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349278240}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349278483}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349278548}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349278666}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349278750}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349278952}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349279019}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349292039}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349292106}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349292265}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" has"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349292683}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349313029}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349313167}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349313238}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349314055}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349321887}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349322139}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349322207}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349322365}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349342974}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349343028}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349343121}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349343313}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349343474}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349343620}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349343715}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349345961}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349359087}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349359160}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349359276}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349359987}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349360075}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" has"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349360143}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349360317}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349360501}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349387098}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349387241}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349387362}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349387453}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349387662}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349387789}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349387910}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349388096}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349432308}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349432390}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".parse"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349432578}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349432978}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349433054}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349433162}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349433235}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349433290}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349451790}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349451873}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349451976}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349452103}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"W"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349472171}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349472311}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349472440}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349472498}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349472698}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349472918}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349473073}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349473359}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349481101}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349481190}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"before"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349481276}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349482083}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"has"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349498471}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349498523}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349498564}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349498814}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349517406}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349517517}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349517568}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349517671}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349533489}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349533709}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349533771}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349533889}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349551493}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349551609}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349551744}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349552119}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349552307}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349552355}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349552551}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349552611}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349581537}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349581613}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'''\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349581674}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349581817}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(base"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349581995}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349582067}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349582314}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349582403}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349599622}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349599897}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349599962}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349600789}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"())."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349615458}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"decode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349615523}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"())\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349615635}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349615838}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349649050}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349649130}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349649323}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349649379}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349649765}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349649848}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349649937}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349649999}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349663328}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Compare"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349663409}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349663533}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-mounted"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349663589}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" world"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349690709}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349690820}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" against"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349690905}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349691400}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349794087}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21332,"ts_us":1793124349794197}}

data: {"id":"dd5cd8b44625bbeba195ea62bb5e5384","object":"chat.completion.chunk","created":1793124342,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":251164,"completion_tokens":1298,"total_tokens":252462,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":249088,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":930,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":21332,"ts_us":1793124349794340}}

data: [DONE]

