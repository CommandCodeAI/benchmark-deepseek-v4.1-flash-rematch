data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123950938674}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Modules"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123950954854}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are substantial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123950954955}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123950955278}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 124"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123950983524}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8 lines, design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123950983607}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123950983877}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2347, dashboard "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123950983925}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1642/734"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951039724}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Teams"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951040115}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951040159}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951041219}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSeed search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951127114}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" job seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951127217}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to have no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951127403}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951127730}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? `/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951152502}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tmp/seed-search.out`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951152611}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" empty maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951152820}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" job still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951153088}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running. Check job list/output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951232396}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also check atelier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951232472}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951232579}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to understand spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951232800}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line markup and how preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951368603}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951368659}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951368820}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design.css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951368980}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/controls relevant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951384557}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" classes quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951384615}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951384706}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fix missing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951385484}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparklines?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951494521}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The `sp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951494579}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ark:0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951494691}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` selector mismatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951494729}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": controls likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951594955}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951595008}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `<canvas class=\"ctl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951595154}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"__spark\">`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951595289}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951641384}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951641476}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_bzskaynye550ai8qdz73vpaf","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951641607}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951641845}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951644726}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951644942}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951645101}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951645209}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951656904}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951656957}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951657172}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951657387}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951674560}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951674666}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951674751}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951674929}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951693588}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951693739}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951693846}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951693957}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951708743}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951708865}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951708977}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951709124}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951709672}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951709758}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951709936}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951710057}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951728246}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951728404}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951728471}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951728578}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951754251}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951754382}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951754491}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951754562}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951774829}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951774974}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951775114}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951775182}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951812373}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951812439}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951812551}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951812679}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951840579}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951840688}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951840790}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951840844}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951868002}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951868126}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951868333}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951868398}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951870452}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951870579}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951870704}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951870793}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951918268}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951918425}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951918614}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ark"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951918668}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951953197}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951953473}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-label"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951953548}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123951953748}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"data"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952003659}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952003771}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952004117}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"role"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952004167}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952021870}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952021920}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ider"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952022023}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952022597}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952038019}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"role"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952038105}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952038192}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952038944}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"switch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952057931}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952057981}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952058029}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"instrument"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952058647}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952105760}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952105808}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952106033}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952106117}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952109897}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952110193}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952110242}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952110833}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952152218}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952152280}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952152409}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952152470}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952169375}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952169426}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952169516}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952169810}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952170018}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952170072}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952170354}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952170418}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" spark"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952185144}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"line"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952185214}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952185382}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" AR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952185439}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952217677}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" markup"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952217943}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952218012}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952218076}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_g8wrcm9420ftbou22q0ek6n8","type":"function","function":{"name":"job_output"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952308381}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952308654}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952308714}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"job"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952308749}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952308963}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952309007}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952309063}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952309383}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952325307}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952325358}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"528"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952325467}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952325861}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"833"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952344132}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952344226}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952344333}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"846"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952344435}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"91"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952383971}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952384036}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952384143}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952384258}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952402169}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952402244}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952402337}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952402439}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952432746}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952432796}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952432908}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952433577}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"_ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952452139}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952452258}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952452351}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952452451}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952546348}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13787,"ts_us":1793123952546406}}

data: {"id":"b8ddd8517fb16ea0f2aa0a25d4caf9ac","object":"chat.completion.chunk","created":1793123950,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":222282,"completion_tokens":326,"total_tokens":222608,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":219264,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":113,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":13787,"ts_us":1793123952546525}}

data: [DONE]

