data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737162336}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_duehz9r3jbt9apc4ghn0jkvi","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737162428}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737162467}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737181973}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737182071}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737182252}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737182359}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737200574}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737200624}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737200695}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737200918}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737217470}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737217702}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737217758}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737217858}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737233389}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737233547}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737233610}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737233857}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737233960}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737234165}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737234296}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737234433}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737252227}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737252365}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737252461}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737253560}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737272473}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737272648}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737272713}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737272795}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737273888}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737274016}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737274339}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737274409}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737284187}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737284396}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737284593}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737284677}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737304755}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737304870}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737304976}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737305644}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737319333}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737319409}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737319540}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737319852}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737326111}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737326194}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737326274}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737326348}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737336375}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737336558}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737336596}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737336865}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737352378}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737352466}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737352525}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737352616}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737435367}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6025,"ts_us":1793123737435687}}

data: {"id":"6bd15b36b30b049802a1731051480f60","object":"chat.completion.chunk","created":1793123736,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":188034,"completion_tokens":88,"total_tokens":188122,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":187776,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6025,"ts_us":1793123737435806}}

data: [DONE]

