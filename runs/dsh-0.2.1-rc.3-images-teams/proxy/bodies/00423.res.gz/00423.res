data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146236755}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146312066}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also check the \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146312139}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"no console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146312812}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" errors\" catch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146382022}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when page uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146382081}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" URL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146382244}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146382295}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146463698}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 etc.\n\nLet me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146463760}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliverable again and possibly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146463816}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" send Lead a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146465855}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nudge."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146682791}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also wait_"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146682856}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"agent could be used to wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146682925}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for Lead status"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146684782}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes. Let me use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146738807}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait_agent 60s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146738854}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146739955}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inactive ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146740016}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inactive ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146793602}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no turn), it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146793656}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returns; Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146793712}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is running probably"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146793764}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848412}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1csj7jc8bhx1mtz5kjx311kt","type":"function","function":{"name":"wait_agent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848467}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848509}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848561}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848610}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848650}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848688}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848726}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848865}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146848916}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"000"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146849240}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23021,"ts_us":1793126146849292}}

data: {"id":"17626a87e1e1af40f209c3c190df1445","object":"chat.completion.chunk","created":1793126146,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":326372,"completion_tokens":117,"total_tokens":326489,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":324864,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":75,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":23021,"ts_us":1793126146865524}}

data: [DONE]

