data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381390114}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381539314}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks well-built"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381539394}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with URL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381539432}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" params, debug hook"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596328}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. Let me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596387}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the browser preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596480}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite progress."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596528}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_wd4o2nnhk11w3179xam8yegb","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596596}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596642}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596686}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596728}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381596772}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381597816}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381597880}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381597993}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381608946}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381609042}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381609092}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381609246}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381621987}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381622066}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381622112}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381622220}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381622892}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381622944}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381622999}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381623271}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381641014}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381641069}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381641110}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381641237}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381659943}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381659998}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381660040}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381660088}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381660492}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381660547}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381660590}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381660635}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aux"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381671344}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381671404}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381671453}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381671493}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381690490}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381690552}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381690604}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381690647}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381691377}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381691435}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381691524}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381691617}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381722794}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381722847}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381722934}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381725081}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381743683}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381743751}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381743818}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381743881}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381774402}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381774469}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381774504}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" progress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381774554}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381838805}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10498,"ts_us":1793124381838880}}

data: {"id":"773b0cf9c13e60ed67607847d122fb39","object":"chat.completion.chunk","created":1793124381,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":237685,"completion_tokens":114,"total_tokens":237799,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":235008,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":21,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":10498,"ts_us":1793124381838994}}

data: [DONE]

