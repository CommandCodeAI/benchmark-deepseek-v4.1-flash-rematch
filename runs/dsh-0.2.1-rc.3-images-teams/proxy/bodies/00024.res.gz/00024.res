data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722353191}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722443399}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me now check the team"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722443478}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task board and my task,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722443536}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722536407}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" agents. Also I should message"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722536462}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722536502}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead about status"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722536603}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722599094}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-contract needs,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722599147}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but first do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722599182}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722599224}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" claim."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722662837}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_9mareuaxgl9xuzphxmfy9eqb","type":"function","function":{"name":"team_task_list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722662903}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722662973}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_qakeimlm8a79z78i0iopaino","type":"function","function":{"name":"list_agents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722664605}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":966,"ts_us":1793122722679283}}

data: {"id":"517a75e3218cfd441c733a70242487bf","object":"chat.completion.chunk","created":1793122722,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":22640,"completion_tokens":72,"total_tokens":22712,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":20096,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":36,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":966,"ts_us":1793122722679423}}

data: [DONE]

