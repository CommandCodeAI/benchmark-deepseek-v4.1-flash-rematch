data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123693880807}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123693961334}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I can see details"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123693961383}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n\nCensus issues"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123693961911}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1. **Y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694028201}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694028258}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label \"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694028372}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",000\" overlaps the vertical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694028425}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" axis title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694095472}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"INDIVID"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694095531}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UALS\"** — the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694095598}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rotated axis"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694098077}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" title at x="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694189442}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"11 crosses the tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694189496}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label \"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694191333}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",000\" (at x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694191383}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694243640}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"76"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694243700}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694243727}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694243871}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"INDIVIDUALS\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694300761}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rotated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694300846}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vertical at left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694300975}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694301035}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694408658}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1,000\" number."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694408725}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need move"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694408784}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" axis title further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694408818}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" left or label numbers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694492669}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closer."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694492751}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Left margin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694492810}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is 44:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694493004}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick numbers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694549908}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right-aligned at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694549988}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x0-8 ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694551105}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 36, width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694551160}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694622735}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"1,000\" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694622802}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694622855}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px → starts at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694622902}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 11 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694690015}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" collides with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694690074}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" title at x="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694690131}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"11. Fix: increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694690184}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" left margin to ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694743977}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"54, or put"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694744029}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694744085}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"INDIVID"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694744190}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UALS\" title vertically at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694797081}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x=10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694797128}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694797164}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numbers at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694797204}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x0-6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694875941}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694876021}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" margin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694876164}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 52. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694876207}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s set left margin 52"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694928585}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694928669}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x=10."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694928725}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Numbers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123694930862}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695020630}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695020673}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0-8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695022507}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695022543}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695079961}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"19"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695080008}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695080071}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ok gap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695080122}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695131728}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". **End labels overlap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695131780}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**: \"141"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695131828}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" and \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695131951}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"133\" and names"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695177851}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drawn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695177918}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stacked but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695178049}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" names collide with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695178113}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695250509}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695250567}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels: see"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695250624}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"HERB"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695250747}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVORA\" behind"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695446193}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"133\";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695446240}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"FL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695446279}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ORA\" behind"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695446317}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695514602}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\". The two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695514726}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-line labels overlap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695514810}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695514869}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" single-line labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695590985}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as planned"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695591071}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n3. **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695591131}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Event rotated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695591210}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels**: They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695640330}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695640379}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-to-top; good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695640434}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695640491}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695707330}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cramped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695707382}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" against"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695707487}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695707538}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695757717}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695757766}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" baseline offset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695757836}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695758439}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ibility okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695820880}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695821234}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cross"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695821314}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695821393}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695889780}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" halo makes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695889849}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them readable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695889908}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The pin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695889998}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695958734}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at top with a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695958783}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashed rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695958867}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123695958945}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696019663}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" think it's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696019734}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696019788}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696019836}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" improve: make label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696071832}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font slightly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696071885}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" larger (7.6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696071923}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), and offset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696071959}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696133103}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rule a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696133179}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bit more (translate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696133235}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696134514}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+4). Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696204421}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label text:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696204595}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"INCEND"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696204647}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IUM · G08"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696204686}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" — the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696268500}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"·"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696268806}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" is tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696268873}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n4. Label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696268938}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"S"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696317891}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ICCIT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696317942}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AS · G16\" appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696318049}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696318090}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696378704}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696378762}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s centered"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696378849}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696378891}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" roughly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696435022}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n5. **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696435072}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Legend**: nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696435109}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \"4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696435143}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" WE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696590988}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATHERS\" right aligned in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696591032}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ink"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696591068}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696591108}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", good.\n6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696656249}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". **Flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696656337}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curve**: The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696656374}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curve has nice wob"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696656421}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ble."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696718772}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696718849}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696718934}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"iv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696719250}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora/carniv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696774577}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696774645}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are very"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696774682}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low relative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696774722}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696829768}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696830136}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expected but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696830212}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" makes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696830290}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696888504}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696888552}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696888592}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123696889301}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" secondary scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697036011}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697036075}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says one chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697036251}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with three curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697036301}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; keep."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697082621}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" End"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697082689}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697082736}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697083921}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n8. **C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697182547}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arnivora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697182595}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697182672}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivora near"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697182754}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697228802}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697228942}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697228988}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to read. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697229035}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697291984}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" axis use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697292049}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sqrt? Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697292094}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" standard. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697292132}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697348904}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" subtle inset?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697348957}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697349022}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s honest ecological"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697349063}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697408564}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697408635}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dominates)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697408677}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697408754}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n9. **x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697456062}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697456129}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0\" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697456219}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"40\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697456299}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** — fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697507699}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Axis title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697507756}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" GENER"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697507798}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATION ✓.\n10."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697507840}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Bottom of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697567880}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697567945}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697567998}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curve drops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697568056}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 0 at ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697690721}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"G36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697690774}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then rises —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697690829}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" honest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697690978}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n11. The census"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697738640}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697738715}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697738760}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697738805}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" missing?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697911111}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" There is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697911158}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697911246}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faint line. ✓"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697911295}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n12. There's a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697987364}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697987425}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697987474}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123697987526}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698058048}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" label top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698058104}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; the axis"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698058141}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extends above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698058178}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698109182}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698109228}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n13. Weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698109265}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698109304}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698170549}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ules"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698170598}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698170704}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSummary crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698170747}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" next. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698250803}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me also check summary."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698250855}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_fsrxmiuibdzbivel6ross6w4","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698250910}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698250967}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251024}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251091}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251152}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251202}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251354}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251401}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251513}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251561}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251732}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251774}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251817}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251860}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251924}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698251978}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698252024}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698252087}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698259421}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698259465}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698259509}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698259548}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698279221}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698279431}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698279494}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698279536}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698297597}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698297664}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698297712}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698297758}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698298296}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698298344}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698298395}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698298444}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698320969}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698321036}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698321198}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698321249}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698344351}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698344433}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698344476}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698344524}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698367213}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698367270}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698367312}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698367361}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698396460}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698396515}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698396741}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698396793}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698396975}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698397027}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698397079}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698397126}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698402814}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698402887}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sum"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698402965}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698403006}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698411991}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698412040}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698412246}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698412296}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698492714}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11003,"ts_us":1793123698492783}}

data: {"id":"e6bba18f620a4d931cc9fec1fa7c47bd","object":"chat.completion.chunk","created":1793123693,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":162456,"completion_tokens":712,"total_tokens":163168,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":161280,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":620,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":11003,"ts_us":1793123698492867}}

data: [DONE]

