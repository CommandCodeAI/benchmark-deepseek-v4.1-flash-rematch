data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457295181}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457377725}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": 20/20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457377773}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PASS on final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457377808}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sha f820"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457448879}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"f20a;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457448946}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" static 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457449000}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/8 PASS ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457449074}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"313.7KB, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457500111}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9049 lines). Browser running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457500161}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457500196}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457500225}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"90s for browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457594379}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457594424}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use shorter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457594526}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sleeps to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457594562}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoid tool background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675086}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ing."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675154}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_k3neudpqza801x4cmyzh1uny","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675250}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675315}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675390}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675456}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675519}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675637}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675709}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675777}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675848}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675913}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457675964}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457676014}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457676065}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457676138}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457676215}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457677004}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457677045}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457677082}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457677129}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457678152}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457678226}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457678293}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457717078}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457717126}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457719480}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457719527}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457727548}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457727619}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457727683}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457727778}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457728340}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457728388}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457729089}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457729175}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457729505}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457729942}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457729984}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457730022}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457737389}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457737434}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457737938}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457738025}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457780730}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457780781}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457780844}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457780901}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457794641}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457794693}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457794760}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457794805}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457802915}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457802961}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457803002}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457803046}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457803593}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457803643}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457803694}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457804008}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457823944}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457824022}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FAIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457824089}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457824169}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457844992}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457845050}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ok"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457845098}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457849372}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457853015}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457853170}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457853323}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457853368}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457959190}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457959259}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457959321}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457959385}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457959668}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457959742}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457959810}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457959948}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457960033}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457960100}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457960166}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457960299}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457960390}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457960456}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457960517}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457961158}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457963991}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457964069}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457964610}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457964690}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"H"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457971054}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457971101}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457971146}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457971214}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457993936}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457994021}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457995516}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127457995584}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458004178}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458004242}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458005565}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458005622}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458016926}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458017011}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458017074}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458017136}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458017194}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458017254}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458017316}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458017451}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458039023}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458039074}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458039172}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458039265}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458055497}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458055563}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458055620}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458055699}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458055991}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458056034}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458056073}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458056643}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458072296}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458072368}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458072417}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458072513}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458245645}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458245701}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458245773}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458245863}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458271528}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458271575}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458271620}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458271659}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458272026}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458272115}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458272221}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" progress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458272317}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458313521}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26768,"ts_us":1793127458313574}}

data: {"id":"d7ef58a6a9bd029866abcf803d393f93","object":"chat.completion.chunk","created":1793127457,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":364146,"completion_tokens":229,"total_tokens":364375,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":363520,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":54,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":26768,"ts_us":1793127458314593}}

data: [DONE]

