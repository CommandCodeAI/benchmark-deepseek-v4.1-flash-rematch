data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733218618}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733407227}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" let me check shared tasks and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733407305}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" claim task-3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733407359}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then plan my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733474331}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verification harness.\n\nLet me list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733474431}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shared tasks."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733474511}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_du4oso42ncdv1y5xfuuqla9c","type":"function","function":{"name":"team_task_list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733474576}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733474640}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_84q2d0241v7u942f68epb627","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733474711}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733474768}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733474829}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475237}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475287}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475353}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475425}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475476}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475522}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475585}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475644}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" which"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475692}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475744}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475791}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475836}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733475961}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733476011}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733476060}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733476111}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733476154}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733476201}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733476241}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733476292}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733490839}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733490905}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733490967}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733491020}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733505927}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Applications"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733505972}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733506034}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733506086}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733621788}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733621882}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733621945}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733622006}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733636215}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" \\\"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733636280}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Applications"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733636334}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733636387}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733638008}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733638062}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733638111}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733638170}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733672389}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733672473}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733672536}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"OS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733672786}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733677212}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733677259}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733677327}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733677396}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733678264}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733678323}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733678411}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733678484}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733685840}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733685914}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733685974}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"eline"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733686031}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733705418}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733705541}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733705637}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733707658}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733707727}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733707812}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733707879}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733707945}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"short"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733773830}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733773918}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774091}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774153}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774222}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774477}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774542}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774603}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774670}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774755}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774828}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733774870}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733793943}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"it"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733794021}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733794071}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733794228}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1062,"ts_us":1793122733856297}}

data: {"id":"73c7691a9e47c35af0848a507e4e4d4c","object":"chat.completion.chunk","created":1793122733,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":21848,"completion_tokens":156,"total_tokens":22004,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":15616,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":24,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1062,"ts_us":1793122733856391}}

data: [DONE]

