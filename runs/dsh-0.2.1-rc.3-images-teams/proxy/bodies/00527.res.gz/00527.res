data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776733002}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776801604}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record looks excellent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776801675}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776801734}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 and event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776850210}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776850286}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then update visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776850346}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" notes to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776850402}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final build, regenerate report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776937008}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776937280}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no interim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776937322}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127776937363}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" message Lead,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777075630}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" complete"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777075700}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777075739}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_eys80n2wkjmv1d5x1vqn5iss","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777075831}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777075910}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777075959}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777076042}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777076158}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777109963}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777110050}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777110114}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777110274}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777115541}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777115798}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777115903}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777116529}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777129238}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777129343}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777129386}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777130023}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777138689}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777138737}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777138776}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777138820}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777153680}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777153998}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777154044}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777154089}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777175177}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777175223}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777175271}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777175767}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777181021}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777181091}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777181157}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777181206}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777181590}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777181886}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777181944}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777181994}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777182650}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777182707}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777182794}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777182839}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777193747}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777193851}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777193917}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777194362}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777195094}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777195140}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777195246}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777195292}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777196232}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777196374}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777196419}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777197018}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777197139}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777197467}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777197554}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777197707}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777198224}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777198345}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777198403}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777198889}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":31885,"ts_us":1793127777251733}}

data: {"id":"f553c024b339e7ff2ecfae70b628339f","object":"chat.completion.chunk","created":1793127776,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":371544,"completion_tokens":124,"total_tokens":371668,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":370304,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":34,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":31885,"ts_us":1793127777251819}}

data: [DONE]

