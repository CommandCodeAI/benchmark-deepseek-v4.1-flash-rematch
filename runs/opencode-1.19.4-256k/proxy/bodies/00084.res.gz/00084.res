data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976101910947}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976101911056}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aps 240/56 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976101911114}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102023973}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102024067}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1160 we saw final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102024131}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 216"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102024194}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/24, maximum"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102079112}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102079205}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102079330}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fine.\n- Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102079647}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy 26. good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102194067}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Plant initial coverage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102194125}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4436"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102194323}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n\nPotential issue event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102194423}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102274263}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102274630}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" encoded cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102274680}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102274737}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102342029}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102342086}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102342130}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102342184}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" duration detail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102426327}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says eight"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102426537}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations. Active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102426853}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102426920}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+7 inclusive. yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102528907}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Pl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102528949}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ague active until"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102528992}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen+3, four"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102529125}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102606427}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; detail. \n- Bloom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102606677}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" active until gen+6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102606949}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The detail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102607014}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't mention duration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102694420}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". fine.\n- The catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102694708}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102694752}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102694940}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 34"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102812763}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", duration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102812854}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max 8,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102812996}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no overlap.\n- Event \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102813180}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Pl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102925156}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ague\" kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102925230}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102925285}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976102925340}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators immediately. The detail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103021170}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103021237}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazers lost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103021363}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103021914}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n\n- Announce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103220865}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ment at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103220993}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n\n- The chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103221056}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" marks event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103221114}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103320041}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation after it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103320158}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s applied."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103320339}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103320449}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeline shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103417233}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" next disturbance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103417312}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" marker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103417368}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only if events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103417408}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enabled. good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103535514}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- The `latest`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103535608}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event in field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103535663}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note updates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103535691}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103691884}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n\n- The catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103691947}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103692020}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103692437}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103756220}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 active\" in heading"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103756335}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103756858}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- The event buttons"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103756936}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in apparatus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103841382}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103841620}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below fold at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103841660}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 768 core"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976103841732}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104017664}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible? The interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104017778}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104017965}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ends at 665"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104018077}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", toggles start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104070727}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 665; app body visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104070820}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 462"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104070882}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104070920}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104147873}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104148224}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"119"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104148275}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104149529}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ggles partially hidden. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104253547}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user can scroll. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104253688}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104253948}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104254016}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less tests maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104335590}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expect `speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104335660}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` or generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104335717}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not DOM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104335768}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104504635}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" relevant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104504712}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104504777}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104504844}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a \"reset\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104560431}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control (start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104560536}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104560627}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104560734}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104602975}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed) beyond report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104603077}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" buttons"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104603170}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The seed rer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104603251}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oll and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104686339}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104686410}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" conclude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104686601}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104686660}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" necessary."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104780382}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n\n- Could add \"Replay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104780456}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104780508}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104780558}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104872191}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104872386}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- If a user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104872579}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pauses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976104872702}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105014556}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wants to resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105014659}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105014763}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" button. good.\n\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105015057}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only way to see"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105060838}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105061007}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105061064}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105061613}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is Con"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105219550}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"clude; yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105219669}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- Dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105219844}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105220088}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" transition and charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105392689}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". yes.\n\n- The report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105392758}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can be extended"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105392798}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105392870}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow, event timeline has \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105439635}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Dist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105440394}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"urbance\" labels too small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105440734}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105442915}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105457306}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeline. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105457406}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good.\n\n- \"scheduled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105457819}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105457869}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" system\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105623416}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105623472}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105623569}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" disturbance marker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105623681}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105718221}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ollow dashed). good.\n\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105718355}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" All variables"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105718402}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" configured. yes.\n\n- Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105718454}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105743982}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intervals auto."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105744094}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yes.\n\nNow, maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105744196}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" implement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105744633}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105976787}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of reports"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105976914}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105976997}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no.\n\n- Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976105977234}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less API"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106019324}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returns config?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106019365}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It returns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106019484}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" summary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106019521}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with seed, generation, target, counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106085588}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", events, history. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106085777}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106085900}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106085983}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106152928}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utation, regrowth, catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106153031}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval) to reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106153321}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106153370}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" currently doesn't include mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106260264}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Rate/regrowth/c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106260404}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"atastropheEvery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106260580}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/en"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106260629}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"abledEvents. To prove reproducibility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106353719}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", including"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106354238}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config would be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106354780}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice. Add `config`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106354835}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to summary. Use:\n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106414396}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"```\nconfig:{m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106414538}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utationRate,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106414763}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"regrowth,cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106414825}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astropheEvery,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106503541}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enabledEvents:["},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106503628}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...], generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106503700}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106503957}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106607787}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"}\n```\nNeed target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106607907}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106608307}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" configured generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106608522}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106687882}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106688102}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" target. Good. Add to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106688464}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" summary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106688509}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also perhaps counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106818772}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106818870}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106818932}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106819079}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106925756}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106925906}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106926011}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976106926112}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107056457}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Add in sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107056592}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" summary."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107056796}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Also `window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107057040}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".Vivarium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107097452}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107097690}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS` maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107097771}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not needed. \n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107098455}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user may inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107221109}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless. Good.\n\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107221259}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107221388}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107222122}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107346212}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less handle `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107346254}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107346723}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`? not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107346773}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" relevant. \n- No render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107435773}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107435825}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n\n- Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107435870}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" support `on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107435924}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107544510}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` callback in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107544579}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless for charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107544655}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107544702}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needed. \n- We should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107757334}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe not use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107757403}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `Int"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107757536}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"l."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107757602}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NumberFormat` in sim."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107775925}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no.\n\n- The headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107775969}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run may mutate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107776200}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107776251}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"en"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107789956}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"abledEvents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107790121}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` array"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107791985}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reference from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107792032}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" options? `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107962465}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"this.enabledEvents ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107962526}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enabled.filter`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107962756}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976107962801}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087034}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Options"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087114}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed etc. \n- It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087186}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't require DOM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087248}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087291}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAdd config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087332}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087379}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" summary."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087428}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_tqp50oedqhc6b531hbzty3p8","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087481}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087526}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087590}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108087626}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147328}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147400}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147463}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147526}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147589}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147651}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147743}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147825}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147890}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108147957}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108148037}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108148098}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108158543}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108158627}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108158695}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108158827}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108169805}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108170113}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108170215}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108170289}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108171155}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108171427}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108171514}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108171991}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108212254}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108212501}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108212582}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108212701}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108223176}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108223255}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108223631}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108223687}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108240940}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108241211}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108241347}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108241402}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108242741}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108242946}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108243034}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108243121}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108270923}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108271131}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108271175}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108271286}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108287048}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108287189}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108287407}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108287484}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108305681}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108305764}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108305825}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108306012}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108306257}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108306381}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108306536}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108306591}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108347107}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108347192}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108347258}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108347328}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108361723}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108362049}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108362126}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108362598}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108386335}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108386420}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108386482}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108386551}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108386600}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108386860}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108386949}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108387024}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108421159}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108421224}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108421472}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108421550}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108464597}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108464671}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108465241}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108465328}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108465528}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108465852}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108466055}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108466129}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108543729}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108543801}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108543869}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108543932}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108587783}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108588130}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108588458}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108588514}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108589537}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108589790}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108589838}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108590011}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108623704}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108623795}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108623900}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108624178}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108658888}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108659173}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108659224}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108659586}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108659865}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108659938}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108659985}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108660609}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108790128}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108790185}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108790313}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108790392}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(),\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108795834}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108958426}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108958510}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108958580}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108958671}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108958726}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108958785}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108958889}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(),\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108980441}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108980500}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108980628}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108980729}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108981085}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108981198}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108981285}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108981363}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982110}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982195}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" };\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982255}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982306}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982347}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982406}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982471}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982525}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982570}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982626}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982672}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982719}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982820}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982896}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108982973}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983047}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983130}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983204}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983277}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983332}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983390}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983456}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983518}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983564}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983763}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983820}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108983930}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984004}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984064}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984136}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984191}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984247}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984294}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984362}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984440}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984508}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984610}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984674}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984761}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984845}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984905}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108984942}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108985027}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108985091}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108986975}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108987056}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mutation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108987171}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108987240}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108987310}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108987375}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108987453}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108987541}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108999137}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976108999175}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109003641}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109003706}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109028715}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109028874}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109028947}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109029326}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109029469}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109029521}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109029626}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109039029}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catastrophe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109066712}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Every"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109066846}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109066942}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109067175}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109098463}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109098527}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109098667}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109098769}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Every"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109099265}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109099359}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109099403}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" enabled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109107081}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109117895}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109117987}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109118036}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".en"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109118886}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"abled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109136672}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109136807}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109136963}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109137052}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109137452}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109137524}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109137642}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109137818}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109204205}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109204297}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109204421}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109204504}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109204657}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(),\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109204787}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109204832}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109204979}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109206807}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109207022}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109207711}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109207791}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109207992}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(),\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109208112}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109208181}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109208284}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109209788}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109209883}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109210030}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109210078}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109210277}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109210375}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109210476}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" };\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109225957}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226005}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226068}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226292}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226376}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226453}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226526}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226586}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226674}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226720}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226788}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109226859}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109227003}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109227056}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109227106}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109227173}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109227223}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109306179}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109306235}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109306337}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109307041}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109308255}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109308315}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109308463}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109308537}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109308671}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109308728}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109308781}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109308905}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sync"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109309624}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109309726}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109309792}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109309984}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109310534}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109310587}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109310655}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109310698}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109336366}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109336424}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109336468}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".indexOf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109336520}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109355985}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"script"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109356109}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109356158}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109356209}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109397008}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109397153}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109397251}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" end"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109397311}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109424050}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109424131}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IndexOf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109424209}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109424271}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"</"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109424316}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"script"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109424385}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109424438}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109424500}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109441737}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109441800}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109441840}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109441922}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109446639}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109446710}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109446757}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",end"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109446878}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109461482}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109461533}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109461597}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109461662}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109477818}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"yntax"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109477869}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ok"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109477991}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109478043}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109478393}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"catch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109478439}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109479066}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109479121}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109501221}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109501311}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109501386}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109501549}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109520195}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109520288}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109520363}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109520527}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2842,"ts_us":1792976109635568}}

data: {"id":"e554ce8f08aba84ae0c42feefb44a6ef","object":"chat.completion.chunk","created":1792976101,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":341688,"completion_tokens":1078,"total_tokens":342766,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":340736,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":722,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2842,"ts_us":1792976109635693}}

data: [DONE]

