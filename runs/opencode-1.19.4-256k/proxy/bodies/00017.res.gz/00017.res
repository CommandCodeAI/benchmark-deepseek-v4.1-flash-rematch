data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788103131}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788103669}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators cap at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788103761}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 120 too easily"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788160702}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788160785}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788160946}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 420"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788161508}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788243828}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788243936}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good. Need lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788248023}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps and reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788248114}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788309718}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788309803}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/impact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788310257}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We need classic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788310302}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788394094}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788394298}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reasonable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788397569}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population ranges"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788397679}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's aim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788547676}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788547755}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788547817}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788547969}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predators 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788559129}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788559465}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788559506}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788559669}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788629856}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788629904}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harder"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788630014}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788630524}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788711221}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788711291}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 43 from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788711457}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 17"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788711552}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; then rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788801231}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"overs to 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788801289}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Limit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788801401}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788802156}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788969172}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60 could stop at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788969237}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60. Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788969339}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788970031}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe higher"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788980437}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788980560}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788980616}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974788981260}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789028485}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789028646}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 188"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789028723}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789028933}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789106225}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789106439}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"120 predators. With"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789106547}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60 predators,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789106748}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey may stabilize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789179362}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789179472}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789179703}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789180424}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789269486}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789269559}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789269629}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789269689}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 17."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789336931}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789337038}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789337155}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 70."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789337235}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789416183}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y cap maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789416284}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789416399}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce PL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789416616}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ANT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789498482}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789498549}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ENERGY? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789498606}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" present"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789498693}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789633585}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789633664}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789633716}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789633766}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need see"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789743383}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789743505}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789743545}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300/64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789747607}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Increase predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789764639}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789764753}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789764854}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bit? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789764962}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789851668}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"104; mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789851754}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evolved"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789851824}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to ~91"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789851886}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789927714}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lower threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789927828}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = more reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789927916}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") because selection"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974789927993}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" favors"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790043438}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790043498}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790043552}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790043602}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hit."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790101944}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790102015}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790102220}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" force. Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790102336}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y genes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790236365}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790236446}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790236521}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790236573}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_okabucscst1r97nfef87ko2k","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790236637}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790237024}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790237106}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790237176}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790265707}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790266142}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790266229}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790266363}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790267540}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790267610}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790267783}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790268316}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790273710}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790273957}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790274036}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790274263}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790298314}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790298404}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790298479}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790298539}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790298610}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790298697}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790298763}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790298832}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790326167}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790326308}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790326380}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790326588}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790335951}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790336106}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790336192}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790336343}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790336690}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790336759}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790336876}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790337120}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790354191}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790354404}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790354613}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790354711}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790366502}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790366674}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790366769}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790367402}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790367807}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790367893}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790368014}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790368089}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790392680}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790392753}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790392932}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790392995}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790414735}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790414969}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790415056}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790415145}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790415648}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790415700}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790415925}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790415995}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790433825}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790433886}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790433939}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790434711}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790481245}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790481361}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790481510}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790481639}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790483579}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790483807}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790483947}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790484219}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790484527}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790484575}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790484786}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790484882}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790491719}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790491777}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790491840}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790492501}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790521235}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790521339}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PRE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790521425}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790521499}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790521632}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790521813}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790521863}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790522029}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"420"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790534610}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790534809}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790535049}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790535357}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790548046}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790548110}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790548167}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790548394}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790548450}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790548524}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790548618}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790548729}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790572266}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790572349}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790572444}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PRE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790572602}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790586681}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790586772}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790586840}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790587155}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790587498}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790587544}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790587718}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790587972}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790617609}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790617672}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790617750}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790617834}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790650288}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790650360}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790650448}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790650504}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790650576}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790650652}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790650742}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790650806}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790656307}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790656355}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790656634}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790656720}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790682079}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790682150}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790682271}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790682378}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790682515}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790682603}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790682923}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790682991}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790712366}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790712438}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790712534}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790712616}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790725810}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790725941}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790726056}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790726168}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790740937}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790740998}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790741050}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790741829}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790810001}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790810097}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790810212}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1755,"ts_us":1792974790820667}}

data: {"id":"f0e7dd416909315b590cb2d01da2e6f6","object":"chat.completion.chunk","created":1792974787,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":148704,"completion_tokens":408,"total_tokens":149112,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":146944,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":229,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1755,"ts_us":1792974790820845}}

data: [DONE]

