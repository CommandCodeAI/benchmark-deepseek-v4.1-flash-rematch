data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974729967675}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974729967874}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974729967931}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less with playwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730039276}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly by loading"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730039366}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file and calling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730039421}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless. Need require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730039632}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playwright path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730134655}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's make small node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730134927}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730135159}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_axf48vg7wzrwoljlwe3ll8y4","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730141323}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730141419}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730141486}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730141547}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730141605}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730143670}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730143913}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730144094}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730145120}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730178496}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730178565}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730178672}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730179245}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730206428}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730206643}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730206721}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730206795}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730216600}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730216676}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730216816}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730216883}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730217501}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730218345}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730218429}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730219890}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730240443}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730240527}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730240592}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730240709}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730326517}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730326807}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730326863}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730327026}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730327640}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730327912}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730327980}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730328113}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730339120}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730339167}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730339235}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(async"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730339289}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730341788}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730341846}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730342006}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730342322}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730342512}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730342995}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730343050}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730343094}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730359849}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730359975}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"unch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730360025}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730360076}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730365378}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730365467}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730365559}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730366372}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730366860}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730366971}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730367405}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730367570}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730379373}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730379454}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730379557}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730379750}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730438170}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"viewport"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730438218}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730438316}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730438397}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730438465}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730438526}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730438572}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730438649}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730483302}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730483442}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730483488}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730483950}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730590236}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730590319}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730590378}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730590434}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730590534}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730590591}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730590639}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730590670}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730592156}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730592362}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730592536}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730593010}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730599274}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730599338}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730599451}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730599500}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730600304}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730600349}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730600486}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730600545}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730601309}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730601384}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730601452}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730601535}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730602326}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730602394}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"())"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730602502}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730603292}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730604709}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730604858}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730605027}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730605101}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730641582}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730641682}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730642076}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730642465}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730649398}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730649512}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730649718}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730650100}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730650213}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730650394}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730650486}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730650563}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730657632}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730657859}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730657933}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730658630}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730740693}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730740808}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730740877}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730740943}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741008}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741090}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741316}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741377}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741438}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741515}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741647}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741719}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730741813}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730742013}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730742086}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730742153}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730782585}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730782799}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730782881}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730783010}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730839905}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730839974}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730840034}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730840919}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730840993}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730841053}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730841913}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730841985}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730854752}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730854810}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730854851}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730855000}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730859758}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730859836}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730859900}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730860034}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730861492}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730861712}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730862018}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730862112}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730863692}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730863770}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730863911}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730864110}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730870899}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730870972}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730871074}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730871190}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730871295}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730871420}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730871545}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730871610}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730878566}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730878614}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730878785}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"500"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730879095}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730880301}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730880411}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" res"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730880587}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730881260}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730881315}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730881443}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730881510}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730881610}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730905756}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730905809}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730905854}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"  "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730905908}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730919121}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730919413}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730919468}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730919650}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"  "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730919902}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730919951}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730920163}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974730920211}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731027376}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731027547}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"188"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731027626}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731027961}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731081688}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"271"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731081726}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731081840}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731082591}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"314"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731101992}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731102110}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731102185}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731103276}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731109904}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731110003}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731110598}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731110828}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"    "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731124396}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731124568}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731124622}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731124675}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731125233}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731125347}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731125398}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731125553}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731126600}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731126813}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731126860}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731127167}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731160387}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731160452}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731160573}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731160610}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731178846}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"180"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731179014}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731179083}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731179197}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731213665}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731213771}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731213859}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731214047}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731238792}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731238896}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731239114}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731239205}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731258326}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731258959}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731259054}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731259607}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731289916}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731290008}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731290081}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Every"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731290155}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731290613}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"34"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731290699}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731290775}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"    "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731290850}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731358213}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731358354}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731358804}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731358871}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731359012}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731359090}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731359940}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731359998}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731394204}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731394345}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731394477}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731394699}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"    "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731445796}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731445890}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731445982}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731446074}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731448089}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731448223}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731448318}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731449356}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"999"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731496367}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"99"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731496456}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731496527}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731496638}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731571006}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731571320}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"999"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731571383}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"99"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731571489}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731571542}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731571588}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731572340}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731572406}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"999"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731572449}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"99"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731572510}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731572604}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"    "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731572683}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731572727}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731573461}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731573524}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731573668}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731588914}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731588985}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731589038}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731589131}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731610380}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731610442}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731610589}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731610644}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731611608}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731611685}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731611827}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731611907}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731642052}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731642132}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731642190}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"    "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731642234}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731662411}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731662463}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731662518}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731662845}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731663056}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731663118}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731663249}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731663299}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731689373}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731689419}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731689474}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731689567}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731689613}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731689679}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731689733}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731689812}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731707550}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731707640}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731707700}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731707758}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731738786}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731738836}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731738886}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731738990}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731759305}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731759663}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731759750}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731760503}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731760548}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731760631}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731760699}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731760748}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731788894}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731788960}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731789011}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731789114}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731845273}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731845390}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731845460}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731846558}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731846611}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731846659}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731846715}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731846754}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731846844}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731846946}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731847031}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731847097}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731850436}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731850501}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731850593}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731850648}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]);"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731851406}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731851457}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"    "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731851518}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731851639}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731873831}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731873957}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731874073}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731874143}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731897494}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731897557}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731898164}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731898218}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731898277}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731898327}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731898388}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731898428}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731921378}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731921520}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731921598}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731921731}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731944035}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731944121}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731944225}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731945073}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731945246}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731945293}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731945400}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731945455}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731957411}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731957471}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731957585}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731957981}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731977820}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731977949}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731978258}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731978365}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731978546}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731978698}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731978787}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974731979011}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732004891}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732005015}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732005129}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"es"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732005205}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732018103}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732018206}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732018310}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732018998}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732055629}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732055845}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732055919}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732056271}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732057462}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732057607}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732057712}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732058114}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732077990}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732078054}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732078176}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"es"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732078515}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732097200}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732097346}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732097427}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732097508}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732098026}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732098141}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732098184}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732098373}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732116844}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732116996}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732117073}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732117171}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732139075}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732139141}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732139193}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"  "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732139247}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732139309}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"  "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732139391}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732139450}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732139500}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732160268}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732160349}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732160482}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732160593}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732175711}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732175832}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732175902}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(res"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732175998}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732176425}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732176588}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732176636}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732177058}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732193527}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732193612}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732193712}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732194597}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732213723}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732213771}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732214084}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732218086}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732218357}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".close"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732218415}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732218475}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732218586}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732234096}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732234234}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732234407}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732234505}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732256296}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732256354}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732256448}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732256499}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732257675}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732257768}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732257863}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732257971}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732346637}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732346750}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732346813}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1725,"ts_us":1792974732348203}}

data: {"id":"4418ec42a35bd5aac094d3bb20c532ef","object":"chat.completion.chunk","created":1792974729,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":134642,"completion_tokens":540,"total_tokens":135182,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":126848,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":28,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1725,"ts_us":1792974732348655}}

data: [DONE]

