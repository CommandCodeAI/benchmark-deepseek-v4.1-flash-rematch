data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183405786}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183405879}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world good. Need panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183405920}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fit after reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183520951}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Rerun layout summary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183520994}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183521067}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_v8srfohaf0tkr58hph1n745n","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183521137}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183521192}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183521274}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183521362}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183521414}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183521457}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183534897}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183534998}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183535095}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183535168}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183535271}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183535334}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183541177}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183553868}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ayout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183553918}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183553960}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183553998}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183554189}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183554251}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183554345}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183554408}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183628744}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183629001}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ayout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183629091}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183629194}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183629877}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183630001}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183630116}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183630193}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183651228}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183651315}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183651407}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183651578}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183653289}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183653352}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VIEW"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183653509}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PORT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183653562}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183661636}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183661730}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Body"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183661876}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183661952}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scroll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183700957}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"H"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183701018}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183701067}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"client"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183701128}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"H"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183749790}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183749880}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183749999}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183750058}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183816002}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183816087}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183816178}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ips"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183816360}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183853515}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Failed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183853610}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183853708}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183853785}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183869346}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183869456}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183869547}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183869645}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183869936}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ayout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183870030}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183870133}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183870214}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183879366}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183879472}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183879605}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183879759}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183982001}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2016,"ts_us":1792975183982079}}

data: {"id":"1948ea36d2b503bf64dd754b475168ad","object":"chat.completion.chunk","created":1792975183,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":228451,"completion_tokens":115,"total_tokens":228566,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":224256,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":17,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2016,"ts_us":1792975183982192}}

data: [DONE]

