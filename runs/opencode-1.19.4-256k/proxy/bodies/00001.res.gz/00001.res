data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851782817}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851782911}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851783790}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generate a title ≤"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851843278}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"50 chars"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851843350}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851843393}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same language ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851843445}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"English). Focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851907625}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851907696}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" topic: ecosystem simulation single"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851907820}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-file HTML with evolution"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851907920}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851993676}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes, dashboard. Title like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851993763}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Evolving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851993952}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem simulation in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973851994164}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index.html\" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973852090058}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"44 chars)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973852090163}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973852090274}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973852090930}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Evolving ecosystem simulation in index","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792973852102364}}

data: {"id":"6fd87961983e52af987543a9bff8b2fe","object":"chat.completion.chunk","created":1792973851,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":".html","role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":979,"completion_tokens":57,"total_tokens":1036,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":896,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":49,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1050,"ts_us":1792973852102777}}

data: [DONE]

