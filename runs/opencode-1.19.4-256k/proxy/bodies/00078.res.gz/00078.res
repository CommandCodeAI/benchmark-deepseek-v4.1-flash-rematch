data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012198283}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012198390}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tesseract. Could use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012198436}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" OCR via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012289313}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012289446}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? no."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012289605}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fine.\n\nMaybe we can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012289735}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use `img"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012370832}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2txt` if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012371005}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" libcaca installed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012371129}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012371414}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_h22aevnmk3slj813fch4dw2m","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012396756}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012396929}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012397082}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012397190}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012420813}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012420894}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012421005}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"which"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012421066}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" j"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012461474}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012461579}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012461798}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012462329}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cii"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012497461}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012497531}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-con"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012497588}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012497770}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" img"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012519063}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012519141}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012519191}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012519303}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"afa"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012540477}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012540569}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iu"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012540769}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" kit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012540841}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ty"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012541299}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012541519}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012542006}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012542051}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012559317}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012559381}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012559480}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012559734}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012577015}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012577062}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012577120}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012577180}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012577281}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012577337}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012577422}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012577578}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012592421}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012592525}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012592576}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012592981}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012617159}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012617270}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012617322}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012618274}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012618450}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012618577}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012618671}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012618773}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012649259}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012649389}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012649565}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012649624}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3061,"ts_us":1792976012717977}}

data: {"id":"dba43eea4d8155f7bb385ba86e1abc99","object":"chat.completion.chunk","created":1792976012,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":333176,"completion_tokens":116,"total_tokens":333292,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":330368,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":32,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3061,"ts_us":1792976012718263}}

data: [DONE]

