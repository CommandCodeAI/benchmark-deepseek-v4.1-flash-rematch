data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738377901}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738377998}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ulation too stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738378038}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": prey hits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738438979}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738439054}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"260, predators 46"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738439104}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", flora increases"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738439176}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738509856}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5900, no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738510049}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738510144}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738510731}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oring. Need tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738591395}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738591457}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738591599}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Initial prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738591681}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738659105}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"86 already too many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738659347}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738659464}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738659739}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plant reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738740504}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth too high /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738740548}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738740605}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too beneficial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738740647}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738804655}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738804840}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too easy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738804986}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need more oscillation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738805019}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", variable populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738879497}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", possibly ext"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738879550}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inctions. Requirements"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738881444}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974738881543}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739123051}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evolving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739123149}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; should show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739123210}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739123272}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739123900}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nInitial prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739123987}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739124056}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap ~260"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739124132}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739124206}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739124277}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effect not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739124365}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739124437}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limit because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739240532}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739240583}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739240750}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739241018}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739289357}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth and/or increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739289426}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739289467}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needs/p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739289524}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"redation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739339164}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739339307}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 46 too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739339369}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739339413}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739409874}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739409983}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739410471}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739410519}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739483603}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739483720}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739484042}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range. Also initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739484149}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739574913}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count 340"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739574975}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0-400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739575159}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0. Final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739575214}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739641944}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (all filled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739642013}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). We need allow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739642132}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739642239}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739762579}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keep it in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739762636}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check.\n\nPrey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739762711}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739762791}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739858194}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739858251}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739858356}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974739858416}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740016725}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740016811}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reach cap. Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740017874}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740017929}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not suppressing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740054623}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740054674}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740055940}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740056008}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but predator energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740079863}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740079936}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740080080}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 46 they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740080137}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill ~1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740154695}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740155005}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740155058}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740155101}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740227997}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740228113}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740228226}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 180,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740228290}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pred cap 32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740290433}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740290509}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they sit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740290666}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740290716}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740378032}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need ecological"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740378111}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740378248}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strength.\n\nFood"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740378521}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740492838}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey: each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740492921}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey consumes "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740492962}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.085 food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740493021}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740539929}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; 260 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740539978}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740540083}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 22 food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740540161}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen. Regrowth final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740607007}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740607383}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740607457}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5600 colonies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740607607}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" & mass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740689305}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740689367}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high; growth per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740689442}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen ~?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740689525}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" averages could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740775950}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be 20+."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740776071}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740776139}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740776180}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap. Lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740913746}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740913823}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth base"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740913881}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740913934}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" say, 0.003"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740929347}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 (from ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740929433}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0058) with default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740929494}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .9 =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974740929550}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .003"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741011018}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"15."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741011096}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741011159}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" supports maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741011219}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 110 prey. Could create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741090517}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" oscillations. Increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741090579}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741090629}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AT_R"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741090681}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATE maybe ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741178228}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"11. Predator reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741178299}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe too easy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741178358}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741178413}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"46. Lower predator kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741261065}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gain 48"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741261301}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and/or reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741261354}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741262758}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741349644}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" influences."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741349721}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Initial predator count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741349786}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741349846}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741474878}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741474974}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741475095}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" immediate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741478891}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction. We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741532373}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can test.\n\nGoal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741532461}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741532552}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ranges"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741532622}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741767874}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741767944}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0-450"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741768601}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, prey 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741768660}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-180, predators 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741788612}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-35"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741788685}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741788747}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles and extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741788803}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741797474}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741798143}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741798211}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some seed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741798268}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741867166}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741867259}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741867333}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with dips"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741867388}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741943119}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes should cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741943202}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" noticeable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741943367}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974741943445}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742016816}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recovery. Currently plague"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742016883}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742017001}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 38%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742017075}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742160098}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" immediately back to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742160162}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742160228}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742160280}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity.\n\nLet's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742172711}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742172933}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742172996}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742175661}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" base 0.003"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742247803}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4, reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742247871}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742247929}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742248140}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742356766}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- EAT_R"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742357073}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATE 0.10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742357131}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742357189}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy 43 =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742416883}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742416956}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4.3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742417083}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gross"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742417159}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742669358}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" net ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742669455}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3.1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742669601}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742669780}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Prey reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742771088}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742771207}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742771329}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742771377}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742805002}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 55"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742805074}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%; juvenile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742805131}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742805186}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742832635}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742832959}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742833021}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742833115}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742850336}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suppress"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742850389}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742850615}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crossing."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742850699}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742891853}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator cap maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742891920}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742892099}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974742892217}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743001549}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator starting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743001682}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743001790}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"17"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743001880}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743044242}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743044371}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill gain "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743044516}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"54"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743044600}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743130217}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" metab perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743130264}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.5; threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743130715}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743130773}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"104.\n- Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743207391}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y initial "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743207670}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"80."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743207843}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Could make plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743207944}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743302950}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth variable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743303051}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spatially"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743303177}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743303275}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with a JS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743367246}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" copy?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743367326}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743367382}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can temporarily edit constants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743369127}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in file and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743432968}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rerun. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743433300}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s fine. Use multiple edits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743433363}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743433490}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower base reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743514518}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth drastically "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743514569}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.0028"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743514713}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743514838}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743602739}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slightly "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743602974}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743603059}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", cap prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743603180}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 220 and predator "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743685340}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"36. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743685433}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator initial "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743685589}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"17 and cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743689100}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743760239}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Run."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743760322}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_qz84c7gugfculj1gxc73a8pt","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743760396}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743760500}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743782761}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743782822}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743782940}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783027}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783105}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783180}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783242}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783400}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783471}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783543}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783677}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743783732}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743800405}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743800485}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743800589}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743800803}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743817609}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743817850}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743817935}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743818188}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743834669}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743834753}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743834850}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743834938}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743835129}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743835425}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743835509}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743839603}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743856705}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743856782}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743857044}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743857139}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743874097}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743874168}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743874320}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743874387}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743874857}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743874949}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743875777}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743875869}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963117}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963219}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963310}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963383}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963515}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963595}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963661}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963723}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963786}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963865}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963930}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743963995}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743964059}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743964122}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743964180}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743964218}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743967835}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743967934}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743968083}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743968161}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743975201}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743975276}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743975344}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743975406}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743975700}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743976470}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743976656}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743976737}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743984581}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743984790}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743984880}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974743984953}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744043199}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744043329}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744043396}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744043449}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744043714}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744043919}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744043992}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744044101}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PRE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744067025}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744067150}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744067226}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744067402}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744068944}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744069137}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"260"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744069272}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744069387}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744070591}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744070723}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744070888}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744070972}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744072911}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744073035}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744073106}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744073166}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744083287}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"46"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744083410}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744083524}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744083600}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744083838}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744084020}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744084067}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744084179}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744144490}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744144543}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744144678}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744144761}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744145940}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"085"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744146009}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744146061}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744146142}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744146770}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744146894}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ANT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744146964}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744147136}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744147922}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744148008}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744148101}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744148148}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744165721}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744165832}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744165925}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744166019}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744166110}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PRE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744166177}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744166299}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744166357}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744182716}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744182836}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744182896}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"220"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744183004}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744202668}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744202952}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744203067}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744203360}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744203453}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744203523}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744203630}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744203700}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744211066}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744211129}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"36"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744211248}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744211394}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744231515}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744231590}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744231740}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744231805}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744231848}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744231988}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744232030}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744232087}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744249290}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744249393}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744249441}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744249608}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744266396}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744266607}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744267785}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ANT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744267842}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744267917}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744267996}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744268042}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744268108}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744289759}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744289857}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744289920}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744290020}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744311066}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744311148}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744311289}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744311376}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744348297}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" growth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744348371}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744348441}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744348495}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744351944}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744352178}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"005"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744352282}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744352401}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744357783}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744357971}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744358046}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744358102}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744379104}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744379371}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" weather"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744379482}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744379620}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744380041}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744380102}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744380167}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" growth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744380391}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744421048}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744421110}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744421156}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744421212}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"003"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744426921}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744427030}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744427126}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744427260}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744453523}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744453609}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744453677}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744453739}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" weather"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744455843}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744455944}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744456030}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744456114}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744456679}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744457266}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744457354}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744457436}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744553495}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744553574}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744553639}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744553701}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563075}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563181}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563246}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563377}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563449}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563513}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"15"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563575}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563675}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563736}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563800}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563860}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744563948}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744564309}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744564377}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744564440}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744564503}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744565847}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744565922}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744565981}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744566045}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744575565}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744575643}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744575708}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744575771}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"17"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744575830}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744575889}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744575947}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744576005}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744591154}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744591233}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744591303}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744591370}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744610596}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744610668}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744610729}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744610788}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744610854}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744610915}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744610975}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744611036}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744672660}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744672930}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744673017}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744673465}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744673544}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744673609}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744673674}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744674708}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2689,"ts_us":1792974744714653}}

data: {"id":"55e9c3c889a356f4e3c090db102815a3","object":"chat.completion.chunk","created":1792974738,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":137405,"completion_tokens":951,"total_tokens":138356,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":134528,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":657,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2689,"ts_us":1792974744714903}}

data: [DONE]

