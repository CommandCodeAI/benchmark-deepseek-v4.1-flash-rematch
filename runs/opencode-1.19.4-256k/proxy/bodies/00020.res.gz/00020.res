data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829165961}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829166060}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations below caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829166091}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and dynamic-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829235539}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Some predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829235932}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinctions on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829236084}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds 42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829236146}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829332029}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 188"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829332144}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829332347}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829332652}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 41; "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829849326}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9001 zero"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829849393}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good. Default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829849448}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 1887:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829849534}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey 86"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829852966}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"→"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829853967}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"157 slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829854008}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth, predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829854077}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 17→41."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829855729}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829855781}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829855825}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modest change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829855895}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829857035}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cause dips"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829857097}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Trait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829857766}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829857832}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mild. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829860253}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829860335}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829860407}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe 220"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829860480}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829861896}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829861967}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829862018}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829862092}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen34 at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829879179}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829879253}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s=5."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829879321}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7s. End at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829879456}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"180 "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829995911}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30s. Dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829995989}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829996045}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later.\n\nNeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974829996117}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830049431}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dramatic cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830049498}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": current prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830049644}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gradually rises"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830049933}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 80"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830126252}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830127183}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"160 with blooms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830127235}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830127290}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"plagues"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830214472}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830214549}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830214597}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" classic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830214662}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator-p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830303633}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rey oscillation. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830303729}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase interaction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830303837}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strength"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830304103}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by making"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830376454}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830376516}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830376640}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" easier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830377038}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" & predators more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830458181}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" efficient"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830458246}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830458301}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830458377}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density regulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830532462}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Yet risk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830532671}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830532823}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". User wants evolving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830532897}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830620931}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; stable coexistence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830620983}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is okay,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830621059}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830621131}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes. Tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830699500}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"it drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830699663}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830699871}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830699925}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830848349}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/sp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830848431}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"read changes. With default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830848507}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830848635}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3.8% and "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830894581}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"180 gens, changes are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830894659}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830894815}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974830895534}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" axes dynamic."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831073991}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could set mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831074085}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831074153}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6% default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831074227}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to produce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831131029}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" larger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831131110}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drift. Is that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831131168}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too high?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831131220}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not crazy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831170223}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". And maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831170300}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" selection effects show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831170361}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831170466}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831270592}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6.5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831270793}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831271093}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831271161}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also maybe catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831312894}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831313075}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831313374}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831314145}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" selection. Could make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831392883}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default preset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831393211}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831393324}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dramatic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831393365}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by adjusting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831479117}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831479167}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831479237}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831479306}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831574938}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831575003}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 180 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831575118}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless quick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831575285}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine.\n\nA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831639529}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" concern: using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831639708}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831640528}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831640585}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831734290}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sampling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831734371}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831734428}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould produce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831734485}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stronger cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831825926}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by letting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831825997}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831826058}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831826140}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831938021}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831938298}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831938591}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strongly reactive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974831938646}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Increase prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832032746}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832032825}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832033187}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lower density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832033352}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832113097}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832113266}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832113626}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832113697}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832195881}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This ampl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832196180}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifies oscillations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832196224}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832196743}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832297007}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". With crowding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832297066}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832297121}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832297178}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keep under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832424942}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps. \n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832424996}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Set prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832425030}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 260"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832425127}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832492365}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"52 and density feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832492475}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832492796}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832493066}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832535527}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster, predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832536425}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832536480}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster; cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832536535}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832615574}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" back"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832615795}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"stop. \n- Set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832615950}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832616149}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832697160}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"110?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832697286}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Current "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832697333}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"86. \n- Under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832697657}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832762504}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback, prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832762620}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 157"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832762776}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832763068}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hunters"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832871118}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 41 near caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832871232}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ratings"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832871331}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832871380}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832934408}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/0.79"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832934511}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832934795}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974832935069}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" near"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833015645}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap because density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833015693}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833015801}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strong. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833015999}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833092232}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833092281}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"70 to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833092319}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" allow more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833092516}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833167851}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833168031}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"260. Test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833168854}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833168933}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators may reach"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833258921}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60, prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833258989}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suppressed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833259147}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833259226}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833350327}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833350483}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- More contrast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833350763}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833351015}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833434147}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833434233}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coefficient from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833434477}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.0 to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833434544}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833538934}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8 so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833539041}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833539192}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can grow closer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833539372}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to cap, then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833618246}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833618442}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833618585}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Prey density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833618641}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coefficient maybe 2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833780979}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2. Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833781168}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator cap 64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833781494}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833781545}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s test caps "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833810539}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833810642}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/64 with density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833810701}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factors maybe 2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833811015}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 and 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833942610}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833942779}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833942856}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" saw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974833943052}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834022620}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834022699}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834022824}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834022979}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834074137}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834074246}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300, pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834074418}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834074612}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 64. With feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834165497}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834165804}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 157"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834165941}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", preds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834166228}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 41. Re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834235614}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"leasing predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834235708}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834235924}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834236017}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8 might yield pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834323895}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834323993}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834324122}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 130"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834324208}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". More oscillations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834383700}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834383817}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834383958}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834384048}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834474108}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834474186}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834474250}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", need predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834474350}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numerical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834569062}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" response"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834569138}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strong"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834569186}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834570356}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834611354}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834611422}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", preds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834611565}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rise and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834611679}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834691906}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hoot. Currently density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834692286}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback limits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834692396}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834692733}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nonline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834771493}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arly,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834771554}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preventing overs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834771660}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hoot. Keep predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834771921}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834860968}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834861240}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834861342}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moderate. Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974834861508}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835177649}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can overs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835177730}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hoot, causing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835177815}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835177907}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drop, then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835234683}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835234789}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve. \n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835234850}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835234929}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835387574}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835387657}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835387720}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 180 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835387787}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835508743}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 cycles.\n- Try:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835508810}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835508864}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factor 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835508915}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835508966}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835509018}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.2; caps "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835509070}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"280/64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835509120}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835557842}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835557884}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835557917}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835557951}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Also could increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835574668}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835574765}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835574822}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835574872}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835603927}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835604001}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" most 1 kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835604055}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per 2 genes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835604107}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835619663}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835619732}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" efficient. Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835619790}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835619944}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 58"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835687812}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835687939}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835688133}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835688216}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20. Not sure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835771735}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's test several"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835771799}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parameter variants quickly."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835771949}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Editing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835772133}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constants for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835858042}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835858109}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", coefficients is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835858152}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cumbersome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835858214}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but possible. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835959942}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expose a URL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835960120}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835960167}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? no."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974835960360}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836032436}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s implement more tun"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836032588}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able constants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836033047}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? We'll likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836033100}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" settle."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836141980}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can evaluate variants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836142038}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by replacing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836142074}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836142117}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file. We'll do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836215613}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a few"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836215701}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nTest A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836215781}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": PREDATOR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836215857}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_CAP 64"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836286395}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836286516}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836286999}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836287038}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836397355}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9, prey density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836397677}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836397732}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836397939}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836500800}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3.8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836501028}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836501384}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_44u5se0wqztpzmih3dlneo6h","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836501679}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836501792}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836501966}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836502034}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836502102}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836513194}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836513335}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836513560}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836513624}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836531612}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836531683}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836531743}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836531803}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836532214}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836532286}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836532631}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836532700}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836550346}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836550429}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836550983}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836551044}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836570536}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836570695}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836570791}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836570857}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836571464}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836571565}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836571711}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836571815}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836609660}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836609759}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836609863}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836609937}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836610941}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836611006}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836611196}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836611273}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836625492}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836625574}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836625692}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836625799}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836650426}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836650502}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836650564}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836650842}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836651536}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836651612}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836651849}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836651944}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836679918}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836680010}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836680090}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836680216}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836695977}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836696038}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836696094}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836696152}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836696509}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836696570}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836696629}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836696685}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836715846}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836715909}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836715966}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836716024}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836740265}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836741025}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836741094}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836741165}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836741739}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836742022}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836742100}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836742164}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836765950}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836766209}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836766355}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836766431}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836776873}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836776968}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836777198}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836777274}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836778377}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PRE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836778686}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836778738}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836778825}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836799013}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836799249}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836799309}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"240"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836799376}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836821145}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836821224}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836821287}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836821355}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836822038}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836822135}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836822217}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836822334}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836927289}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836927365}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"52"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836927425}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836927544}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836985603}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836985683}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PRE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836985757}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836985821}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836985897}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836985959}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836986024}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836986089}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"280"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836995242}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836995336}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836995406}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836995474}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974836999672}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837000255}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837000323}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837000384}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837001173}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837002406}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837002467}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837002523}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837005486}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837005557}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837005617}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837005675}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837010659}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837010729}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837010789}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837010869}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837048034}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837048119}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837048186}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837048252}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837048315}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837048381}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837048446}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837048510}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837053954}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054033}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054121}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054185}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054269}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".pow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054341}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054407}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"unter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054468}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054532}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ensity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054595}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054670}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837054742}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837055138}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837055252}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837055324}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837055388}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837058764}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837058844}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837058910}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837058979}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837059042}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837059105}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837059161}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837059219}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837098806}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837098888}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837098954}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837099035}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837103982}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837104069}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837104140}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837104208}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".pow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837104279}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837104347}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"unter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837104414}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837104480}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ensity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837138857}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837138930}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837138992}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837139055}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837148586}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837148662}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837148732}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837150139}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837150213}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837150281}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837150344}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837150408}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837168623}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837186860}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837186935}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837186997}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837187059}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837187118}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837187178}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837187236}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837187296}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837187353}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837187411}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837187472}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837212248}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837212322}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837212384}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837212443}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837241932}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837242032}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837242115}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837242194}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837570603}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837570717}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837570809}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837570893}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1892,"ts_us":1792974837571357}}

data: {"id":"2366b8c9eb666b8d2ada2738ab40b12e","object":"chat.completion.chunk","created":1792974829,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":160996,"completion_tokens":1058,"total_tokens":162054,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":156416,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":821,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1892,"ts_us":1792974837571502}}

data: [DONE]

