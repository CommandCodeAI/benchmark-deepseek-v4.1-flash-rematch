data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361044886}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Continue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361045446}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361045492}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_9qy5qt4h569ngn4amt9dmgam","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361054926}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361055338}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361055380}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361056441}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361067755}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361068071}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361068695}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361068735}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361100270}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361100435}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361101353}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"382"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361101400}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361136030}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361136106}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"384"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361136180}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361136227}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361158837}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361158886}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361158943}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361158998}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361230510}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2416,"ts_us":1792975361230715}}

data: {"id":"f37672c3d97be62f7190bbb4b5e214eb","object":"chat.completion.chunk","created":1792975360,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":256307,"completion_tokens":51,"total_tokens":256358,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":252032,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":2,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2416,"ts_us":1792975361230822}}

data: [DONE]

