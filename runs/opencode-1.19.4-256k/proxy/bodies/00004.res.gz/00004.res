data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973988920996}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973988921124}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s: Inter Display available"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973988921179}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! Let's see more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973988966251}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973988966337}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_jv1zk02x72kxz8cc2egualnv","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973988966454}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973988966636}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989056940}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989057095}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989057233}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989057310}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989073262}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989073523}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989073604}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989073760}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989078246}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989078343}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989078406}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989078475}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989081968}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989082052}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989082160}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989082232}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989085594}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989085777}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989085937}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" //"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989086120}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989094067}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989094112}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sort"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989094594}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989094666}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"u"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989094741}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989094800}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989094847}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989094962}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ei"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989100863}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989101154}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989101214}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989101392}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"source"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989144104}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989144186}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989144292}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989144403}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989144560}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989144607}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989144653}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"orm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989144695}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"or"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989148015}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989148151}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989148271}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fair"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989148338}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989194778}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989194856}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ral"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989195056}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989195128}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"news"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989253872}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989253925}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989253977}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ight"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989254105}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989254182}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989254438}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989254810}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989254887}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989265864}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ade"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989266044}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989266204}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989266259}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plex"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989284635}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989284737}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mon"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989284789}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989285025}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989293311}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989293372}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989293423}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989293531}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989293617}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989293720}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989293799}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989293894}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989401699}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2094,"ts_us":1792973989401773}}

data: {"id":"206c8424c5e8280aadabcc6ad93dbf92","object":"chat.completion.chunk","created":1792973988,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":26453,"completion_tokens":115,"total_tokens":26568,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":11520,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":12,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2094,"ts_us":1792973989401849}}

data: [DONE]

