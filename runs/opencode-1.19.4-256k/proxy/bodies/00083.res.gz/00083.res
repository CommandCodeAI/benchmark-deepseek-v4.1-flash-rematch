data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091370389}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091370496}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ensure at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091370533}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" <1080 media"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091422269}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091422453}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apparatus-body { overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091422524}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": visible; display:grid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091422632}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ... }` over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091530021}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rides display"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091530103}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flex; yes it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091530205}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091530270}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091696101}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" display grid. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091696200}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091696458}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 900,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091696502}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091791965}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" total "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091792027}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"591, container "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091792080}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"591;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091792155}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" field note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091817385}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" margin auto "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091817559}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0; okay.\nAt "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091817714}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1080, note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091817805}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at bottom. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091908269}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPotential issue field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091908351}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091908463}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ote margin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976091908659}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-top auto in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092104444}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll container if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092104738}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" total content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092104923}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092105193}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"flows? Auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092164282}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" margin zero when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092164386}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" negative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092164736}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" free space."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092164801}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n\nNow,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092179416}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092179586}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we add a subtle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092179668}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092179747}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is alive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092240728}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" movement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092240795}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092240917}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092240983}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092374442}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092374760}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" layer rebuilt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092374805}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only on sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092375240}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" step; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092403415}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6 gen/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092403458}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092403679}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092403734}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092546904}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6fps while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092547110}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" animals interpol"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092547297}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ate "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092548515}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60fps. Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092641920}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092642197}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" static colonies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092642275}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; 6f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092642434}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ps changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092691886}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not noticeable."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092691990}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n- Dust and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092693035}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sweep animate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092693085}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092730111}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ps.\n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092730269}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators/pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092730468}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y interpol"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092730563}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ate.\n- If speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092820318}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused, plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092820514}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" layer static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092820573}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but creatures static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092821284}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092915732}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- At speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092915782}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60, everything"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092915995}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976092916051}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093019328}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- Maybe add micro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093019510}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093020400}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ax?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093020511}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no.\n\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093132214}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093132301}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093132509}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is a cached"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093132573}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bitmap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093174911}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093175127}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DPR; draw each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093175185}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame. fine.\n\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093175439}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world shadow."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093329593}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n\n- Potential CPU"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093329683}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093329874}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant layer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093329991}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at every tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093374909}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 6/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093375146}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093375193}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093375390}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Image per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093480040}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093480107}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093480164}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k/s; fine.\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093480208}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", output of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093555382}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" internal API"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093555488}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The Simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093555634}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" class has no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093557060}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" access to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093647211}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `EV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093647556}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ENT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093647623}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_META`? lexical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093648800}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" const"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093785542}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", fine."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093785679}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093790826}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093790950}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPotential issue using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093894720}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spread"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093894827}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093895071}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...PRE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093895126}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Y_BOUNDS.s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093933696}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"peed` in `cl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093933831}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"amp`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093933964}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976093934012}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094031109}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094031246}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" args; yes `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094031370}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"clamp(v,min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094031528}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",max)`. Fine. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094109993}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spread is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094110184}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min,max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094110259}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" array, yields"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094110876}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094193319}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n\n- Mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094193752}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094193798}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probability"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094193833}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094279385}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Actual ratio"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094279500}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = mutations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094279663}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094279731}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"irths across"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094355133}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094355421}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species. If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094355473}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094356858}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094460260}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fewer births,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094460364}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094460517}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- The genetic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094460566}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spread"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094555583}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094555683}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n- Mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094555797}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094555958}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094624733}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"038, UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094624852}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094625155}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8%. \n\n- Species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094625208}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094706558}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bounds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094706711}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for predicate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094706822}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094707152}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" repro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094834519}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094834703}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 125"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094834771}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094834912}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"180. In charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094953818}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" axis"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094953934}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamic."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094954263}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094954315}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094991186}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094991640}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can mutate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094991705}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" down"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976094991762}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 58"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095084785}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095084944}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could lead boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095085007}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095085191}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095175334}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y reproduction threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095175383}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095175851}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28. \n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095175901}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095257670}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effect."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095257867}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Spe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095257981}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eds etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095258054}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n\n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095339716}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095339977}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" selection:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095340032}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" found"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095340082}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095434093}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095434922}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision; prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095434982}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095435034}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095522739}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .68"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095522800}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*vision. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095523029}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Prey forage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095523092}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095608414}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095608519}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cells"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095608634}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095608735}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoidance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095703584}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if threat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095703653}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" beyond"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095704535}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" *0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095704599}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".68; okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095781094}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095781391}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y movement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095781461}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if current food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095781572}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095895370}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"14 mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095895456}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazes and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095895527}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095895590}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095968841}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve if cell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095968937}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" depleted after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095969016}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976095969090}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; once"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096059409}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" <.14"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096059481}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096059536}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" move"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096059606}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096101587}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096101845}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.085"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096101919}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096102434}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cell loses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096221932}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096222007}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". good.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096222074}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" When prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096222414}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flee,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096308057}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096308353}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096308423}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after moving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096308502}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". fine.\n- Energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096384484}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drains."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096384684}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Predator energy gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096384773}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096385019}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Predator may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096465153}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096465320}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096465442}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096467653}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" marked dead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096528188}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096528576}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" skip."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096528739}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- `found"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096528977}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096641647}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from nearest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096641693}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before movement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096641791}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096642061}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096704283}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096704371}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096704424}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y update occurs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096704478}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096808130}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update, so target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096808182}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current; predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096808370}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then move."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096808481}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could attack"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096869123}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" found"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096869182}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096869260}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096869390}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096945385}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096945638}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It moved before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096945670}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976096946943}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097034902}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097035023}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097038877}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" distance calculated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097038931}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after predator movement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097200786}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". good.\n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097201086}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator speeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097201155}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097201251}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exceed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097277876}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097277970}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; edge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097278042}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bounce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097278101}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097282122}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097282190}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moving fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097282262}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" near"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097282618}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edge, clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097368026}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097368092}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097368151}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097368209}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097452983}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097453057}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097453113}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097453189}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097531813}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097531886}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097532004}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097532078}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not move"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097631505}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much. fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097631587}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097631658}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097632591}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 56"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097712411}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097712518}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 64?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097712765}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We set in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097712862}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097783289}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tuning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097783528}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097783849}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PRE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097783930}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Y_C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097889837}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AP=240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097889922}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097889976}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PREDATOR_CAP="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097890025}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"56, then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097961361}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" never"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097961479}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097961687}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976097961993}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098056727}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098056798}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ya5dn1a8lrcdr8cfagojat0l","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098056867}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098056929}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098056995}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098057056}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098057120}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098057191}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098057631}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098057705}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098057769}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098057830}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098069541}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098069616}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098069703}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PRE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098069768}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098079593}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098079670}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098080616}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098080697}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098082158}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098082225}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098082292}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ATOR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098082360}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098100404}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AP"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098100458}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098100511}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098100565}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098140810}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ANT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098140894}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098140959}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098141051}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098159829}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098159910}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098159987}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098160046}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098301286}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098301377}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098301582}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098301714}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098310842}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098310951}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"116"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098311047}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098311564}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098317921}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098318210}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098318293}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098318387}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098324593}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098324742}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098324914}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098325000}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098372260}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098372418}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098372470}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2758,"ts_us":1792976098379484}}

data: {"id":"e1c2e455fdb17167ccaa67054bd77154","object":"chat.completion.chunk","created":1792976091,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":340761,"completion_tokens":810,"total_tokens":341571,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":338304,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":729,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2758,"ts_us":1792976098380019}}

data: [DONE]

