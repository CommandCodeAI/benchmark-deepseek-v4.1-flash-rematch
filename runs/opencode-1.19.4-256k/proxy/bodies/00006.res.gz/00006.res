data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994827502}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994827580}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", playwright installed?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994827640}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need check path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994905906}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994906057}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_53va3g38n78ra6yqbxo4cjke","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994906745}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994906954}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994909374}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994909584}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994910231}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994910737}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994941667}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994941763}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994941847}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994941941}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994942020}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994942104}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994942192}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973994942286}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995005391}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995005589}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995005691}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995006302}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995018202}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995018414}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rows"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995018779}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ers"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995019285}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995019901}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995020338}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995020617}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995020706}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995021469}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995021637}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995021862}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995022539}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995022632}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995028710}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995028797}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995028882}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995028967}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995029049}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995029223}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995029416}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995049288}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995049388}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995049995}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995050094}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995050170}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995050245}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995050337}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995050427}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995093999}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995094073}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995094190}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ok"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995094241}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995105187}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995105248}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995105322}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995105432}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995114550}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995114668}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995114886}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995115606}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995192237}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1066,"ts_us":1792973995192355}}

data: {"id":"0e3a1d6db7aec0c477ca8546a666ec5b","object":"chat.completion.chunk","created":1792973994,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":28773,"completion_tokens":96,"total_tokens":28869,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":28288,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":9,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1066,"ts_us":1792973995192447}}

data: [DONE]

