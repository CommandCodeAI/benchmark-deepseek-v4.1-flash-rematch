data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991248222}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991248298}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have Inter and Jet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991248325}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Brains Mono. Great."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991262067}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991262287}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Inter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991262334}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Display\" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991263298}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels. Display"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991350688}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" serif options"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991351120}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": Bitstream"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991351173}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Charter, Calade"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991351818}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"a ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991439812}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cambria-like),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991439863}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DejaVu Serif,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991439908}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" FreeSerif. Charter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991439958}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is elegant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991624788}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991624845}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Charter\","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991624879}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Cal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991625522}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"adea\". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991679813}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use an"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991679869}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" editorial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991679973}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" serif for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991680557}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991722942}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; Charter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991723022}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay. Type"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991723116}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pairing: Charter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991723287}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / Inter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991777084}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Display /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991777143}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" JetBrains Mono. Distinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991777189}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ive.\n\nMaybe embed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991777289}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991849122}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991849185}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fonts installed?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991849232}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991849278}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t guarantee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991932694}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evaluation env"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991932754}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991932851}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973991932986}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same machine?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992006098}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We're"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992006241}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" developing locally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992006522}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992006596}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unknown screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992080480}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" environment likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992080527}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same container"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992080794}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992081095}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992179793}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992179859}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stack"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992180279}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992180329}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992261948}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992261999}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992262041}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992262080}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992361867}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"uppeteer."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992361950}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_livsge5uxojyfx0swm2py2iv","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992362108}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992362271}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992362558}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992362646}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992362693}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992362777}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992362891}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992363376}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992363422}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992363648}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992363722}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992363797}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992364458}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992364563}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992379999}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992380189}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992380325}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992380421}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992380607}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992383770}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992383820}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992383866}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992392051}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992392135}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992392210}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992392491}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992413015}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992413330}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992413459}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992413632}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992413797}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992413987}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992414509}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992414669}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"catch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992429315}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992429365}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992429539}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992429646}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992447316}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992447395}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992447466}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" playwright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992448153}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992448235}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992448299}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992448361}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992448509}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992467337}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992467431}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992467489}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"upp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992468555}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ete"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992494588}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"er"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992494662}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992494708}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992494848}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992494901}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992494962}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992495019}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"upp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992495068}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ete"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992513053}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"er"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992513375}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992513434}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992513553}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"catch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992528520}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992528762}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992529294}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992529366}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992529483}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992529703}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992529766}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pupp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992530012}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ete"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992553422}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"er"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992553510}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992553564}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992553624}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992615105}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992615165}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_2935g72jbed1eezqpfbcbac8","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992615289}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992615361}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992637272}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992637374}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992637445}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992637559}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992656490}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992656542}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992656591}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992657530}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992678589}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992679353}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992679693}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992679743}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992679823}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992679902}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992679983}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992680031}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992697714}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992697794}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992697906}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992698368}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992717632}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992717813}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992717856}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992717966}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992718626}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992718728}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992718824}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992719081}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992741147}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992741434}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992741494}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992741856}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992760640}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992760706}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992760866}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992761202}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992781350}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992781627}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992781697}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992781893}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992846414}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992846470}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992847461}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1222,"ts_us":1792973992849153}}

data: {"id":"919a655bc8f69ecfab80e127a7fe803e","object":"chat.completion.chunk","created":1792973991,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":28315,"completion_tokens":305,"total_tokens":28620,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":26368,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":139,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1222,"ts_us":1792973992849781}}

data: [DONE]

