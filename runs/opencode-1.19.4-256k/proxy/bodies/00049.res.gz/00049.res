data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444812880}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444812971}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ensure `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444813012}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"outcome-section"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444871488}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` min-height removed;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444871646}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check CSS around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444871820}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444871921}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_blfdg54iti6oye366slpdf2e","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444894999}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444895095}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444895387}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444895434}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444901645}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444901732}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444902249}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444902318}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444926964}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444927021}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444927142}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444927286}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444941949}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"come"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444942032}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-section"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444942138}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444942289}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444971107}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444971164}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444971430}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444971518}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444971657}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444971757}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444972108}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444972160}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444988770}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444988864}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444989002}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975444989072}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445025467}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445025690}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445025742}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-body"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445025868}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445027765}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445027812}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445028070}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445028112}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445093761}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445093863}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445093926}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445094234}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445136197}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445136555}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445136638}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3449,"ts_us":1792975445147228}}

data: {"id":"8cc86009c777ffc0e3f2285e3bf1d460","object":"chat.completion.chunk","created":1792975444,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":269541,"completion_tokens":86,"total_tokens":269627,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":264320,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":15,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3449,"ts_us":1792975445147315}}

data: [DONE]

