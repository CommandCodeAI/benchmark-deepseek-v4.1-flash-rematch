data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976688798485}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976688835194}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1366x768,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976688835398}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976688835561}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Overflow hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976688917695}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976688917846}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-open"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976688918018}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976688918078}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" absolute not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689017741}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fixed because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689017832}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >108"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689018141}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0; report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689018195}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height 585"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689087885}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689088007}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689088108}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The report extends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689088182}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689166301}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"750; page view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689166439}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"port 768. Fine."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689166540}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It fits."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689166731}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Report content "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689235447}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"585. Good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689235571}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- At 128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689235713}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 report "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689235974}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"623. \n- At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689331461}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440 report y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689331519}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"173"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689331689}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689331743}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 716, bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689444197}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 889; body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689444332}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689444427}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait earlier report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689444487}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689472159}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 157.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689472243}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; now y173 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689472391}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" census"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689472707}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y308."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689534700}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689534813}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The report hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689534925}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689535009}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" transform?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689657022}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689657198}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is open,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689657333}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" transform"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689657579}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" none. Earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689703439}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report y157"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689703620}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9 when console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689703775}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y148"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689703944}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689788404}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689788656}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y166"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689788898}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due font/l"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689788976}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ayout? Did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689844143}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page shift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689844291}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because masthead height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689847825}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increased? Our changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689847936}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to font sizes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689916573}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689916700}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689916970}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976689917039}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" affecting layout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690034240}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690034306}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tip fonts no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690034365}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690034436}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright current page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690078975}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690079099}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" built"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690079422}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after direct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690079491}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stepping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690131487}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690131624}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial page state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690131704}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690131818}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690210477}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y173;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690210628}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690210819}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690210962}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"166. In prior"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690312537}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" measurement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690312715}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690312864}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440 console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690312920}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y148.8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690374035}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Did `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690374135}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apparatus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690374259}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690374567}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` flex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690451778}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690451830}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No mast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690452035}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"head. Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690452096}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690524114}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font loading?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690524286}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We measured after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690524417}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690524547}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"350"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690612169}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms, Inter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690612246}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/Ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690612416}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arter loaded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690612462}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" causing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690682989}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" header height."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690683104}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690683460}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" measure also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690683519}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690784704}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690785011}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe the previous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690785255}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690785300}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690899262}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1440 had mast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690899318}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"head y21"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690899496}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" h113.8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690899552}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -> console y147.8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690931154}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Now report y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690931365}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"173 implies console y167"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690931525}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976690931802}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `.masthead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691076522}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` get taller due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691076709}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `font-size"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691076772}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691076810}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes? We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691125150}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" didn't change mast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691125241}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"head. The body frame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691125356}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691125566}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could be because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691179083}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when page loaded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691179202}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with body open"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691179280}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691179321}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691291069}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Actually report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691291137}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691291173}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691291218}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console, and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691351333}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691351518}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691351737}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6; console y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691351799}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 167"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691434328}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Earlier console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691434467}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y=153"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691434579}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691434654}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" measure2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691522712}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; measured after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691522796}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691522870}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691522950}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691588141}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691588233}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"147.8 first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691588306}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691588390}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691677400}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" masthead height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691677482}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grew from "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691678549}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"113.8 to ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691678611}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Why?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691770474}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691770798}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our report chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691770908}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691771229}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691820714}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t. The tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691820843}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tip or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691821180}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" added"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691821238}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ste"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691909627}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pper unit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691909765}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Ste"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691909937}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pper unit adds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976691909991}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692036473}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692036547}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692036596}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" masthead. The added"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692036678}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692107076}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692107149}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The changes to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692107267}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692107369}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"::after` no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692144494}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" layout."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692144591}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Report y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692147780}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692147828}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692217082}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+6;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692217187}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console y maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692217388}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 167."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692217636}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692300134}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe loaded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692300256}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692300651}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692300745}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692383183}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" affecting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692383300}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692383367}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wrap? h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692383422}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 deck"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692471701}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692471909}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Masthead measured"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692472027}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min 106"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692472239}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe Inter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692541332}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" font loaded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692541490}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692541591}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" metrics, leading"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692541730}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692612796}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"113. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692612958}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" header could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692613018}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692613067}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 133"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692680069}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692680237}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial layout now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692680480}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692680714}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At 144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692802366}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0x900, console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692802423}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692802573}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692802611}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692847997}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height 716"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692848055}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692848092}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 728"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692848147}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") because console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692928909}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692928974}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692929255}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom 889"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692929329}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692999633}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 167+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692999708}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"728=895"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692999802}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? 167"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976692999854}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+722"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693070577}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Wait rep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693070693}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y173"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693070924}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", height716 ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693070998}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom 889; report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693173881}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inset6 => console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693174079}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693174244}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"167, bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693174312}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"895?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693261244}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Console height maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693261329}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 734"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693261391}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693261458}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693334701}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 878"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693334785}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let's measure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693334936}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actual."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693335249}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not concerning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693431785}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; report fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693431954}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693432100}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693432164}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots initial maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693506735}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693506797}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"head now taller"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693506847}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; need verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693507566}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693603178}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693603253}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's measure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693603308}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current once."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693603358}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_cyyw6vbeesq96d9zj5vbh0w8","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693649174}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693649285}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693649439}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693649603}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693668714}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693668836}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693668938}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693669006}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693669737}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693669793}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693670034}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693670087}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693689763}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693689902}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ayout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693690032}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693690182}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693724256}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693724374}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693724524}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693724631}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693739672}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693739762}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693740003}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ayout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693740080}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693852954}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693853037}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693853246}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693853320}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693857656}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693858082}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693858174}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693858246}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693870374}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693870446}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693870580}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693870644}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693871717}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693871923}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693872025}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693872137}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ayout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693888291}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693888381}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693888522}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693888701}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9453,"ts_us":1792976693939630}}

data: {"id":"a30c214a0d5d1d3480650511bd2691f6","object":"chat.completion.chunk","created":1792976688,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":394876,"completion_tokens":682,"total_tokens":395558,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":392704,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":610,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":9453,"ts_us":1792976693939734}}

data: [DONE]

