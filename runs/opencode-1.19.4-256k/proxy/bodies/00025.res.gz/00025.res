data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097097088}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097097167}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s view screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097097225}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_kvhizzirqkpsaae3mie0rugu","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097097285}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097097344}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097097399}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097097447}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097103084}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097103148}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097103201}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097103256}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097131128}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097131199}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097131263}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097131326}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097142101}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097142174}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097142235}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097142391}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097309359}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097309499}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2337,"ts_us":1792975097309772}}

data: {"id":"d9a1aeec379d0871012b343a4d635c2e","object":"chat.completion.chunk","created":1792975096,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":212087,"completion_tokens":51,"total_tokens":212138,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":210944,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":5,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2337,"ts_us":1792975097309937}}

data: [DONE]

