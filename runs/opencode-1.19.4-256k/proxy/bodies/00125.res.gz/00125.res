data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977113978694}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114051314}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note updates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114051428}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now. Good.\n\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114051630}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114107939}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 32 no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114108053}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114108245}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; wait a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114108289}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bit. We don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114189213}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t need.\n\n- The initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114189418}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114189649}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114189715}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good.\n\n- The note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114284863}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114349312}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 140"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114349391}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114349443}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throttle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114407299}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~ after "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114407416}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114488175}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". fine.\n\nNow,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114488252}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" any other bugs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114488302}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114488348}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114488411}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114488479}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".1s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114535565}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114535694}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114535798}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114536409}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114602345}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114602483}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114602641}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114602679}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"34 maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114686134}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114686224}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114686357}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114686815}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114756341}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114757249}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114757311}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114757358}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- The banner overlap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114906895}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calculation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114907082}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114907615}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" invalid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114907688}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114920513}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114920669}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test at event."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114921100}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977114921567}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" did with interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115024967}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 and banner pos"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115025111}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 248"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115025219}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115025841}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UD bottom likely "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115106461}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"264 ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115106622}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115106747}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlaps H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115107120}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UD by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115257065}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 16 px, but actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115257139}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115257327}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UD content bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115257376}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe 214"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115301239}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; it's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115301343}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within the H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115301502}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UD's "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115301651}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"101"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115394395}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px height because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115394491}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115394668}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UD has padding bottom42."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115394708}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The banner may overlap the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115458833}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" transparent padding of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115458886}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HUD, not text."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115458952}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It might overlap the lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115459477}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" part of species counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115532971}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115533111}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UD top "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115533247}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"163, padding top18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115533732}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", contents ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115620624}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30? HUD height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115620736}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 101 ending"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115620814}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 264. Species legend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115620866}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115725106}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"181"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115725294}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-211"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115725456}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115725611}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Banner top 248,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115898485}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115898718}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below. Good.\n\n- At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115898894}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115899576}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115982475}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 162"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115982551}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and event banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115982918}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top 94 => 256"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977115982995}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116039692}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116039762}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116039914}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116040067}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116066896}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"34"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116067008}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should banner show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116067197}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116067352}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s wait "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116149203}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116149397}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116149625}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not needed. Earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116149701}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116273607}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval10 confirmed.\n\n- Any"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116273658}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" other throttle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116273764}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bugs?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116273813}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n  - The drawMicro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116332065}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116332325}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116332425}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" guard: `draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116332481}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Micros(now,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116400469}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" force = false) {"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116400568}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if (!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116400673}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"force && now - this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116400731}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".lastMicro < 220"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116496889}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") return; ...}`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116496953}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In frame, we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116497102}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" call only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116497814}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if now-lastMicro>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116587996}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"240, then draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116588198}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Micros("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116588411}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"now) ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116588453}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"force"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116659231}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" false) sees"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116659432}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116659598}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116659661}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116738348}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"220 so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116738482}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" proceeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116738621}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". On"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116738764}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116829049}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116829181}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" force true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116829373}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine. But do we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116829469}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update lastMicro in draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116991702}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Micros? The frame sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116991882}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116991974}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"this.lastMicro=now`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977116992182}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before calling;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117014589}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control force"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117014689}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117014801}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t update last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117015469}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Micro, so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117110046}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117110137}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" red"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117110314}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"raw again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117110368}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soon"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117226999}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Not a functional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117227125}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue.\n  - The draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117227196}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117227336}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eline called"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117305109}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every frame even"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117305232}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117305384}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" open. fine.\n  -"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117305455}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117457113}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Micros calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117457229}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117457416}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Canvas` each time. fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117457477}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n  - The `update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117471392}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117471499}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Note` now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117471610}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117471726}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lastNote only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117520608}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117520677}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117520806}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" force. In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117520909}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updateLiveUI, every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117619953}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 140"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117620126}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0ms it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117620248}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls; if text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117620422}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unchanged, lastNote is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117695564}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not updated!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117695647}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117695887}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117695950}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117787333}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1400ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117787497}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", updateFieldNote gets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117787624}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" called because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117787801}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117869304}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-lastNote>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117869375}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1400 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117869557}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text unchanged;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117869610}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it computes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117961144}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117961247}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't set last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117961306}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Note. So it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977117961445}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118043296}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118043442}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame (60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118043595}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fps), not throttle."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118043721}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118203976}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118204234}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lastNote ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118204310}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now` always at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118204447}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the end, not only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118234197}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118234356}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118234484}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118234529}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118396015}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wrong"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118396117}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118396286}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118396329}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Note = now always after computing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118475279}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118475448}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118475514}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118475661}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118494248}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Note also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118494408}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118494548}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118494612}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" guard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118621146}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for !"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118621255}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"force. When called"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118621488}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118621752}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updateLiveUI periodically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118656433}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118656492}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at end. So simply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118656843}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n```\nif"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118657147}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118742751}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118742866}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118743021}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Content=note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118743062}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";\nthis.lastNote"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118844682}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118844789}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now;\n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118844900}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"```\nNo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118845079}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need else if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118917718}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" force"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118917856}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The guard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118917956}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prevents calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977118918048}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119030393}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" than "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119030467}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1400 unless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119030533}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" force;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119030595}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" force"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119067153}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119067227}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lastNote"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119067298}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too. Good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119067368}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119166748}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119166877}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" always set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119166970}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- That prevents repeated compute"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119167043}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119299507}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119299645}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_op79m7ydtwxoouvmnhqhomg1","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119299758}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119299863}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119299956}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119300048}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119300140}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119300234}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119300336}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119300427}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119300512}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119300590}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119310743}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119310866}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119310949}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119311027}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119311108}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119311185}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119311264}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119311343}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119317007}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119336025}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119336105}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119336169}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119429101}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119429174}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119429235}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119429326}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119429387}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119429444}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119429503}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119429561}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119467624}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119467704}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119467765}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119467822}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119467881}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119467942}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119468007}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119468065}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119468124}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119468539}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119468617}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119468701}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119468760}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119471413}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119471491}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119471558}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119478307}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119478378}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119478441}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119478502}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119481316}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119481393}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119481654}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119481723}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119482732}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119482821}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119483165}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119483258}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119483495}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119483557}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119484242}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119484480}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119486961}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119487030}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119487235}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119491748}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119491819}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119491882}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119491943}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119492001}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119492059}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119492120}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119492180}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119492249}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119506693}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119506763}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119506824}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119506881}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119539460}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119539539}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119539606}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119539667}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119539730}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119539792}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119539855}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119539915}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119567272}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"om"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119567348}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".field"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119567409}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119567469}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119624525}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119624602}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" !=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119624664}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119624723}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119642123}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119642221}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119642284}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119642344}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119642406}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"om"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119642467}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".field"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119642554}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119642614}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119645392}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119645468}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119645530}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119645599}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119680610}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119680691}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119680770}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119680844}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119680915}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119680986}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119681054}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119681114}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119681174}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119681230}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" else"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119681287}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119681346}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119691677}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"force"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119691761}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119691822}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119691882}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119691945}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119692004}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119692061}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119692119}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119719829}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119719910}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119719978}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119720043}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119740847}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119740916}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119740975}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119741030}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119741088}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119741146}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119741204}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119741263}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119770424}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119770501}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119770561}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"om"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119770618}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".field"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119798495}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119798580}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119798648}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119798709}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" !=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119798770}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119798832}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119798895}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119798955}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119861782}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"om"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119861832}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".field"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119861873}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119861911}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119891815}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119891899}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119891965}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119892031}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119892100}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119892165}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119892239}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119892306}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119921954}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119922044}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119922115}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119922179}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119932400}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119932474}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119932533}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119932599}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119932657}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119932738}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119932800}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119932860}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119942060}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119942143}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119942218}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14773,"ts_us":1792977119942280}}

data: {"id":"564a6707ae18e53c9f114a783da01d12","object":"chat.completion.chunk","created":1792977113,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":428337,"completion_tokens":847,"total_tokens":429184,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":427264,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":642,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":14773,"ts_us":1792977120043222}}

data: [DONE]

