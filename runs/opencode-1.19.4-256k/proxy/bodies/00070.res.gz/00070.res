data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833024463}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833024559}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replaced final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833024734}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833217718}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" string maybe whites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833217773}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pace at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833217870}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end added? Check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833218126}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_y1cf1rezuy6xme60zut603z0","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833218575}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833218666}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833218749}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833218816}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833218880}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833219042}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220329}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220387}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220501}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220595}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220716}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"441"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220785}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220872}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220927}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"442"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833220990}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833221075}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833253136}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833253195}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833253257}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833253321}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833253367}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833253403}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833253470}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833253521}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833256763}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833256830}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833256876}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Input"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833256931}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833280975}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833281182}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833281235}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833281299}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833357192}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833357447}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3937,"ts_us":1792975833357752}}

data: {"id":"5cbe378eed312f51f5c6c1113ce635c0","object":"chat.completion.chunk","created":1792975832,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":315890,"completion_tokens":76,"total_tokens":315966,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":313344,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":14,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3937,"ts_us":1792975833357857}}

data: [DONE]

