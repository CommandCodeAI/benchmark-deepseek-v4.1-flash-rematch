data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997170769}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997170879}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997171023}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997246019}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997246168}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /opt/ap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997246344}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ache"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997246426}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"... list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997318912}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; second"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997318985}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997319040}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997319104}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ls /opt/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997395955}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"playwright;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997396047}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ls /opt/pw-b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997396131}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowsers | head` output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997396417}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"chromium...\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997488755}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probably /opt/playwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997488828}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997488882}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997488928}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output lists"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997570324}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997570379}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"opt includes playwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997570473}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997570788}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then second"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997635653}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997635723}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first command"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997635776}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997635837}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says chromium chromium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997788643}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-1243"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997788735}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc likely `/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997788978}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"opt/browsers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997789137}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`? `ls /opt/playwright;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997822319}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997822421}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe no output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997822536}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997822826}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997842313}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_r5tc3hzo441syti4il5ogql2","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997842418}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997842833}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997843260}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997862212}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997862396}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997862646}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997862697}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997880425}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997880590}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997880811}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997880933}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997881721}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997881788}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997881942}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997885849}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997906700}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997906783}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997906836}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997906895}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997927165}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997927238}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997927399}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997927588}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997938327}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997938389}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997938448}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997938593}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997955814}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997956056}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997956319}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973997956387}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998010586}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998010785}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998010840}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998010926}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998012825}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998012954}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998013054}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998013169}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998017398}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"package"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998017492}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998017597}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998017754}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998019734}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998019991}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998020070}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998020199}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998020339}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998020594}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998020663}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998020827}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998036914}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998037040}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998037114}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998037175}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998052058}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998052213}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998052312}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998052426}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rows"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998136301}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ers"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998136391}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998136485}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1462,"ts_us":1792973998136703}}

data: {"id":"7198cae1419dc77ff8f24eab67dad839","object":"chat.completion.chunk","created":1792973997,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":29082,"completion_tokens":184,"total_tokens":29266,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":28672,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":94,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1462,"ts_us":1792973998136840}}

data: [DONE]

