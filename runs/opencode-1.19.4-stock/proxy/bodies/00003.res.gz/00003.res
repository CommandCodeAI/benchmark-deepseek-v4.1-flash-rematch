data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381243833}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Empty"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381298808}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" repo. Need create index"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381299056}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".html. Need thoughtful design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381299241}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need likely test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381392015}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381392103}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less browser. Is playwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381392168}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" available? Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381392705}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tools."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381475548}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_5l6g69oemmbj5szu1h2twacu","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381475623}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381486417}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381486495}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381486576}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381486659}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381486738}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381486800}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"which"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381486883}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381486985}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381487063}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381487147}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381487214}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381487814}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381487898}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381487964}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" playwright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381501055}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381501140}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" npm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381501226}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381501302}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381518250}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381518335}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381518842}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381518969}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381519030}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381519117}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381519199}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381519275}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381526725}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381526797}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381526856}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381527761}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381540824}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381540942}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381541004}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"usr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381541068}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/bin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381567966}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381568065}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381568161}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381568395}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ei"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381569341}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381569766}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381569855}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381569933}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381597641}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381597710}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381597783}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fire"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381597861}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fox"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381624254}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381624350}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381624424}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381625108}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381678426}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381678695}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_0bhbeapltq3lq7talijt7dwi","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381678789}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381679135}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381679681}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381679742}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381679969}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381680053}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381736018}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381736093}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381736158}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381736243}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381737748}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"eline"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381737849}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381738107}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381738174}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381745728}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381745807}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381745879}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381745931}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381746064}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381746124}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381746168}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381746993}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381773808}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381773905}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381774001}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381774172}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381839828}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1129,"ts_us":1792973381840541}}

data: {"id":"d38ab4f02bee942be6efeb3216a30e5e","object":"chat.completion.chunk","created":1792973381,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":11455,"completion_tokens":152,"total_tokens":11607,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":11136,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":27,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1129,"ts_us":1792973381840761}}

data: [DONE]

