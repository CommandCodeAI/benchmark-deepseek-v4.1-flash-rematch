data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839110625}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Mobile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839110727}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel now visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839110767}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", though no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839188516}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839188593}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instructions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839197339}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839197397}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Looks fine;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839265031}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no close button"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839265376}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839265442}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right shows X?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839265771}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It's blurred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839353017}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839353086}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At x365"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839353150}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839353196}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" there is maybe close"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839430303}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839430373}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839430601}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses full screen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839430878}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" minus "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839530599}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40. Good. The footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839530694}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839530760}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ALL D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839530866}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IALS ACT LIVE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839728010}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839728196}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and seal record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839728280}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine.\n\nOne issue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839728363}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839749015}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839749064}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" open, mobile panel overlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839749127}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839749168}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839766151}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839766434}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" behind partly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839766505}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" blurred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839766560}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n- At top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839868253}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839868320}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" close icon"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839868378}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839868430}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at top right but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839962975}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faint. fine.\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963034}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" desktop screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963100}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963156}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_5mhb4i9bvjng9qlrs7jtkk6l","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963218}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963475}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963587}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963691}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963772}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839963835}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839964854}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839964938}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839982806}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839982885}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839982955}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839983250}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839983653}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839983760}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839983860}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977839983968}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977840023746}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"des"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977840023960}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ktop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977840024051}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977840024099}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977840072014}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28032,"ts_us":1792977840072214}}

data: {"id":"fb96c45d217f250c525b0877a3d9ba77","object":"chat.completion.chunk","created":1792977838,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":307241,"completion_tokens":155,"total_tokens":307396,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":307200,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":106,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":28032,"ts_us":1792977840073065}}

data: [DONE]

