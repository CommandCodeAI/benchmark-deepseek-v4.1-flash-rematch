data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290573035}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_sbcbatm8cfbo0kadm2vlq15y","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290573131}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290573191}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290573584}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290573642}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290573693}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290574170}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290604592}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290604689}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290604805}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290606034}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290621249}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290621413}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290621592}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290622423}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290645197}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290645392}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290646004}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290646092}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290668733}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290668942}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290669803}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290669854}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290687246}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290687312}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290687369}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290687744}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290688174}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290688286}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290688949}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290689186}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290706679}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290706754}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290706853}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290707429}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290727994}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290728210}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290728407}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290728705}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290751157}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290751233}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290751289}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290751657}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290751731}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290751787}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290751864}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290751950}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290769265}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290769753}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290769940}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290770252}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290789571}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290789688}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290789801}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290790518}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290790800}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290791012}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290791390}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290791490}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290809491}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".back"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290809693}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"up"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290809769}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290810291}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290831131}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290831223}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"base"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290831311}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290832239}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290832309}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290832391}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290832592}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290832640}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290856964}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290857056}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290857138}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290857864}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290878912}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290878988}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290879503}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290880198}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290881259}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"short"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290881330}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290881379}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290882509}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290930624}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290930706}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290931192}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290931265}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".random"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290931829}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290931911}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290931992}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290932803}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290945332}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290945383}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290945457}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290946148}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290965151}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290965312}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290965360}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290965740}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290985548}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290985793}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290986435}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978290986490}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978291068113}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29937,"ts_us":1792978291068176}}

data: {"id":"3a7a03d862484b1bea14ce15a29db470","object":"chat.completion.chunk","created":1792978290,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":310821,"completion_tokens":131,"total_tokens":310952,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":310400,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":29937,"ts_us":1792978291068753}}

data: [DONE]

