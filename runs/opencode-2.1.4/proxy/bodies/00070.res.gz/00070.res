data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977063966244}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977063966319}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977063966379}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1024,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064063681}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064063764}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064063919}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"flows by 95/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064063975}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"123px, requiring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064128393}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll. In "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064128444}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064128493}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064128609}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fits."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064200226}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064200313}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptable but important"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064200381}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064200484}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sizes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064278423}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064278896}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fit 128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064278965}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0x800 without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064279045}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll ideally,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064349213}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064349376}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064349423}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" least forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064349747}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" partially."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064431654}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064431809}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" designed responsive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064431886}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064432324}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adapt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064518079}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064518130}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height. "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064519286}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"95px overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064519340}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064688113}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 800: significant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064688272}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064689420}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064689475}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064719018}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compact at lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064719064}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" heights or allow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064719711}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overall page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064719769}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll. Better use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064765873}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CSS @media ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064765937}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"max-height: 820px"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064765985}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") to shrink controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064766032}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064893374}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064893454}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064893524}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024, the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064893582}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064933026}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"306, content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064933087}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" taller due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064933137}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wraps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977064933256}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065009231}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use media"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065009281}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query max-width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065009344}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1180 for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065009408}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slightly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065219653}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" smaller components"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065219738}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", or scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065220232}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065220295}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? We can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065411652}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065411746}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-responsive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065411824}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" styles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065411946}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- For max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065604350}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-height 840px"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065604427}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065604491}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065604548}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-note? Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605106}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" heading, dial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605173}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605230}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", padd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605285}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ings, weather footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605341}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. Need save"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605398}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~95 at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605455}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 800 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605512}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605831}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605899}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 120.\n- Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065605965}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" place"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065606025}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065711848}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at top?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065711937}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could hide bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065712034}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drawer forecast ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065712667}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"it's redundant with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065727720}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ledger forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065727774}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065727816}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for short heights"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065727946}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But panel bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065768277}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" currently forecast; user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065768371}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wants forecast?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065768758}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It's duplicate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065768831}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At short"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065852444}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" heights, hide `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065852493}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"drawer-forecast`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065852610}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" saves "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065852646}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"65. Then overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065923519}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 95"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065923570}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"→30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065923672}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977065923711}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed note saves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066022577}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066022649}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066023090}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fits. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066023154}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tooltips etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066099766}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At 800,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066100240}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066100295}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066100334}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066202492}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066202543}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fold; user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066202580}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can scroll. To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066202688}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066253007}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066253308}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clipped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066253670}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", hide forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066253720}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066347232}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-height 850. Bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066347284}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066347338}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" forecast visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066347398}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066431081}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066431140}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" information"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066431495}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066431681}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed note at max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066510101}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-height 820."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066510158}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066510198}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `panel-foot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066510449}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066605371}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066605431}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066605479}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066605537}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" important. This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066686927}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066687004}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n- But at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066687117}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024 width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066687185}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066772040}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066772119}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 306 and overflow "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066772188}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"123; hide forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066772295}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066873404}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"65) + note (28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066873467}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") + some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066873631}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" padding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066874433}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" save "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066925667}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 => fits. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066925739}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Alternatively reduce dial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066925808}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s from 79"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977066925875}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 70 and range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067016341}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. Could maintain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067016420}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067016869}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067016942}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067085712}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067085789}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" savings"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067085846}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067085905}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" forecast "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067176355}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"65, hide seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067176433}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note 28, hide weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067176598}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-foot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067176651}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067259154}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") 12, reduce vertical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067259306}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" padd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067259677}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ings 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067259754}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067339386}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel footer?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067339437}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 26"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067339542}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067339623}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"but seal record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067424238}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would be inaccessible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067424291}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Hmm. Could put"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067424394}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067424437}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record in footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067594505}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" global"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067594770}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Perhaps no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067594855}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can allow panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067595133}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrolling; it's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067665762}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not fatal. But screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067665840}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067665887}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067665936}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clip forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067704396}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Better to adapt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067704461}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with visual.\n "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067704529}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067704857}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067777926}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll 95"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067777990}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means forecast 65"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067778058}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067778107}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067854950}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067855004}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067855062}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clipped."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067855120}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need measure layout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067977308}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 1280. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067977362}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067977417}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could scroll. But aesthetics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977067977839}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evaluation likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068014669}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 1440x900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068014722}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068014775}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280x800."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068014869}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At 1280x800"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068104417}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", panel looks cut at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068104479}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068104554}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068104637}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068189817}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_b4hgnsck2unpy8qcjl6u2ibp","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068189909}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068190111}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068190327}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068196567}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068196658}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068196729}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068196791}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068199768}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068199819}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068200096}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068200177}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068201171}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068201238}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068201337}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068201515}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068203385}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068211915}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068211996}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068212068}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068303327}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068303414}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068303477}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25761,"ts_us":1792977068303535}}

data: {"id":"61c6bf3005c03d4eb4b5fd8e0a2dd7ad","object":"chat.completion.chunk","created":1792977063,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":293585,"completion_tokens":598,"total_tokens":294183,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":292352,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":548,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":25761,"ts_us":1792977068303637}}

data: [DONE]

