data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578214337}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578214478}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright cli available"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578214782}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but browser?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578308163}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578308309}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_r3qcngqn90zp4yvg6as43z0b","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578308407}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578309547}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578309677}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578309760}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578310284}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578310399}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578310495}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578310586}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"px"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578310676}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" playwright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578310880}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578326852}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578326951}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578327117}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578327672}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ~"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578353369}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578353481}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578353555}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578353678}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578368253}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578368333}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578368945}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578369009}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578369356}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578369455}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578369547}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578369659}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578399687}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578399736}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578399778}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578399819}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578430694}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578430805}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578431134}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578431404}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578432982}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578433066}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ame"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578433110}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578433621}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578435796}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578436081}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578436413}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578436507}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578440139}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578440428}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578440491}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578443256}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578467915}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578468028}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578468172}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578469627}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578548992}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578549049}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1627,"ts_us":1792974578549128}}

data: {"id":"cdb86740c53358726b8411fa972fb7d2","object":"chat.completion.chunk","created":1792974578,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":20416,"completion_tokens":90,"total_tokens":20506,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":5888,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":10,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1627,"ts_us":1792974578549311}}

data: [DONE]

