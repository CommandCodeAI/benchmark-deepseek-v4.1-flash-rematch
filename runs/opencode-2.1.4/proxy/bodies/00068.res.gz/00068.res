data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976994971471}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976994971535}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Collapse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976994971607}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995070460}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe layout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995070855}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995071830}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yduw33yq1la5m0a1zjy2bbak","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995071902}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995071962}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995072189}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995072262}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995072383}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995077729}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995077980}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995078028}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995078165}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995092662}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995092715}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995092961}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995093397}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995094399}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995094454}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995094505}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995094569}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995115599}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995115822}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apsed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995115898}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995116012}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995231686}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19672,"ts_us":1792976995231772}}

data: {"id":"182b33901d977555625b36350cbcd57f","object":"chat.completion.chunk","created":1792976994,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":291599,"completion_tokens":58,"total_tokens":291657,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":290688,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":8,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":19672,"ts_us":1792976995231936}}

data: [DONE]

