data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746691572}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746691657}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746691712}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746711340}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event, dashboard."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746711381}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_kxzigkmiiluhlk2eb7r2pq43","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746711434}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746711498}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746774193}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746774300}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746774723}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746774957}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746775047}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746775214}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746775269}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746775926}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746775998}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746776060}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746776478}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746776547}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746776599}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746776696}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746777096}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746777159}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746777356}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746777409}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746777934}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746778369}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14691,"ts_us":1792976746870911}}

data: {"id":"d25ecb00440e2d11dd24d7b11a1da04b","object":"chat.completion.chunk","created":1792976746,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":283366,"completion_tokens":61,"total_tokens":283427,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":282240,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":11,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":14691,"ts_us":1792976746871041}}

data: [DONE]

