data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450673547}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450673659}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need answer with title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450673733}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450746495}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450746565}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quotes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450746613}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need name"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450746669}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" specific"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450924944}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" conversation."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450925008}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Message is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450925111}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450925159}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" single-file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450953954}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450954072}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450954251}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974450954411}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ist design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451018909}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", controls,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451018972}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451019066}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451019170}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard. Need "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451070926}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3-5 words,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451070997}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sentence case."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451071103}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451071380}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451161989}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eded ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451162098}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation\" or \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451162474}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Evolving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451162601}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem specimen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451255613}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\". Must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451255669}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be specific"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451256043}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451256095}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Evolving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451317641}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem under glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451319012}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" captures"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451319072}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451319121}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451403717}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 words"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451403990}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Distinguish."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451404197}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need no label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451404462}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451468630}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's craft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451468852}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \"Evolving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451468899}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem under glass\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451469135}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451559319}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451559430}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" words. Sentence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451559482}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" case. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451559587}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mentions seeded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451628539}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451628805}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? \"Se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451629463}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eded ecosystem under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451629505}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glass\" 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451706992}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" words. Specific subject"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451707232}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451707536}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451707579}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design living"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451800369}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" specimen under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451800439}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glass. Use \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451800490}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Seeded ecosystem under glass\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451800542}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It reads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451926727}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" naturally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451926808}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Title only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451926905}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451927159}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Seeded ecosystem under glass","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1282,"ts_us":1792974451927435}}

data: {"id":"99289ba43adebe8132ea9427998736f4","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":896,"completion_tokens":153,"total_tokens":1049,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":384,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":147,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1282,"ts_us":1792974451927571}}

data: [DONE]

