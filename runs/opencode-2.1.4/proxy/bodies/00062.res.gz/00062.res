data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767048492}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767048573}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767048608}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.2s after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767242620}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" load, gen0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767242674}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", elapsed 1. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767242806}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767242930}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" did not show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767261642}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767261734}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767261861}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767262819}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"218"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767356070}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767356185}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767356513}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"27."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767356563}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Looks okay."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767490261}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767490608}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more varied but still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767490675}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kind"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767490740}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of horizontal paisley pattern"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767555002}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due lots of broad"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767555050}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"leaf. Some areas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767555165}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767555211}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like a woven"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767639076}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pattern. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767639408}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more organic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767639487}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767639547}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" this zoom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767769561}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767769668}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the field is dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767769780}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and varied. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767769862}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767828784}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a strong"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767828887}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767829102}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767829164}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could we improve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767918047}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by making certain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767918143}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767918203}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shorter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976767918259}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/bar"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768003715}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768003785}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768003830}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lying distribution"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768003871}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768083619}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge dark clear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768083673}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ings and dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768083777}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768083842}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Nice.\n\nBut a couple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768169738}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of concerns:\n- The world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768169863}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at top 100% dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768169974}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but no margin?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768170066}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768284075}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Top overlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768284144}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text \"L"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768284192}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVE SPECIMEN...\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768284273}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low contrast but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768379348}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768379517}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ible.\n- Header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768379583}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" elapsed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768379645}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768532157}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"00:01 despite wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768532201}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.2; started"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768532540}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~1.2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768532595}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sec earlier. fine.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768586713}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Panel now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768586971}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768587022}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768587213}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and forecast. Good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768642754}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Bottom forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768643008}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at ~814"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768643050}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and footer 837"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768643244}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Great.\n- The control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768746720}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels are still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768746967}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tiny but fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768747007}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" style"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768747454}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768870457}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768870566}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ac"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768870766}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lysm\" and \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768870861}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mutation\" tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768977755}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tips etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768977812}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- \"Can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768977865}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"opy reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976768977966}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth\" spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769029011}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769029093}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769029144}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line. It's okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769029243}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The sparklines are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769128365}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not visible enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769128417}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769128460}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769128542}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as faint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769201809}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769202001}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right. The instruction requires"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769202601}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769202715}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparkline next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769288368}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to each knob"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769288523}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; they are there"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769290404}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769290463}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more visible. Raise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769384075}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" opacity/st"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769384158}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"roke width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769384243}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and give"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769384289}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769483779}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faint box"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769483856}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769483904}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769483965}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a subtle baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769566947}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769567227}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769567303}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" colored"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769567396}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769629126}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769629207}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" values do show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769629271}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769629388}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769707641}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparkline traces"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769707698}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are almost invisible. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769707977}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s boost. For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769708027}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `Spark`,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769820175}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lineWidth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769820291}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" =1 currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769820355}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and alpha"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769820399}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769916610}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"92. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769916680}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" color of food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769916741}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976769917029}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on dark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770132096}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770132350}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18px height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770132403}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", should be visible. In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770132779}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot only a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770209377}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tiny wigg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770209439}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ly line. Maybe because initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770209597}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770209647}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" values are too flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770267598}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770267654}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770267704}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). We should seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770267826}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more amplitude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770383891}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770384162}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ise and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770384203}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ensure path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770385312}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770514663}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" full height. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770514821}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" does by scaling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770515044}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min/max, so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770515278}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current traces"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770597779}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should be full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770597824}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770598031}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770598075}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770687029}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faint small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770687251}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line at right but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770687508}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770688116}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I can inspect crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770796081}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We'll enlarge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770796286}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770796343}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770796889}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"width and line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770872036}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770872298}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770872363}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770872493}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faint area"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770947891}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770947963}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770948006}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spark,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976770948046}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 62x18, okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771051530}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe the screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771051583}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resolution makes it small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771051697}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Add a tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771051740}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caption above the spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771141924}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771142034}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `.range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771142265}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-bounds ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771142354}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"signal-name` \"L"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771257116}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVE CANOPY\" centered"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771257340}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under range;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771257494}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tiny."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771257913}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The spark is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771351589}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at right of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771351647}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771354375}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The requirement might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771354428}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be satisfied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771435394}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771435454}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771435521}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771435631}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771512778}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771512853}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771512950}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771513031}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771719582}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, but at 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771719645}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2s only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771719698}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771719818}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation. After "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771803889}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5s, line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771803944}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- The panel may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771804004}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feel too much tiny text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771804555}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771895764}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but sophisticated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771895820}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The theme reads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771896177}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as a high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771896664}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-end field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771950388}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" journal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771950454}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771950518}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"observatory. Good.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771950556}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The layout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771964960}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s title at top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771965154}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" left and controls right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771965225}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976771965416}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772015475}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772015527}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are integrated as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772015636}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a docked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772015752}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instrument drawer.\n- Need perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772111806}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add a more distinctive signature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772111894}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" element visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772111999}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772112062}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" load. The seal mark and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772192416}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772192484}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s are custom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772192551}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772192708}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"living"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772272500}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" specimen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772272557}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under glass\" is implied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772272613}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772272743}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", glass frame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772446430}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772446494}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stamps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772446562}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are signature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772446608}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moments"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772478954}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The arched"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772479013}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772479077}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not present. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772479153}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add a more visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772581779}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"glass\" reflection"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772581868}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to convey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772582007}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772582075}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glass. Currently subtle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772629614}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe add a large"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772629671}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" diagonal glass she"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772629711}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"en and condensation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772629769}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at top left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772741216}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It already but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772741293}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" imper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772741370}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ceptible. Streng"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772742028}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"then slightly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772881777}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", add an \"arc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772881849}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772881904}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772881946}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" along the top/left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772965248}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772965643}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CSS pseudo overlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772965916}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976772965975}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" polygon."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773039104}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" More"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773039192}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" obvious could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773039247}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" risk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773039289}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual noise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773152831}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773152969}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773153018}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top-left diagonal streak and rounded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773153350}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" highlight"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773249549}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773249605}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" upper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773249650}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edge. It can help"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773249865}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Add a faint inner oval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773385866}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773386483}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dome outline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773386526}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The world is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773386584}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773504594}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rectangle with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773504696}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" corner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773504878}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brass brackets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773505743}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773562368}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773562684}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773562767}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Signature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773562824}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773621104}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be the **weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773621210}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773621300}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773622127}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It's only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773707302}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when event. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773707383}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773707461}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773707532}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" great from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773799618}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773799795}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the seals. \n- Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773799850}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add a central \"specimen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773800520}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773910856}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" or ruler"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773910945}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773911085}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could be nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773911145}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but no.\n\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773999258}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Header top right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976773999371}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774000178}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ring uses minute tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774000224}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" marks? In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774080230}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774080336}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows only some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774080605}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks? The progress ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774080645}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0. It looks like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774161440}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a clock. Nice.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774161487}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774161542}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774161591}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774247070}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-specific logo seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774247136}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The empty"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774247264}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" black area under the right panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774247342}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774350401}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no.\n\n- The simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774350641}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774350938}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants everywhere"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774350989}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but some are dim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774443626}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n- Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774443692}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y circles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774443740}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sometimes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774443798}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" look like small flowers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774523002}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774523064}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the legend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774523198}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774527944}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s make species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774610965}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clear. Good.\n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774611011}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators are rust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774611206}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" colored"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774611245}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774686338}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774686649}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lost among"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774686702}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dry"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774687115}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774791495}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Not too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774791642}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- We can add a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774791684}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slight outline/ring to predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774792069}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for clarity. Maybe enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774883290}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- Main"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774883546}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774883805}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seems very green"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976774883845}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", body dark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775028694}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine.\n\nCheck"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775028743}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775028792}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775028854}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8ebj22bt6w5v4qa5dr4dkas5","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775029270}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775029328}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775029388}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775029471}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775042619}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775042670}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775042957}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775043011}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775066504}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775066604}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775066685}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775066765}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775066845}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775066923}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775067020}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775067121}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775097872}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775097952}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775098168}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775098308}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775258382}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17539,"ts_us":1792976775258981}}

data: {"id":"d20ced7b30badba496dd15500af3c01b","object":"chat.completion.chunk","created":1792976766,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":284236,"completion_tokens":986,"total_tokens":285222,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":283264,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":937,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":17539,"ts_us":1792976775260362}}

data: [DONE]

