data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001598036}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001598112}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need stop being"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001598148}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interrupted. Perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001607405}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" messages"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001607458}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too long due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001607545}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reasoning? I'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001607686}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keep tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001722699}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls concise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001722767}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and final answer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001722831}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" short"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001722913}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's run final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001758768}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001758815}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_a8y28ahlurlqtmtvnd1wxvw8","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001758871}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001759024}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001759107}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001759356}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001759442}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001759513}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001832536}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001832627}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001832701}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001832761}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001832801}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001832853}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001832909}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001832955}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001834480}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001834557}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001834803}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001834858}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001835323}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001835504}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001835642}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001835776}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001836839}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001836891}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001837120}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001871634}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001871683}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001871724}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001872293}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001872368}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001872439}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001872516}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001872575}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001872659}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001874199}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001874296}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001874341}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001875088}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001883587}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001883639}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001883690}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001883743}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001883873}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001883928}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001883986}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001884050}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001898312}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001898382}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001898551}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001898617}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001913280}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001914470}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001914535}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001914600}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001914714}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001914762}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001914815}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001914865}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001956563}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001956778}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001956854}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001956989}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001961224}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001961275}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001961511}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001961688}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001977003}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001977062}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001977130}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001977180}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001977226}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001977276}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001977333}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001977388}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001999444}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001999516}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001999585}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(async"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978001999625}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002039030}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002047879}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002047954}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002048004}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002048329}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002048415}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002048487}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002048566}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002100817}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002100897}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"unch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002100976}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002101118}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002165363}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002165434}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002165710}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002165792}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002165878}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" executable"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002166382}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002166486}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002166548}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002166606}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167022}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167123}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167190}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167269}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rows"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167343}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ers"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167388}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167475}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167903}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002167984}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002168053}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"124"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002168123}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002168175}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002168209}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002168673}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002168728}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inux"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002185736}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002185937}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002186877}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002186952}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002187016}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" args"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002187081}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188333}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188442}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"--"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188534}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188610}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188690}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188766}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188821}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188891}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002188961}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002189034}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002189111}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002189157}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002189292}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002189368}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002199681}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002199788}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002199876}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"viewport"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002199925}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002211164}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002211249}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002211324}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002211387}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002211566}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002211635}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002212170}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002212224}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002231709}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002231897}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002231996}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002232109}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002253232}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002253278}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002253317}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002253906}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002277878}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002277958}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002278107}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002279922}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002283755}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002283950}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002284051}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002284122}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002285138}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002285234}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002285321}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002285379}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002302777}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002302833}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002302903}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002302969}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002325090}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002325471}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002325557}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002325614}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002327553}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002327630}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002327703}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002327765}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002350581}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002350658}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002350782}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002352055}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002374207}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002374285}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002374425}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002374785}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002375201}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002375298}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002375378}}

data: {"id":"67ca0dfa392ae9d7728d36f99048a063","object":"chat.completion.chunk","created":1792978001,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":30591,"ts_us":1792978002375493}}

