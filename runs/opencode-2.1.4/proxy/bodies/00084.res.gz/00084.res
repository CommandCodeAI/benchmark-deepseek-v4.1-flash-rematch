data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581798042}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581798114}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Mobile","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581798139}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" fixed. Need","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581816242}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" see screenshot","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581816466}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581816583}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1j5zrlgcibva6hsvcpps1594","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581817004}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581817246}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581817303}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581817769}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581817999}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581818220}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581818407}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581818464}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581818733}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581839772}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581839815}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581839915}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581840334}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581840465}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581840586}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581840633}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"obile"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581841041}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581939045}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581939097}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581941967}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24944,"ts_us":1792977581947500}}

data: {"id":"895115e806713f2e21b1061c8fdd1c1b","object":"chat.completion.chunk","created":1792977581,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":304370,"completion_tokens":57,"total_tokens":304427,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":303488,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":24944,"ts_us":1792977581947719}}

data: [DONE]

