data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450524465}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450524541}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need build single-file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450524575}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index.html. Need inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450613164}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" workspace. We need design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450613243}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" excellent."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450613372}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450613424}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450879784}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450879896}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450879954}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974450880082}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451057730}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NG, sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451057805}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" logic head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451057871}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less-cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451057936}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able, evolution"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058012}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" genes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058082}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058148}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" neural nets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058212}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058280}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058346}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" integrated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058407}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058465}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" charts dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058531}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058809}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058874}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451058943}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We need likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451089643}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451089726}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evaluation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451091614}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451091704}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357311}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".html in working"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357384}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dir. Let's inspect."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357481}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_j75de97qimpzruibqjkn4xmq","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357555}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357620}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357683}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357745}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357842}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357905}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451357967}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358029}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358090}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358188}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358269}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358348}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358411}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358484}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358567}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358638}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358703}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358770}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358864}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451358940}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359008}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359121}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359209}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359275}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359342}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359405}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359509}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359577}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359640}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359695}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"./"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359780}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"##"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359855}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451359928}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451360078}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451360140}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451360179}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451360230}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451384566}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1086,"ts_us":1792974451384633}}

data: {"id":"2fa0f0ab00398321ebd634e149abd46c","object":"chat.completion.chunk","created":1792974450,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":5739,"completion_tokens":135,"total_tokens":5874,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":256,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":69,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1086,"ts_us":1792974451384712}}

data: [DONE]

