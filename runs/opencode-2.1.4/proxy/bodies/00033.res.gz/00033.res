data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942254003}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Who"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942254131}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"a `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942254177}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_birthOd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942317399}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ds` in current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942317483}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942317543}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942317597}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fertility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942396028}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-suppressed version"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942396092}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942396240}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We replaced,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942396390}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but grep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942473682}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942474071}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows no fertility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942474283}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Wait we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942474357}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" copied sim."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942582185}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"softcap before modifications"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942582256}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942583173}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we applied; the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942583735}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `_birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942700660}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Odds` insertion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942700721}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe didn't match"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942700830}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942700943}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differences? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942743221}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final observed event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942743288}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effects:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942743630}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942743725}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recovery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942847933}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" one gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942848107}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; indeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942848230}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fertility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942849355}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suppression absent. Let's inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942960588}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942960648}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_g1nmfdrs2bgcwg5mesywhplr","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942960709}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942960768}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942960811}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942960890}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942960946}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942960984}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942975821}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942976738}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942976800}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942976868}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942976920}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942976967}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942977021}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975942977446}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943015813}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943015899}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943015967}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943016085}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943034990}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943035472}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943035535}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943035668}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943035731}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943035770}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943036242}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943036312}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943050318}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943050476}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943050532}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943050665}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943069557}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943069631}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943069694}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943069755}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943069895}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943069987}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943070063}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943070124}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943094063}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943094117}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943094191}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943094265}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943130061}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943130108}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943130170}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943130551}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943131712}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943131937}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943132006}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943132121}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943132881}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943132984}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943133163}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943133308}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943161549}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943161658}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943161754}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"423"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943161831}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943163060}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"440"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943163111}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943163164}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943163213}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943186897}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943187131}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943187195}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943187238}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943206082}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943206133}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943206219}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943206346}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ility"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943206433}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943206508}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943206569}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943206613}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943301862}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943301954}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943302071}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2613,"ts_us":1792975943325387}}

data: {"id":"820b04c4eef2fe16f13d14eb198c4d66","object":"chat.completion.chunk","created":1792975942,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":209529,"completion_tokens":182,"total_tokens":209711,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":206976,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":77,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2613,"ts_us":1792975943325486}}

data: [DONE]

