data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100212977}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100213097}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100213176}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" forecast isn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100280846}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t visible, panel fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100281077}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100281375}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cuts after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100281696}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weather."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100367612}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Panel scroll hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100367997}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because footer at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100368117}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 740. The `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100368174}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100500597}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100500667}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"forecast` missing ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100500719}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"below scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100500776}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Need fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100547841}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100548811}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100548892}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100548949}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" responsive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100618705}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height. Maybe prioritize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100618900}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" showing forecast;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100619055}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" duplicate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100619445}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100722787}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom ledger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100723004}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100723140}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100724394}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, bottom ledger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100788101}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100788153}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" disturbance, so missing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100788225}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drawer forecast isn't fatal."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100788325}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But controls are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100899166}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clipped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100899230}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100899290}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" foot?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100899347}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actual weather controls visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100980924}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Only forecast is not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100981001}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100981052}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977100982051}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s, accessible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101028885}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101028961}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101029070}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280 still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101029188}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine. However weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101119948}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge white spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101120009}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ly grass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101120074}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101120196}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"PR? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101212896}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot appears brighter and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101212973}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" field more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101213551}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clumped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101213632}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101297452}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101297528}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It's different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101297578}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101297627}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101378982}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world aspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101379056}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed causing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101379105}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vertical stretch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101379231}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; grass appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101456317}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" taller. Fine. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101456366}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world ratio"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101456407}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 880"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101456479}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101574404}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"568"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101574456}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=1.55"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101574557}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101574652}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101629316}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101629394}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".725; grass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101629467}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stretched"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101629560}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101700400}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" major"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101700494}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nThe instrument"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101700567}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drawer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101700638}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in 1280 lacks the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101785389}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" forecast (because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101785716}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clipped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101786142}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"); could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101786217}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101885374}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101885463}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intentionally and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101885538}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" move"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101885600}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101981195}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to allow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101981267}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101981343}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977101981417}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAt 1024, layout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102059062}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102059529}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" side-by-side because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102059582}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" breakpoint at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102059912}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 980; panel "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102149138}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"306 and content "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102149192}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"123 overflow."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102149241}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102149299}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 659"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102224753}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×540"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102224818}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ratio 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102224944}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".22 huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102225921}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vertical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102320995}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stretch; creatures"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102321069}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stretch?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102321129}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102321181}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render normalized"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102401545}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" positions into canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102401626}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so vertical spacing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102402454}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stretched"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102402501}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", not body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102462500}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shapes ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102462813}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102463602}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" circles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102463645}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stay circles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102551469}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because unit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102551525}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" based"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102552518}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102552569}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cell)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102648105}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102648528}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102648606}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102648673}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aspect 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102723722}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102723956}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102724245}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".75;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102724786}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102830433}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tall."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102830498}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Looks like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102830543}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a taller"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102830580}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meadow. At "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102896558}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1024, side"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102896637}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102896695}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-side with panel maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102897310}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cramped. Could trigger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102957636}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mobile drawer at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102957734}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max-width 115"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102957774}}

data: {"id":"f62c2a18262612cedc7f63fa7f2d4ada","object":"chat.completion.chunk","created":1792977100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 instead of "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28010,"ts_us":1792977102957860}}

