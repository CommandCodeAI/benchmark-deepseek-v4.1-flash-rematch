data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976086931364}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976086931457}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" logs. sim gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976086931493}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 after 2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976086982331}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5s? Means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976086982396}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation not stepping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976086982450}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976086982577}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" debug. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087061981}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087062044}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AnimationFrame not running? Glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087062097}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"house init"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087062145}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087136198}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" App sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087136277}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 0. Scre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087136333}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enshot inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087136952}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087228301}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_uxe90aequc9d48e3rz6cttv3","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087228386}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087228455}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087228615}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087233299}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087233415}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087233481}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087234080}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087234168}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087234377}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087234500}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087234577}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087243660}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087243841}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087250491}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087250716}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087250800}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087250880}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087251093}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087251161}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087326993}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4119,"ts_us":1792976087327082}}

data: {"id":"25962db5efc8357418735c8f80b50203","object":"chat.completion.chunk","created":1792976086,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":230347,"completion_tokens":92,"total_tokens":230439,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":229888,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":44,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":4119,"ts_us":1792976087327246}}

data: [DONE]

