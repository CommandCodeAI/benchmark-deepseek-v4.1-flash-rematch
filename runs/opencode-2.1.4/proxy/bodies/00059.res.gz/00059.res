data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976670777957}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976670778041}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inserted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976670778078}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976670824562}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"T"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976670824647}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"empo perhaps at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976670824737}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wrong place? Search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976670825068}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" context"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671030550}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to confirm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671030682}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671031145}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_08ho89x07eeo0m4qaqj8b8j1","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671031256}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671031349}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671031393}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671031497}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671031569}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671031627}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671035702}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671035774}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671035909}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671035988}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036078}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036145}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036217}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036320}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036416}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036499}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036566}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036629}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036681}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036751}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671036780}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671038313}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671051677}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671051754}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671051889}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671051974}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052074}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052134}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052200}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052356}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052490}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052637}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052693}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052871}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671052939}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671053000}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671053053}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671053912}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671053982}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671054047}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671054119}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671054659}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671054730}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671054821}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671054885}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671055281}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671055337}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671055390}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671055469}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671074204}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671074242}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671074435}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671074486}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671075001}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671075242}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671075528}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671075608}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671126420}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671126478}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"empo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671126530}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671126664}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EFA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671131200}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ULTS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671131264}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671131467}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"empo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671131550}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671136136}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671136225}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671136292}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671136348}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671136550}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671136596}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671136654}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671136712}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671162034}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671162082}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671162152}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671162207}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21269,"ts_us":1792976671224814}}

data: {"id":"6b43257810e64277f2d5f15c3b6d890a","object":"chat.completion.chunk","created":1792976670,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":282135,"completion_tokens":120,"total_tokens":282255,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":277632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":15,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":21269,"ts_us":1792976671225071}}

data: [DONE]

