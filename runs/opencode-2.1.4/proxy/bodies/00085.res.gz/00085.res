data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614006881}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Mobile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614006997}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614007058}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now renders"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614064318}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614064383}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cramped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614064471}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614065384}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brand seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614158752}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614158810}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"itle vertical arrangement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614158902}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614160048}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; mast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614272729}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"head right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614272856}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614273387}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614273446}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/l"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614333028}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ive/in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614333092}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"struments;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614336971}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" subtitle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614337024}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614389372}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614389573}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 spills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614389618}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614390777}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width on second"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614487484}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614487627}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614487828}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614488281}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614558263}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614558400}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mobile, no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614558521}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614558603}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614641205}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614641273}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614641320}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614641382}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hidden forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614737727}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") but fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614737825}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The mobile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614737951}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canvas field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614738046}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614826396}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tall."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614826467}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Page body likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614826515}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrolls;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614826647}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom cut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614927424}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614927551}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; acceptable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614927901}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Header over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614927947}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614970979}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614971051}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines; perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614971108}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977614971523}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615081976}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615082223}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" required.\n\nNeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615082482}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615082751}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mobile panel screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615155724}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to ensure usable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615156112}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615156213}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_r7y917d29m07e41s13k26c5o","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615156432}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615156481}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615156562}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615156696}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615156747}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615157885}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615157972}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615158046}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615158138}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615205195}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615205418}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615205664}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615205762}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615205813}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615205989}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615206038}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"obile"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615206519}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"panel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615227775}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615227883}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615227948}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615227997}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26290,"ts_us":1792977615296769}}

data: {"id":"fb1e110e48bc6cfa81caa463776e9fcf","object":"chat.completion.chunk","created":1792977613,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":304673,"completion_tokens":154,"total_tokens":304827,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":304256,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":105,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":26290,"ts_us":1792977615297234}}

data: [DONE]

