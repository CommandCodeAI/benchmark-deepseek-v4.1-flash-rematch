data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294835971}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_k3ksvx86qkcjjhl5d1rmgblo","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294836056}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294836104}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294841502}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294841557}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294849992}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294850048}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294860813}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294860862}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294861051}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294861247}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294861656}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294861711}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294861827}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294861873}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294862256}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294862430}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294862919}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294863075}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294953836}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294953957}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6899,"ts_us":1792976294954025}}

data: {"id":"9b90fe71f4f485d2fa51eb26368e1eb8","object":"chat.completion.chunk","created":1792976294,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":255877,"completion_tokens":48,"total_tokens":255925,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":250880,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6899,"ts_us":1792976294954138}}

data: [DONE]

