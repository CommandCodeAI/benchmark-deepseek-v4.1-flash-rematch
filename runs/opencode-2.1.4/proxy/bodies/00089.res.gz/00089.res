data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768141526}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ut2bcjhsthpohutjmytf930o","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768141631}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768141676}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768168857}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768168947}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768169022}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768169097}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768180785}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768180938}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768181007}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768181168}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768209302}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768209358}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768209475}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768209743}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768209945}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768210169}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"obile"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768210385}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"panel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768210583}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768306408}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768306497}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768307261}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26367,"ts_us":1792977768315236}}

data: {"id":"efcf8912cb4740031249e63a254dbef8","object":"chat.completion.chunk","created":1792977767,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":306943,"completion_tokens":49,"total_tokens":306992,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":306816,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":26367,"ts_us":1792977768315433}}

data: [DONE]

