data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524756059}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Oops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524756163}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" duplicate drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524756201}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524780784}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (from edits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524780849}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" applied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524780904}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524780957}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524895261}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" variants) and frost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524895336}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" duplicates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524895381}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need clean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524895485}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also currentCan"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524989093}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"opy not set in record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524989886}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! We removed accidentally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524989945}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Search."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524989980}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_6prt3ps48oa8g1ho99zfat2x","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524995949}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524996283}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524996351}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975524996409}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525062284}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525062403}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525062486}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525062555}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525062603}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525062674}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525062905}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525062971}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525101450}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525101593}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525101752}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525101815}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525110283}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525110357}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525110429}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525110542}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525110640}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525110733}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525110823}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525110968}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525122774}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525122863}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525122937}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525128631}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525128773}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525128866}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525131767}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525131837}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525155888}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525156023}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525156090}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525156374}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525156592}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525164916}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525164982}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525165038}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525181658}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525181749}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525181839}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525181937}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525198718}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525198885}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525199136}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525199199}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525199380}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525199530}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525199595}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525199660}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525223544}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525223645}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525223734}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525223808}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525239839}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525239905}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Can"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525240027}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525240089}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525283874}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525284080}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525284144}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525284277}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525285199}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525285264}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525285318}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525285429}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"880"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525308025}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525308130}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"960"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525308226}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525308445}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525412594}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525412672}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525412810}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525412883}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2294,"ts_us":1792975525456366}}

data: {"id":"e90e29d840c6747c6a5dde6efd4b2f69","object":"chat.completion.chunk","created":1792975524,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":139675,"completion_tokens":139,"total_tokens":139814,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":114816,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":35,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2294,"ts_us":1792975525456595}}

data: [DONE]

