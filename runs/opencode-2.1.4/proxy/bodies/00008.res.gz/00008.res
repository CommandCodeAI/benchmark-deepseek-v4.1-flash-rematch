data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862714227}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862714291}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test with node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862714606}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862824371}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds, print"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862824456}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862824707}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", counts. Note sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862824881}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".js global in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862939786}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Node attaches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862939857}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862939959}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" globalThis; need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862940126}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" require."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862941383}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_gjnz8v701k5jp1dcjd44pnqd","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862941651}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862941700}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862942340}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862968559}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862968607}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862968713}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862968943}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862978628}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862978849}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862979174}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862979245}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862979351}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862979602}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862979724}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974862980152}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863101953}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863102046}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863102132}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863102325}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863103728}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863103809}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863103876}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863103963}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863118019}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863118099}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863118146}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863118251}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863136246}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863136357}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863136417}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863136530}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863136857}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863136928}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863136984}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863137201}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863139821}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863140020}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863140103}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863140193}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863144906}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863144957}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863144995}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863145065}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863145635}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863146502}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863146565}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863146640}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863146725}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863146775}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863146845}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863146916}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863156890}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863157004}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863157065}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863157195}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863157739}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863157821}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863157886}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863157937}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863185472}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863185552}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('./"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863185607}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863185669}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863245783}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863245864}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863245976}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seeds"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863246065}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863271305}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"619"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863271394}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"04"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863271478}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863271567}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863276674}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863276725}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863276769}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863276823}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"177"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863289862}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863289939}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863290004}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863290156}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863304953}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863305154}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863305224}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863305303}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"999"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863327434}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863327524}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863327597}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"314"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863327699}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"15"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863347431}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863347498}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863347559}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"888"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863347657}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863348368}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863348567}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863348644}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"123"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863348754}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863372373}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863372458}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863372572}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863372644}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863397421}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863397481}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863397533}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seeds"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863397637}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863429829}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863429888}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863429974}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863431373}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863446120}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863446180}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863446234}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863446344}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863471248}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863471449}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863471541}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863471652}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863492165}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863492248}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863492310}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863492411}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863492525}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863492751}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863492798}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863492944}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863544920}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863545015}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863545136}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863545195}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863563899}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"36"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863563952}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863563999}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863564043}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863610670}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863610743}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"065"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863610808}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863610854}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863611118}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863611192}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863611256}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863611300}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863630759}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863630832}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863630929}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863630995}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863642141}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863642256}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863642313}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863642495}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863678224}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863678310}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863678401}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863678499}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rec"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863686051}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863686128}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863686187}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863686251}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"records"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863705801}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863705898}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863705979}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863706111}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863738881}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863739194}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rec"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863739243}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863739330}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863739414}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rec"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863739678}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863739732}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863739771}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863756312}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863756396}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863756465}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863756541}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863769295}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863769587}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863769649}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863769791}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863793882}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863793979}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"finished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863794078}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863794142}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863816645}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863816755}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863816875}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863817053}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863835950}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863836033}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863836105}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863836234}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863856039}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863856379}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863856428}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863856542}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863880678}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863880749}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863880807}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863880904}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863902865}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863902937}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863903079}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863903464}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863921109}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863921173}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863921226}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863921335}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863921868}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863921920}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863922101}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863922157}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863955563}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863955614}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863955657}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863955707}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863959772}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863959845}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"can"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863959969}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863960015}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863960600}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863960733}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".can"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863960812}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863960874}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863985260}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863985314}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863986271}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974863986349}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864003475}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864003539}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peak"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864003618}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864003823}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864003901}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864004063}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864004109}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864004159}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peak"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864053122}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864053401}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864053489}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864053669}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864054345}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864054438}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864054532}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peak"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864054610}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864055061}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864055155}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864055230}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864055307}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864068035}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864068141}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864068237}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864068421}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864092771}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864093155}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864093249}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"irth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864093723}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864093836}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864094109}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864094196}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ills"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864094271}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864113917}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864114008}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864114087}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864114255}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864135550}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ills"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864135643}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864135857}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864135956}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864136367}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864136453}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864136534}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864136610}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" prey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864200361}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864200418}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864200473}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864200617}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864224596}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864224893}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864224942}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864225019}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"met"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864225103}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"abolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864225149}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864225585}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864225645}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"production"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864236306}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864236363}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864236404}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864236491}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864264407}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864264478}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864264606}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864264687}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864282320}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864282394}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864282445}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864282529}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864286143}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"es"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864286204}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864286250}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864286306}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864304435}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864304501}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864304545}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864304613}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864323314}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864323594}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864323676}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"±"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864323781}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864325096}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864325211}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864325423}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864325488}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864372640}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"es"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864372689}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864372745}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864372844}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"std"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864372888}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864372952}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864373133}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864373204}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864373261}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864373344}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864373398}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864373467}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864390551}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864390786}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864390840}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864391285}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864413068}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864413285}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864413344}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864413500}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864413545}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864413719}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864413790}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864413902}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864435267}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864435353}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864435449}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"met"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864435531}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"abolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864455396}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864455455}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864455505}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"production"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864455651}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864455981}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864456060}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864456141}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864456301}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864588745}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864588836}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864588910}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864588990}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864589484}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864589590}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864589664}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864589751}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"es"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864589841}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864589917}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864590014}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864590097}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864592357}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864592448}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864592520}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864592590}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864772927}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864773333}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"±"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864773401}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864773440}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864774643}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864774725}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864774798}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864787038}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"es"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864787119}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864805386}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864805476}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"std"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864805543}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864805762}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864805813}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864806258}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864806323}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864811827}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864811911}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864811966}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864815257}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864815330}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864815484}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864815569}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864815655}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864815970}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816042}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816091}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816159}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816235}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816305}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816365}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816443}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816519}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816586}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816641}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816716}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816863}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816918}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864816991}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817083}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817146}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817214}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817273}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817324}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817373}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817440}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817480}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817590}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817659}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817711}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817771}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817823}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817869}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817911}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864817971}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864818016}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864905877}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864906034}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rec"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864906134}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864906180}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".filter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864920623}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864920825}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864920879}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864920931}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864922711}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864922758}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864922816}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864922900}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864923847}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864923902}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864923951}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864924010}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864925923}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864925974}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864926022}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944236}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944303}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944364}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944439}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944513}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944622}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944701}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944768}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864944820}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864945443}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864945506}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864945593}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864945645}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864945783}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864945905}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864946004}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864946075}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864974207}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864974256}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864974305}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974864974451}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974865042449}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974865042517}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974865042700}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1902,"ts_us":1792974865046177}}

data: {"id":"e38413ff91494df76d37cb2b9253eeb1","object":"chat.completion.chunk","created":1792974862,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":59742,"completion_tokens":512,"total_tokens":60254,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":50176,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":26,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1902,"ts_us":1792974865046844}}

data: [DONE]

