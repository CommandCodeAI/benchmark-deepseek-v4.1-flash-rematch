data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048523107}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_uwvvkvu59gb2zvslo4brls9g","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048523202}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048523270}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048537810}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048537877}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048538028}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048538289}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048637384}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048637701}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048637768}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048638655}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048652373}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048652435}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048652700}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048652766}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048653500}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048653640}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048653959}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048654125}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048664490}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048664536}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048664584}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048664642}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048672236}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048672289}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048673452}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048673508}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048673560}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048674972}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048675049}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048675104}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048677538}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048677604}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048677653}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048677822}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048683038}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048683465}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048683533}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048683599}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048686903}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048686966}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048687283}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048687335}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048687556}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048687655}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048687729}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048687884}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048782313}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048782638}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048782733}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048783104}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048783215}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048783299}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048784000}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048784123}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048784217}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048784348}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048784463}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048784630}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048784830}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048784926}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048785011}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048785092}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048788445}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048788934}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048789019}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048789098}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048789735}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048789817}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048789909}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048790055}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sync"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048832039}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048832128}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048832208}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048832374}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048835739}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048835844}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048835960}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048836166}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048861956}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048862054}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048862135}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"size"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048862210}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048862286}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048862361}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048862459}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048862561}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"external"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048903272}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048903400}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048903482}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048903557}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048927947}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"href"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048928029}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048928251}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048928316}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048928887}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048928976}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048929046}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048929235}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048949851}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048949938}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048950002}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048950067}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048983040}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048983125}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"random"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048983197}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978048983550}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049006450}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".includes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049006516}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049006568}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049006613}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".random"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049151250}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049151355}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049151446}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"place"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049151517}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"holders"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049151848}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049151925}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049152006}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".match"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049152062}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049176840}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049176974}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049177065}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049177136}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-Z"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049177205}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049177275}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049177344}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049177446}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049248381}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049248442}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049248564}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049248908}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29605,"ts_us":1792978049351685}}

data: {"id":"159158590407d319c831958c2af022f0","object":"chat.completion.chunk","created":1792978048,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":308876,"completion_tokens":158,"total_tokens":309034,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":308736,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":29605,"ts_us":1792978049352080}}

data: [DONE]

