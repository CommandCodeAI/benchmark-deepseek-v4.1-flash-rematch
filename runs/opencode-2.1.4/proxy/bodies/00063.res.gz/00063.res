data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976797966065}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976797966145}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976797966190}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": The world becomes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798051335}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ochre/d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798051626}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ry, field shr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798051665}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inks, banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798051884}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Looks nice. Issues"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798131383}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Weather panel active forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798131460}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at bottom says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798131565}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Drought holds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798131996}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the glass\"; good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798204979}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798205348}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"drought\" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798205396}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798205614}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-sub"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798303194}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798303278}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is tiny and same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798303387}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" color. Fine.\n- Timeline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798303452}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mini chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798392733}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798392785}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" big green shape"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798392821}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798392877}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798458636}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798458705}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798458765}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Nice.\n- Header gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798458864}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798533904}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"05 while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798534062}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner says drought gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798534297}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"04. fine ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798534570}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"active).\n- The event announcement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798640165}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has impact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798640649}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798641333}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"opy cut by 73%\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798641958}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on the right,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798712973}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798713278}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner fits.\n- Population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798713495}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798713889}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count 232 but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798804484}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798804806}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798805127}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not.\n- Main field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798806507}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798869984}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought is very sparse and gold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798870062}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", effective"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798870104}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- However at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798870163}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798970423}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", simulation is fast;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798970634}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visuals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798970772}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still meaningful.\n- Top \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976798970938}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"TEM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799054384}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"PO"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799054454}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799054507}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" active but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799054559}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799154615}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tiny."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799154986}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- \"L"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799155044}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVE\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799155186}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" status at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799219284}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799219430}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- World"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799219487}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has a glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799219587}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" light"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799300360}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799300651}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much. \n- The responsive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799300753}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799300925}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 1440 is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799389688}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compelling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799389780}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPotential"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799389846}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue: Default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799389909}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799464441}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799464788}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799464871}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799464998}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799558809}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6s. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799558867}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s a nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799558913}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799559056}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799633643}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799633721}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 86"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799633765}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. There"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799633816}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s speed control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799716898}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799717014}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8x.\n- Could set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799717112}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default 4× to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799717853}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show drama"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799804174}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799804405}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. But the initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799804476}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799804674}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799867674}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is appealing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799867734}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and event at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799867810}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10s not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799867867}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bad"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799966464}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". User can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799966519}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799966714}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm.\n\nNeed view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976799966914}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032018}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032080}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_q10hg10tqhs7s334le1c6rr4","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032162}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032232}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032282}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032392}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032461}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032506}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032572}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032628}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032662}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800032703}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800048384}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800048489}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800048916}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800049028}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800079318}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800079415}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800079480}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800079554}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800087142}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800087218}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800087280}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800087324}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19149,"ts_us":1792976800152216}}

data: {"id":"6f525e1a0168a773c7833edb105b49df","object":"chat.completion.chunk","created":1792976797,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":286031,"completion_tokens":337,"total_tokens":286368,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":284160,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":287,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":19149,"ts_us":1792976800152413}}

data: [DONE]

