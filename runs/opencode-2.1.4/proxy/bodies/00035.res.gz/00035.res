data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965262997}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965263161}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with fertility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965263207}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suppression, events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965351689}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965351809}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965351910}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965352010}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s and population trends."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965352432}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965352510}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction. Some final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965352568}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965352622}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965416249}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"19"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965416558}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") but fine. Cur"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965416665}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ves have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965416749}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965538278}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"180. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965538432}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBut event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965538955}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" types for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965539050}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 1065 start drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965579644}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965579898}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4, frost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965579995}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965580072}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plague16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965657067}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", frost22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965657251}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", drought28, frost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965657454}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"34;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965657596}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965778428}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plague."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965778546}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965778612}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ague at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965779511}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16. That's okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965832153}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Tail final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965832220}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965832269}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"165/26 maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965832306}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965911115}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dramatic than"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965911255}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1007"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965911619}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975965911687}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966096642}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1065; has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966097379}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canopy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966097436}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 27"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966097502}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966260863}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" varied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966260921}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Peak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966260970}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966261068}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"271. Should look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966310599}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966310923}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can choose seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966310988}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966311027}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with final "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966340061}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"150/43 and event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966340251}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" f4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966340561}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",d10,p16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966340607}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966377121}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"22,f28,d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966377188}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"34; dynamic 181"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966377398}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966377448}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966467645}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 42 tr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966467792}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivially simple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966467903}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Seed 1065"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966469158}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966562018}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" archival"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966562293}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" number."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966562331}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use 1065."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966562503}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \nCould set initial pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966661527}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run `sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966661793}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".st"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966661871}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ep` zero? Start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966662037}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with full populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966727016}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 168"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966727185}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/24. Scre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966727266}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enshot at 1s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966727587}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966809230}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966809326}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") gets "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966809477}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"264/50?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966809588}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966967640}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" base "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966967794}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20 tempo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966967851}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2=40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966968431}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966996246}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ps, generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966996393}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 96 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966996467}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" =2.4s."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975966996730}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At 1s still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967081010}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967081088}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967081308}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 230"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967081385}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? In stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967161885}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967161949}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967162010}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen1 "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967162302}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"264"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967271361}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967271474}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967271846}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"odes from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967271908}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 168 to ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967400016}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"264 quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967400160}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967400257}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial design should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967400842}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967441947}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967442045}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" creatures"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967442239}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967442914}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967524485}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5s, maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967524541}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967524670}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967524806}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967611586}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 ticks."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967611633}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967612617}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967612667}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967686637}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Need first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967686711}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967686763}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967686870}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967778853}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9.6s. If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967778982}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967779091}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evaluation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967779286}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967868569}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5s no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967868769}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event, but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967868812}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n\nWe should maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967869793}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967963877}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967963972}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967964088}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975967964190}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968055299}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events quicker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968055385}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968055460}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968055534}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evaluate.\n\nSim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968137808}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issues"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968137944}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968138038}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968138115}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968247577}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968247701}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be 1065"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968247980}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968248143}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6. currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968331789}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constructor default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968331927}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 61904"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968332083}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? We need change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968335625}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968464255}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1065. It may still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968464358}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default 61904"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968464940}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968464995}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968528462}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rcstp3f6wkacj5fwasipgy3s","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968528608}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968528879}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968529305}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541090}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541171}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541241}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541302}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541380}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541439}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541483}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541545}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541688}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541767}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541877}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968541968}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968574721}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968574782}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968575055}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968576919}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968600032}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968600103}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968600189}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968600321}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968600614}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968600861}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968601255}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968601438}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968601560}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968601693}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968601804}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968602107}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968624668}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968624888}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968624979}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968625093}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968639363}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968639544}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968639631}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968640181}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968640270}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968640376}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968640625}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968640756}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968657826}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968657928}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968658061}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968658242}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968680319}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968680464}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968680624}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968680706}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968681035}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968681150}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968681503}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968681802}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968705723}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968705785}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968705881}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968705933}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968729459}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968729754}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968729811}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"options"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968729920}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968745125}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968745220}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968745284}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968745590}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968800373}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968800458}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968800554}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968801176}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Can"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968820384}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968820528}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968820899}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" canopy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968822120}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968836762}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968836889}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Bag"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968836960}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968837243}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968837462}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968838019}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968838077}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968838143}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968863669}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968863793}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968863942}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968864038}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968882331}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968882400}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"148"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968882466}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968882630}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"158"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968906283}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968906384}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968906461}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968906965}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968923188}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968923269}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968923344}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968924461}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968941007}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968941304}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"896"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968941539}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968941649}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"922"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968941869}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968941935}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968941985}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975968942395}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975969022334}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975969022479}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2377,"ts_us":1792975969022540}}

data: {"id":"89ec4de969709f164cbb0217cddab27a","object":"chat.completion.chunk","created":1792975964,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":212217,"completion_tokens":528,"total_tokens":212745,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":210048,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":391,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2377,"ts_us":1792975969023221}}

data: [DONE]

