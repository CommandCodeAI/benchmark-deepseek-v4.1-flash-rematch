data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950471064}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950471187}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950471234}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950556406}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950556609}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many but both populations pe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950557979}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gged caps. Need slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950558064}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950769015}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950769120}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lot and/or reduce caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950769460}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950769516}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"crease mortality. Why prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950786205}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hits 420 in 3 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950786539}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950786612}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950786672}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3.5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950879882}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k over run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950879955}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but cap early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950880013}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950880070}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"168 initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950944411}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", doubling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950944690}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950944825}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974950945099}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951031386}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951031463}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951033567}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951033629}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951108168}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cooldown "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951108378}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"34 + maturity 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951108635}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plus ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951108853}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"illing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951210222}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951210501}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951210596}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every 50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951210798}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks, so huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951330015}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need stronger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951330113}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constraints"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951330172}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and predation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951330232}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPredators at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951438679}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 80 with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951438746}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24 start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951438804}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951438863}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951482601}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951482671}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" perhaps lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951482724}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951482777}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951603469}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951603537}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rates. Caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951603599}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mask"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951603656}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Set prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951644949}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 320"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951645422}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951645489}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951645650}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951733587}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"55. But charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951733659}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951733720}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Better dynamic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951733775}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNatural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951814000}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" selection would favor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951814090}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951814147}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction, so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951814203}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951919120}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951919197}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resource"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951919256}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limits; that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951919310}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s realistic."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951972630}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951972699}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951972750}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evolution"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974951972802}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mainly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952038492}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952038576}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952038635}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952039799}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952125899}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952126116}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dependence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952126243}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and stochastic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952126503}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952227632}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Introduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952227718}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952227784}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952227835}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952314860}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952314935}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952314989}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952315036}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952392135}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952392374}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952392453}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" depleted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952392637}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952466184}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds 42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952466294}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc canopy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952466447}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remains "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952466559}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"45% because prey population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952565326}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952565394}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952565432}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" balanced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952565644}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952676806}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952676885}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limiting. Lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952677594}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952677640}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" allow."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952722613}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952723044}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators pe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952723122}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gged means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952723176}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey limit?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952849768}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952849818}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey pe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952850202}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gged too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952850268}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can reduce caps to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952907138}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952907220}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952907264}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952907325}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952999544}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952999613}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" animals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952999661}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" die of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974952999745}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" old"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953102439}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age more,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953102525}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" creating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953102594}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" turnover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953102737}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953203630}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fluctuations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953203717}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Lif"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953204403}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"es"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953204477}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pan 920"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953310257}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953310370}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953310522}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953310633}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"456 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953331046}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953331293}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953331342}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 420 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953331615}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deaths from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953593611}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953593692}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953593746}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953593803}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5k over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953658608}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953659251}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.73"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953659311}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick. Old age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953659576}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953705876}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" To maintain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953705945}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953706030}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap, death"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953706242}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953732159}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" match birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953732271}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953732412}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators at cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953734685}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953778780}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate becomes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953778911}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limited by cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953779043}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953779385}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953857115}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remove cap,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953857220}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953857274}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953857325}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953956862}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953956944}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953956997}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974953957068}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canopy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954070571}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954070643}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"45% for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954071561}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954071626}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954136376}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954136531}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yet,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954136657}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954137120}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954198352}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limited by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954198420}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" something"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954199534}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954199610}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954295224}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954295992}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"45% with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954296059}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constant;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954296113}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954490871}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capped."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954491111}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Remove"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954491305}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap will cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954491578}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food depletion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954567281}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954567366}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954567463}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954567551}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954593584}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWe can let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954593637}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954593695}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" beyond "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954593757}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"420 and "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954642422}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"80 and see"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954642498}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954642603}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe use cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954642657}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 800/160"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954734366}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" just safety"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954734428}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; simulation performance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954734514}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954734767}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 800. Let's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954808106}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954808178}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remove caps high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954808226}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954808298}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" see dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954893204}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954893371}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954893967}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974954894043}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" agents fine. Set cap prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955018274}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 900, pred 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955018403}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Test."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955018530}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_9fxl1ah1s66u61n3econztr3","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955018652}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955018763}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955018837}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955019230}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955019361}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955019539}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955019623}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955019701}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955020117}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955059469}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955059620}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955059667}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955060129}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955078945}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955079023}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955079097}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955079165}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955096462}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955096547}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955096600}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955096695}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955116816}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955116940}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955117269}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955117330}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955117485}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955117836}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955117891}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955118023}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955129532}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955129609}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955129661}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955129776}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955147741}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955148308}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955148376}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955148447}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955148507}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955148578}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955148663}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955148732}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955196027}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955196130}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955196189}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955196247}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955209224}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955209311}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955209387}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955209510}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955210858}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955210974}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955211072}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955211190}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955228983}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955229071}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955229133}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955229269}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955231859}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955231947}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955232014}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955232175}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955232516}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955232649}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955232723}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955232765}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955251838}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955252325}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955252377}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955252428}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955319786}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955319954}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955320003}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955320072}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955320975}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955321035}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955321089}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955321139}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955323011}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955323266}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955323326}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955323394}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955328482}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955328542}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955328587}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955328649}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955328716}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955328770}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955328809}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"420"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955328856}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955336523}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955336753}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955336810}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955336870}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955352307}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955352407}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955352503}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955352661}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955375167}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955375238}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955375302}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955375436}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955397672}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955397736}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955397787}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955397880}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955398431}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955398588}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955398673}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955398721}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955424425}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955424499}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955424541}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955424677}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955440747}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955440805}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955440876}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955440952}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955479562}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"220"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955479646}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955479709}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955479791}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955480075}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955480150}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955480209}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955480245}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955525445}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955525544}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955525620}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955525690}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955542953}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955543113}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955543240}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955543541}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955588566}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955588672}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955588787}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955588883}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955589195}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955589286}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955589359}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955589513}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955616102}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955616206}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955616432}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" _"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955616519}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mut"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955650728}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955650820}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955650906}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955651077}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955653236}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955653305}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955653387}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955653465}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955674378}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955674678}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955674762}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955674805}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955697687}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955697766}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955697837}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955697897}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955698036}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955698187}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955698269}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955698426}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955731026}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955731890}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955731965}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" _"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955732029}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mut"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955740508}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955740605}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955740689}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955740808}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955740872}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955741863}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955741962}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955742028}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955762978}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955763090}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955763161}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955763231}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955779648}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955779727}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955779868}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955780089}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955801677}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955801753}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('./"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955801880}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955801955}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955826057}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955826145}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955826215}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955826280}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955826365}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955826468}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955826555}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955826630}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"619"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955891702}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"04"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955891927}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955891992}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955892060}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955903730}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"177"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955903824}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955904068}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955904134}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955915580}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955915668}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955915758}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"999"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955915887}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955916828}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"314"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955918175}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"15"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955918281}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955918349}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955929174}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955930146}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955930565}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955930654}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955930804}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955930872}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955930941}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955930997}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955953675}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955953900}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955954019}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955954175}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955977101}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955977184}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955977232}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955977437}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955978169}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955978287}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955978360}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955978522}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955998902}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955998985}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955999054}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974955999399}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"36"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956015486}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956015544}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956015600}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956015652}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956064538}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"065"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956064603}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956064645}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ood"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956064698}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956064848}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956064939}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956065006}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956065079}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956074869}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956074957}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956075096}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956075216}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956095206}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956095328}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956095481}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956095562}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956095733}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956096083}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956096155}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956096223}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956118910}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956119037}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"records"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956119117}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956119236}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956139152}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956139237}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956139385}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956139785}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956139865}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956139923}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956140134}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956140215}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956167019}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956167097}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956167168}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956167336}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956191023}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956191198}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956191290}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956191357}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956208258}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956208353}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956208430}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956208586}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956208992}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956209066}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956209174}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956209255}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956237202}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956237294}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956237400}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956237537}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956246370}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956246441}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956246505}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"can"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956246558}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956246978}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956247168}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956247227}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".can"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956247352}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956280327}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956280415}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956280472}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956280517}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956298216}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956298343}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956298442}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peak"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956298536}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956381746}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956381817}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956381966}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382123}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382186}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peak"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382331}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382413}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382491}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382669}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382754}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382835}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956382912}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peak"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956383042}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956383102}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956383170}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956383251}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956383326}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956383694}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956383762}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956383826}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956396075}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956396157}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956396276}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"irth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956396370}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956396436}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956396493}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956396650}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ills"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956396713}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956397436}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956397510}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956397582}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956397650}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956414478}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ills"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956414592}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956414673}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956414795}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956468083}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956468294}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956468352}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956468457}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956477514}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956477604}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956477669}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"records"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956477733}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".filter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956489992}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956490159}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956490230}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956490338}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956490518}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956490703}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956490763}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956490828}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956502357}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956502432}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956502495}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956502704}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956515823}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956515894}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956515941}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956516034}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956516242}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956516303}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956516349}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956516421}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956536879}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956537060}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956537188}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956537282}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956550065}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956550214}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956550268}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956550414}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956551100}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956551215}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956551492}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956551566}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956571730}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956571818}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".can"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956571891}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956571954}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956590782}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956590862}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956590935}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956591001}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956591962}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956592082}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956592135}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956592202}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956614697}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956614763}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"N"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956614828}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ODE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956614876}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956700104}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2284,"ts_us":1792974956700219}}

data: {"id":"e9323f148ff341df02155d545dc5f642","object":"chat.completion.chunk","created":1792974950,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":69728,"completion_tokens":875,"total_tokens":70603,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":64512,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":445,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2284,"ts_us":1792974956700510}}

data: [DONE]

