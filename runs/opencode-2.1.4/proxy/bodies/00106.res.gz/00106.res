data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479358491}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479358640}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe validate that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479358687}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim source"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479443264}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in index"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479443403}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actually latest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479443482}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479443569}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479541630}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1065 and corrected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479541725}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479542050}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479542141}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We did."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661133}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could search snippets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661255}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661389}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yslcstkmd9iooi96o2f6sj2w","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661485}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661671}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661745}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661807}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661911}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479661976}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479662046}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479663413}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479663486}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479663576}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479663700}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479663780}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479663940}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479723231}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479723337}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479723465}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479727204}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479727298}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479727398}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479727473}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479727534}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479734820}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479734886}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479734977}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479735050}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479745238}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479745332}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479745419}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479746243}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479746395}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479746512}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479746597}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479746668}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479790252}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479790354}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479790407}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479797341}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479806629}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479806686}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479806760}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479806895}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479834594}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479834673}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479834725}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479834777}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479860017}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479860212}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479860278}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479861114}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479881457}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479881847}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479881922}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479883325}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479883394}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479883463}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479883531}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479883594}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479946503}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479946559}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(options"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479946684}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479946739}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479979414}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479979521}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479979705}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978479979791}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480003602}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480003679}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480003747}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480003881}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480052887}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480052947}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480053009}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480053119}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480053196}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Od"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480053396}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ds"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480053450}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480053649}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480108136}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Weather"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480108338}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480108391}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480108640}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480109798}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480109935}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480110019}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480110130}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"15"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480162802}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480162897}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480163055}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480163280}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480179817}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480179871}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480179936}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480180022}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":29230,"ts_us":1792978480279657}}

data: {"id":"de6082fe3df9d7f9f1ec7b3ec8644fc9","object":"chat.completion.chunk","created":1792978479,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":311514,"completion_tokens":148,"total_tokens":311662,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":311424,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":27,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":29230,"ts_us":1792978480280792}}

data: [DONE]

