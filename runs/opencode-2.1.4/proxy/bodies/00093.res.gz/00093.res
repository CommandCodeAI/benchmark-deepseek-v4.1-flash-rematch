data: {"id":"0b06cfb60f47b7655b8b9f6d7384e116","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28865,"ts_us":1792977912505992}}

data: {"id":"0b06cfb60f47b7655b8b9f6d7384e116","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28865,"ts_us":1792977912509527}}

data: {"id":"0b06cfb60f47b7655b8b9f6d7384e116","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"The","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28865,"ts_us":1792977912509574}}

data: {"id":"0b06cfb60f47b7655b8b9f6d7384e116","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" field looks lush","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28865,"ts_us":1792977912548186}}

data: {"id":"0b06cfb60f47b7655b8b9f6d7384e116","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" but","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28865,"ts_us":1792977912548688}}

data: {"id":"0b06cfb60f47b7655b8b9f6d7384e116","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" still overly","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28865,"ts_us":1792977912548738}}

data: {"id":"0b06cfb60f47b7655b8b9f6d7384e116","object":"chat.completion.chunk","created":1792977912,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" regular","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28865,"ts_us":1792977912549021}}

