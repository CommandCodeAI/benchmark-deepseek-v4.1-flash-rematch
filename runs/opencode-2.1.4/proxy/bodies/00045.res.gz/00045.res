data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240217759}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240217839}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240217867}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 657 vs client 653"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240288553}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", only 4px cut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240288640}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Great. Need maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240288697}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240288743}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" padding; currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240372166}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240372217}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240372349}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plus "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240372561}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"11 padding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240470235}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Forecast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240470291}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240470531}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible; scroll "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240471086}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4px. Fine. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240589887}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s see screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240590082}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_3p6g0lnzdygzti844noo561p","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240590273}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240590398}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240590623}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240590761}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240591072}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240591184}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240591630}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240591750}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240592085}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240592204}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240592583}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"encode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240622704}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240622756}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"glass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240622797}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"house"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240627712}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240627828}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240627894}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240628038}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240691559}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240691783}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4474,"ts_us":1792976240691893}}

data: {"id":"661ee7e0c03c6e0098d60cfc73ac26fa","object":"chat.completion.chunk","created":1792976240,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":250074,"completion_tokens":97,"total_tokens":250171,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":244352,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":49,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":4474,"ts_us":1792976240692121}}

data: [DONE]

