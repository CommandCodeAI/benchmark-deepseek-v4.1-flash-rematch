data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584050904}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584050993}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser binaries elsewhere."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584051029}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584094391}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright install` would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584094820}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network perhaps; maybe browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584094887}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" available in /m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584094927}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"nt. Check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584136311}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_kpam1nlzk0szae5c057mncls","type":"function","function":{"name":"shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584136395}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584136472}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584136928}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584154701}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584154986}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584155055}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584155388}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584173627}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584173747}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584173812}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584174109}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584185756}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584185808}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584185969}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584186811}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584186866}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584187037}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584188169}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584188444}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584205617}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584205679}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584205911}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584205959}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584228450}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584228666}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584228986}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584229056}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584246567}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584246648}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584246715}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584246782}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584246844}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584246970}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584247061}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584247154}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584267119}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584267173}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584267247}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584267477}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584306312}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584306590}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584306666}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584306721}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584307801}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584307918}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584308097}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584308255}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584308668}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584308713}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584308937}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584309140}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584320753}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584320830}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584320890}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584320938}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584341986}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584342063}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584342302}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584342374}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584368015}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584368108}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584368224}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ills"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584368281}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ex"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584384727}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584384801}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584384855}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584384951}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584444835}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584444905}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584444968}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584445037}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1087,"ts_us":1792974584478598}}

data: {"id":"32aef835f150c38b8d0481317014c8f8","object":"chat.completion.chunk","created":1792974583,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":20612,"completion_tokens":123,"total_tokens":20735,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":20352,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":24,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1087,"ts_us":1792974584478882}}

data: [DONE]

