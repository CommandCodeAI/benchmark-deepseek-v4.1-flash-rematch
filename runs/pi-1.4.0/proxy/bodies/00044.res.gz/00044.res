data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020834607}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_3m4vwc4n8jpq9szwm5zb875n","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020834778}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020834868}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020862714}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020862862}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020863440}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020863841}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020900732}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020900873}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020900972}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020901176}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020904159}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020904382}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020904571}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020906193}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020986070}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020986303}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":17296,"ts_us":1792975020986430}}

data: {"id":"a46ae19e5a65249daaaf81a490a7f4f0","object":"chat.completion.chunk","created":1792975020,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":230047,"completion_tokens":44,"total_tokens":230091,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":228992,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":17296,"ts_us":1792975020986713}}

data: [DONE]

