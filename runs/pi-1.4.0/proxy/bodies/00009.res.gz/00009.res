data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842272287}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842272563}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but prey still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842272653}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842353548}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842353783}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842353834}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then plant crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842353978}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predators mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842429571}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" die"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842429697}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842429876}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" one seed surviving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842430108}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842505482}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resilience"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842505585}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plant crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842505718}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842505900}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5-8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842572020}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" triggered by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842572207}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842572264}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842572378}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842654074}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen5, removes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842654181}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842654449}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduces"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842654573}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth, while prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842733819}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already 400."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842733962}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That causes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842734211}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842734348}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But we want"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842803640}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842803755}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fewer prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842803956}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and robust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842804179}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators.\n\nLet's think"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842876789}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" about carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842876911}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842877039}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842877151}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant 484"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842951329}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, prey "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842951423}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"42,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842951485}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973842951554}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick. Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843039332}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y pop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843039604}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843039862}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 400 by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843039908}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen5, eats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843155857}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843156882}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Food growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843156944}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can't sustain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843157006}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843217337}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843217616}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" level"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843217666}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? They consume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843217798}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" standing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843313523}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stock then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843313605}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843313714}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could reduce prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843313907}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843408190}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843408351}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843408439}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by reducing reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843408963}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843501944}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843502096}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cooldown, or introduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843502269}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843502472}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth stronger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843567369}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843567489}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" higher"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843567619}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843567774}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843641262}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick=360/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843641375}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Each prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843641568}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843641675}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843742439}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843742563}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843742942}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food consumption maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843743066}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6 plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843830622}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843830713}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843830788}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843830858}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843915220}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843915526}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843915715}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ability"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843915890}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843999655}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is one per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843999717}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9 ticks; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843999764}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973843999834}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844078479}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844078563}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". To support"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844078783}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400, need plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844079020}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844154959}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844155200}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844155309}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"33/tick. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844155454}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase plant reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844272594}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth factor 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844272646}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"x. Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844272773}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844272991}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844352504}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1000 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844352553}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844352675}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844352888}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" animals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844425936}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can't"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844425979}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844426221}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844426267}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due handling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844499771}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844499820}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so food still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844499927}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" de"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844499978}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pletes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844747769}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe plant growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844747838}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should be much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844747911}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster but space"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844747968}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844799349}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Current cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844931822}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 84"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844931887}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%. If growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973844931937}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 33"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845024045}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick, plants would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845024121}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly fill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845024184}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845024233}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can maintain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845025368}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But then prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845025425}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845025476}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845025521}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845027050}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845027112}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845027181}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845027207}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845027782}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845027871}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" de"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845027940}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"plete? Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845028026}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845125008}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845125158}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grasslands"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845125599}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845125713}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" turnover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845178797}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845180642}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845180704}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"216"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845180771}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"00 cells; target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845373534}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coverage 84"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845373618}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845373753}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18k plants. A prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845374097}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can eat every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845464449}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9 ticks;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845464559}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845464689}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey ->44"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845464809}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants/tick consumed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845481217}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845481350}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845481550}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845481739}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrowth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845500818}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845500985}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >44"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845501232}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845501320}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" support"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845575636}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845575698}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"400, impossible if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845575827}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrowth default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845575883}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1 ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845670209}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 33/tick maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845670280}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845670389}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could increase default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845670511}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845736419}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845736553}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845736707}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845736773}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm.\n\nAlternatively reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845816450}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eating rate drastically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845816779}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (cooldown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845816845}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20 ticks) so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845816976}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845893351}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consume ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845893703}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20/tick. And"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845894097}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845894171}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845984200}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"15/tick. This creates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845984667}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium at more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845984759}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reasonable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973845984824}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations. But what"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846060246}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846060398}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" desirable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846060440}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846060549}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count? 200 maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846153365}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846153418}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846153454}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846153594}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nThe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846232832}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fundamental"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846232983}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue: prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846233211}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pop grows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846233285}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from 42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846300010}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846300101}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846300245}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" decline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846300400}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from 480"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846359817}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 to 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846360080}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". With fewer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846360144}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846360263}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846458703}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846458973}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846459225}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" settle. Let's set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846459275}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846522794}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846522864}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846522936}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846522996}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846619541}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 70 maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846619599}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But evolution"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846619647}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846619732}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We want dramatic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846802584}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but not extinction. Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846802855}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846802918}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846803749}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846819407}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846819613}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n\nA robust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846819680}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846819774}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846902051}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" an explicit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846902127}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"car"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846902273}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rying capacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846903176}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846958841}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846959145}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from fixed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846959255}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" territories"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973846959355}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847060575}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g.,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847060678}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847060762}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pressure. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847060831}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847168756}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" natural:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847168849}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847168921}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847168992}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" requires"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847231564}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847231672}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" just energy but a \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847234567}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847234648}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" site"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847296915}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847297030}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" safety"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847297138}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with local plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847297229}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847360397}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847360666}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density-dependent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847360792}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847360944}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847442600}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" *="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847442887}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847442955}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847443342}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847524585}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847524688}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847524824}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" * clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847525017}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847648549}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847648716}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FoodNear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847648773}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"by -"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847648867}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847692807}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")/...)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847693188}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could drastically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847693271}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce reproduction when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847693337}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847771390}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants scarce,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847771457}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preventing overs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847771523}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hoot. Each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847771659}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey checks local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847848260}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847848325}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847848365}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847848416}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if fewer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847939121}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" than 2 plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847939237}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847939490}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance zero"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973847939566}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848075232}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" natural:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848075322}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848075389}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848075461}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but no habitat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848163804}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848164026}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848164103}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848164263}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848197646}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848197709}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848197945}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add \"the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848198013}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meadow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848471507}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848471730}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ists\". Another"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848471790}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mechanism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848471918}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": juvenile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848489170}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" starvation no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848489402}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe implement a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848489444}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"condition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848489507}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848503939}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848504113}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848504298}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after handling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848504521}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848541703}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848541768}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are depleted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848541837}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848541909}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash, they should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848643601}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848644062}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproducing, then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848644132}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deaths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848644191}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848727856}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations down. The delayed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848727927}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" response"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848728026}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848728146}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848849978}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848850047}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already stores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848850094}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848850130}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848984304}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a minimum"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848984372}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848984559}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant density. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973848984609}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849013930}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849014028}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849014145}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if local plants within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849014555}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849173659}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849173750}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849173838}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? In scarce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849173909}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" environment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849192038}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" none"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849192314}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This prevents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849192364}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849192588}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in barren"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849277053}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" areas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849277371}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849277429}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849277562}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Add a hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849336820}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" global \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849336994}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849337185}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"zer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849337317}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carrying capacity\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849521506}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from available"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849521797}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant coverage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849521845}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849521901}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" repro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849551002}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance *="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849551325}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clamp(plantCover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849551526}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"age/0.25,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849551614}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.05"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849616869}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",1). When plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849616914}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849617089}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849617132}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%, reproduction stops. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849763109}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849763205}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kind of natural:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849763334}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" famine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849763513}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849781142}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849781220}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", no births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849781292}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849781386}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survive on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849857352}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stored energy and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849857740}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" die. Population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849857813}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" decline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849857886}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849927582}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849927896}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recover."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849927987}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This yields"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849928195}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" oscillations not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849985075}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" full extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849985159}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The prey crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849985473}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973849985540}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850073330}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because plants at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850073400}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 61"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850073541}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and no food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850073638}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850149435}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850149506}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850149665}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash sooner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850149719}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", they'd stop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850242779}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproducing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850242883}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850243099}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850243153}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20%, leaving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850335281}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850335405}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and fewer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850335510}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mouths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850335612}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850408126}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850408173}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850408252}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scaled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850408462}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by plantCover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850523769}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"age maybe not enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850523820}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because at 480"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850523965}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850524039}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800 still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850587397}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850587493}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%. \n- Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850587540}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" animal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850587685}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850676503}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850676608}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850676669}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" condition.\n\nPred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850677110}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators similarly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850750808}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850750908}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to reproduce. Their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850751068}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850751162}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scaled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850856286}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by prey availability? Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850856403}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850856576}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850856621}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850909479}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if prey count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850909621}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850909737}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973850909921}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not needed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851019383}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe make predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851019463}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a lot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851019535}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more effective"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851019608}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" such"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851083377}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that they check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851083476}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey before over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851083618}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851083792}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Their initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851160771}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numbers 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851160863}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851160953}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851161154}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851250434}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851250501}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" successful"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851250561}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Currently predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851250623}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851316816}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851316889}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 25, gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851316986}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851317111}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851400434}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851400705}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12/8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851400795}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851400887}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" even"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851497593}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851497670}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851497722}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why? Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851497767}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851567672}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" struggle to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851567722}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch prey (birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851567853}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851567989}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20 over 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851664918}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens), and star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851664976}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve. We need make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851665036}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pred hunting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851665105}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more effective"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851757677}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851757776}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction easier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851757833}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851757890}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they can keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851816916}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851817108}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check. Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851817294}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851817339}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851877811}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851877863}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851877907}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" isn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851877980}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t limited for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851956040}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators. Why don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851956113}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t they reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851956268}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Perhaps movement search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973851956370}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852032158}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or predators target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852032279}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852032378}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852032497}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t catch."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852166735}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852166797}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s 20 across"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852166854}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852166897}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens is low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852194142}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852213124}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852213211}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18 predators need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852213265}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852287596}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births to maintain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852287715}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852287896}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They should be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852288015}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catching"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852355290}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852355343}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852355482}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s intro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852355803}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"spect one run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852453505}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to see predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852453641}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852453691}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852453743}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852572833}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births. Maybe prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852572951}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852573082}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every time, so predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852573172}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" never"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852632378}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch. Because prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852632625}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852632791}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" approx"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852633114}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852705158}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852705264}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852705631}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators also vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852705737}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~8. They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852792481}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chase but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852792645}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey speed roughly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852792756}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852792928}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so cannot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852866546}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" close"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852866697}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852866818}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" newborn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852866954}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852962297}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"low prey caught"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852962474}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predator must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852962771}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973852962876}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853048984}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853049069}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ambush. We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853049137}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can grant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853049218}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator l"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853142801}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"unge speed ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853142918}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.4 or higher"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853143113}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853143225}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Current pos `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853221437}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"moveAnimal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853221503}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` uses step"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853221550}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853221625}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed*f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853351106}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actor for predator."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853351820}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853351861}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y flee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853351936}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853401419}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed*1.08. Speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853401526}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gene ranges"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853401687}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853401731}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853506438}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6 vs prey max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853506522}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.05; initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853506603}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853506877}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853587789}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Predator speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853587900}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.14 multiplier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853587956}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" offsets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853588005}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial average"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853703440}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" genes .56"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853703557}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -> speed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853703671}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853703717}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853800533}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s compute pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853800585}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed: ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853800627}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"55+.56"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853800710}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853899263}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".05=1.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853899328}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; prey speed .42+.48"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853899436}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*1.63"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853899495}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=1.2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853934820}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853934926}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853935039}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster! Should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973853935125}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch. Why births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854001632}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854001835}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Maybe cost too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854001900}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high and initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854002023}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854083292}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predators at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854083349}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854083495}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854083593}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854236872}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854236970}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854237042}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854237240}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854252504}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"112"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854252587}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854252897}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial energy "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854252968}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"78-120, so some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854362406}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". One"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854362634}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854362924}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gives"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854363053}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854408308}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854408387}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854408443}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854408488}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~50;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854494142}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854494237}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills. H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854494388}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm.\n\nBut kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854494486}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aren"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854630276}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t tracked; prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854630350}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deaths from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854630517}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854630622}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854675595}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854675742}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854675830}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 prey 287"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854675921}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854757461}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 385 despite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854757536}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854757746}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854757796}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854847696}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predator population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854847742}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854847794}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854847876}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854927469}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 18 etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854927536}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe age deaths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854927584}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973854927627}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855005547}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855005686}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855005843}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to45; max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855005999}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855092339}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 205, all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855092377}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855092546}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" die by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855092604}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855180751}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 205"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855180815}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (gen ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855180948}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3), need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855181063}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855221467}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to replace."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855221660}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Only 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855221766}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855221865}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855301246}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" logic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855301314}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855301361}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": pred threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855301421}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855380188}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855380351}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"heno('"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855380440}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pred','re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855380553}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pro') range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855461747}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ["},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855461806}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"65,160],"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855461853}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" init .5 =>112"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855462007}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855531753}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Initial energy "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855531877}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"78-120; kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855532070}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855532128}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855644358}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855645856}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7*prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855645905}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855645959}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (~43)="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855700541}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"67"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855700586}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -> above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855700623}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Should reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855700675}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855776858}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855776916}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"52 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855776958}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", chance 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855777030}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".06 per tick."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855863263}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Expected within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855863326}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 17"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855863502}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks, so yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855863643}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855941169}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855941253}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" don't find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855941391}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973855941486}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" often"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856017220}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due to prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856017326}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scattering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856017448}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856017551}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856172879}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856173002}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856173115}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 216"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856173293}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"00 area, predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856199335}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856199416}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856199501}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" => circle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856199547}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856261233}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200 area"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856261308}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856261365}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856261423}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4% =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856328623}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expected "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856328709}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856328885}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856328978}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision. Should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856502939}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" find."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856503040}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856503102}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856503160}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" move"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856611635}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856611741}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856611813}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856611920}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Search does"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856626097}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nearest, yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856626177}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then chase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856626270}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could be catch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856626357}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856683841}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20 births only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856683926}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856684543}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age deaths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856684631}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856858288}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856858372}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856858458}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856858525}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856918122}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856918213}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856918473}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856918545}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/3="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856993366}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856993443}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856993597}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.083"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973856993652}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857054233}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857054360}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857054512}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857054615}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857114240}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857114408}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" With chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857114515}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .06 when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857114711}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" above threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857189870}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857190067}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" continuous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857190168}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills, could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857190589}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" produce ~1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857274967}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857275158}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857275212}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857275253}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s instrument"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857415663}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso starvation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857415762}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857415848}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857415990}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857475655}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cost ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857475873}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.1/tick,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857475956}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 205"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857475998}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks =20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857565636}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy. Initial "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857565698}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857565748}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", kills. H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857565803}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857642644}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857642694}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857642807}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" branches only after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857642878}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" movement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857737391}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but if prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857737456}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" near they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857737518}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill; energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857737584}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold. Should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857788767}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's add debug snapshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857788865}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857788960}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1-5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857789025}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857869452}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pred energies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857869577}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", ages"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857870236}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857870456}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown, births/de"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857973473}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aths details"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857973590}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857973641}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" track"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973857973735}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" causes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858061795}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858061880}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quick script."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858061985}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_21hjtdgngvy99gwrlm3hyirj","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858062266}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858062327}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858062698}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858062875}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858062929}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858062975}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858063086}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858063536}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858063749}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858094278}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858094408}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858098451}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858098510}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858098553}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858098614}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858098783}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858098840}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858106706}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858106748}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858106904}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858106968}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858130359}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858130440}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858130679}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858130777}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858132493}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858132576}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858132842}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bug"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858132934}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858149919}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858150198}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858150265}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858150399}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858171033}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858171111}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858171220}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858171286}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cosystem"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858235387}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858235592}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858235665}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858235710}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IC"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858235978}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858236082}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858236360}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858236406}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858237458}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858237542}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858237599}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858237644}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858248221}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858248293}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858248355}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858248402}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858248606}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858248680}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858248763}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858248819}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Ecosystem"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858279807}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858279869}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858279987}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858280045}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"184"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858286398}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858286505}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858286572}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858286675}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858329327}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858329380}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"18"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858329459}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858329548}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858331721}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858331988}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"045"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858332035}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858332092}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858360805}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858360959}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858361068}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858361118}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858362612}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858362661}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vals"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858362796}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858362866}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858366967}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858367076}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858367164}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858367210}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858389278}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858389457}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ight"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858389504}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858389816}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858390903}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858391093}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858391136}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858391237}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858409421}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858409534}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858409658}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858409737}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858423519}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858423657}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858423724}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858423829}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858442110}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858442944}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858442993}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858443060}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858443104}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858443158}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858443213}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858443257}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858455999}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858456062}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858456204}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858456300}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858472807}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858472899}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858473055}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"GEN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858473131}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858475591}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IC"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858475650}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858475715}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858475775}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858498831}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858498884}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858498920}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858498966}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858520377}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858520453}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858520503}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" prey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858520592}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858520660}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858520776}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858520837}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858520900}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858535558}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858535606}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858535897}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858535995}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858557949}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858558012}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858558070}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858558129}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858577140}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858577197}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858577241}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858577316}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858616691}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858616794}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858616892}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858616947}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858649822}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858649904}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858649975}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".reduce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858650049}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858678984}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858679061}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858679113}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858679224}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858679796}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858679887}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858679955}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858680121}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858771967}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858772044}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858772099}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858772149}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858772614}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858772686}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858772755}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858772818}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858773679}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858774076}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"):"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858774157}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858774259}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858780408}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858780511}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858780719}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858780945}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858781181}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858781269}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858781350}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858781430}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858787940}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858788028}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858788109}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858788191}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858788535}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858788612}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858788684}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858789873}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858803041}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858803542}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858803717}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858803797}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858825053}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858825151}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858826265}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plants"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858826354}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858826441}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858826523}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858826601}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858826678}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cells"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858875653}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858875765}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858875869}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858875960}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858895951}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858896075}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858896172}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858896267}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858917057}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858920210}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858920293}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858920366}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858920440}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858920533}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858920618}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858920690}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858932771}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858932863}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858932940}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858933314}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858950641}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858950733}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858950806}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858950953}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858951029}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858951098}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858951170}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858951240}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858968144}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858968254}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858968341}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858969049}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858987185}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858987290}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858987374}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858987469}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858987548}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858987640}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858987715}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973858987876}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859006669}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859027292}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859027395}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859027490}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859064690}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859064788}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859064861}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859064928}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859064996}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859065062}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859065124}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859065189}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859074157}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859074232}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859074306}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859074483}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859093281}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859093503}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859093625}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859095411}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859116294}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859116387}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859116514}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859116624}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859140202}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859140273}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859140338}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859140400}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859140455}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859140519}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859140581}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859140643}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859157923}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859158014}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859158270}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859158336}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859178616}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"irth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859178692}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859178752}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859178821}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859218000}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859218181}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859218262}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859218401}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859236365}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859236478}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859236551}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859236735}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859274066}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ind"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859274145}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859274198}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859274318}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859298839}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859298940}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859299034}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859299219}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859299303}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859299377}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bug"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859299450}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859299505}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859350031}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859350115}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859350169}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859350224}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859375120}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859375192}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859375270}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859375354}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1475,"ts_us":1792973859460377}}

data: {"id":"8d8fe21ee1d0e2015d5f5ddbc011b081","object":"chat.completion.chunk","created":1792973842,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":54074,"completion_tokens":2092,"total_tokens":56166,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":48896,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1745,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1475,"ts_us":1792973859460476}}

data: [DONE]

