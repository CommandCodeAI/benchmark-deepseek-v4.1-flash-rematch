data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949639952}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949640599}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ha! The earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949640656}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replacements didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949651303}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t apply to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949651465}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updatePred catch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949651534}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code because it still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949652147}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had old values!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949777818}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Python"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949777886}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replacement target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949777943}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failed due whitespace? Indeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949777996}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949828155}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 0.92 old"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949828238}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; our modified"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949828290}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sequence earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949828332}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949913437}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949913481}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949913820}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".97 maybe never"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949913902}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matched? Wait current file shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949984275}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch old no eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949984611}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cd, energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949984660}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 230"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973949984710}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950061524}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +18+."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950061610}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"65. Our replacements"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950061647}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" didn't match due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950062540}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950143283}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" source formatting? We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950143332}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" did earlier patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950143561}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950143600}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950223130}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"<0.97...\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950223198}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950223252}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might have failed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950223704}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950298853}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950298937}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"if(d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950298990}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"<0.97...\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950299182}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It remained "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950394038}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.92 after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950394132}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Strange"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950394204}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950394422}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" never gained"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950473486}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950473829}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? But they should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950473898}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950496852}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.92, mind"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950553822}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950553878}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"092"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950553929}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -> should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950555505}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950664300}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Yet kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950664712}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0. Why? Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950664768}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950665054}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Pred`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950716579}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code catch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950716664}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no kill count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950716737}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instrumentation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950716874}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950798973}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instrumentation replacement added kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950799051}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950799112}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a different block"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950802358}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? In debug4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950882277}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950882387}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950882447}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 because instrumentation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950882508}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950983854}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t modify this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950983946}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" block maybe and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950984016}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actual kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973950985820}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951038030}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counted."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951038263}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But prey deaths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951038340}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951040494}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951129626}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" do catch,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951129880}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but no counter due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951129925}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replacement failed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951129959}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951220985}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In actual dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951221096}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951221200}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951221319}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe because gains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951305936}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" old"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951305985}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951306032}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counter properly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951307760}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951369974}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"<0.92 should catch often"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951370034}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951370555}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills happening"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951370622}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Our previous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951455379}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patch failed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951455703}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951455782}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" source"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951456037}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in line 337"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951670245}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is `else"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951670313}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" this.moveAnimal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951670359}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(...speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951670563}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":");` not modified"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951731912}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Most of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951731960}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951732015}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tuning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951732069}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951743952}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! Similarly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951744004}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951744043}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951744088}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may have failed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951777185}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's inspect."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951777226}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This is why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951777290}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tuning confusing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951777390}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951872808}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patch targets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951872852}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use direct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951872967}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edit. This time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951873017}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explicitly update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951941078}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951941601}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updatePred function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951941668}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973951941818}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updatePrey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952039680}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's inspect current update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952039722}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Prey."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952040133}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1ysramgdwyv6xqz6apwratxx","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952040460}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952040526}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952040594}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952040640}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952040747}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952040827}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952041113}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952041158}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952041675}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952079666}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952079707}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"250"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952079897}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952080502}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"380"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952080578}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952080634}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952080837}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952080931}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952104774}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952105035}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952105080}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952105980}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952140167}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952140228}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952140305}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952140805}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952195793}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1460,"ts_us":1792973952195863}}

data: {"id":"d6a9bdba7891f7a59183ed21bd617ad5","object":"chat.completion.chunk","created":1792973949,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":73306,"completion_tokens":375,"total_tokens":73681,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":72320,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":321,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1460,"ts_us":1792973952196758}}

data: [DONE]

