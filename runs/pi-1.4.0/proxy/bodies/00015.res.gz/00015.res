data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944353659}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944353752}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Pheno"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944353790}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not exported? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944451280}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is exported?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944451354}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" module"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944451407}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".exports"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944451449}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = { ...,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944507164}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" genePheno }"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944507224}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? yes. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944507261}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" import"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944507320}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944546766}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_fj3d9ig1du2umyv698yk4x56","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944546832}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944547066}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944547356}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944560456}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944560714}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944560959}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944561221}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944586681}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944586758}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944586830}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944586897}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944586959}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944587000}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944587053}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944587092}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944597998}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cosystem"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944598051}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944598100}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944598163}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944618734}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IC"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944618928}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944619141}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944619231}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944640494}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944641248}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944641318}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944641451}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944651748}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cosystem"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944651793}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",G"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944652024}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944652177}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944652268}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IC"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944652489}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"KS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944652676}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944652764}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ene"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944672085}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944672223}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944672277}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944672531}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944689990}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944690065}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944690131}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944690202}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944690266}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944690332}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bug"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944690393}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944690449}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944705587}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944705796}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944705848}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944706104}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944724331}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944724461}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bug"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944724885}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944724974}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944760179}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944760254}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944760369}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944760592}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944767071}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944767139}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944767214}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944767481}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944859827}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1418,"ts_us":1792973944859939}}

data: {"id":"9b785a58657df22718ccffc00a1b6b5b","object":"chat.completion.chunk","created":1792973944,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":72030,"completion_tokens":129,"total_tokens":72159,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":70912,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":27,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1418,"ts_us":1792973944860075}}

data: [DONE]

