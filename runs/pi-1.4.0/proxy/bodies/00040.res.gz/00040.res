data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895074991}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895075094}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default events at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895075139}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6 not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895106134}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 7 because initial schedule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895106210}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses RNG; earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895107221}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895108068}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895149967}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895150039}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1847 had 7."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895150129}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895150413}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run, sim result"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895407478}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might differ because `maybeRef"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895407548}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ugia`, archive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895407735}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895407991}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895449437}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no RNG? archive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895449556}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895449612}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895449664}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895487184}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constructor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895487277}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895487350}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recordGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895487423}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895571883}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" schedule?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895572509}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Same. Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895572574}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event at 6? Because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895572638}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scheduleInitial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895610039}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895610150}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differs? We changed initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895610292}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895611028}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" call? Might be visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895722161}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or event? Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895722271}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895722947}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due initial schedule consumed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895723019}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895794754}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" number of R"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895794844}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NG? Should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895795075}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895795157}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deterministic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895872936}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Wait earlier test of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895873011}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tune4 seed1847 first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895873067}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895873116}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895963806}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen7. Our app has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895963872}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895963913}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6. Some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974895963973}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" RNG usage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896120220}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differences from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896120285}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modifications (maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896120558}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896121277}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sample"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896157708}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Telemetry in constructor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896157781}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? we removed; archive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896157886}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896158254}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ng). In final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896202614}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896202829}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", `recordGeneration`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896202884}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adds tele"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896203454}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"metry."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896281427}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No R"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896281552}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NG. Could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896281851}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differences"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896282435}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896378963}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scheduling formula"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896379019}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896379093}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4? We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896379167}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" copied formulas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896458449}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Something changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896459134}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896459196}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" RNG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896459284}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896526039}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896526353}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Animal`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896526424}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896526592}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Not important"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896606074}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896606180}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896606688}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896606763}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896681816}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"195"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896681898}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 plants, 353"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896681974}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey, 52 pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896682077}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896766724}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896766809}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896766860}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896766898}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Great.\n\nLet's view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896849981}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshots."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896850495}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_3uo60usitkjd1ly0onezykxt","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896850598}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896850908}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896866689}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896866761}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896866826}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896866893}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896876361}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896876416}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896876549}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896876601}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896896928}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896897025}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896897294}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974896897633}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974897002128}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9374,"ts_us":1792974897002214}}

data: {"id":"7378aaba6c538afc931956f114a44ead","object":"chat.completion.chunk","created":1792974894,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":222662,"completion_tokens":274,"total_tokens":222936,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":221568,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":231,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":9374,"ts_us":1792974897002450}}

data: [DONE]

