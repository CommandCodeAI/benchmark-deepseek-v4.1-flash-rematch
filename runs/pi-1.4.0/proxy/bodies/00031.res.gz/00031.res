data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756390658}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756390776}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" know syntax okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756390817}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756466323}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" launch Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756466633}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright screenshot. The site"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756466676}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756466865}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loads."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756543510}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756543607}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test script. Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756543865}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playwright. Check browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756544035}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" path. Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756626127}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Node require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756626379}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from /opt/node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756626425}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-tools? likely `play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756626763}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright` can be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756720302}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" required"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756720613}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756720894}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756721086}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_13t6134pfaj70rfan6itzqve","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756721480}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756721556}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756721635}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756722037}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756741105}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756741483}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756741567}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756742550}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756756631}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756756855}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756756939}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756757053}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756757728}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756757858}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756758035}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756758180}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756785785}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756785887}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756786098}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756786177}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756789369}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756789446}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756789572}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756789663}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756811408}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756811525}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756811615}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756811801}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ools"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756812614}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756812722}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756812849}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756812933}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756830840}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756830939}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756831043}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(async"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756831961}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756851208}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756851325}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756851399}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756851565}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756852081}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756852188}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756852275}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756852383}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756871051}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756871116}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756871190}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"unch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756871928}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756892712}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756892806}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756893062}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756893131}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756894196}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756894287}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756894441}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756895031}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756909253}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756909503}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756909573}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756909737}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756930120}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756930197}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756930320}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756930405}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"port"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756949920}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756950092}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756950201}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756950705}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756971854}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756971933}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756971988}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756972039}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756972137}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756972360}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756972441}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756972504}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756989969}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756990083}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" device"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756990201}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Scale"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974756990363}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Factor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757010272}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757010561}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757010645}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757011387}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757017408}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757017467}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757017515}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757017559}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757042211}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757042302}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757042929}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" msg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757043001}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757067455}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757067608}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757067771}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757067865}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"CON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757082358}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"SO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757082497}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"LE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757082593}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757085830}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" msg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757085886}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757085937}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757086066}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" msg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757086110}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757099712}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757099780}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757099835}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757099881}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757111984}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757112094}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757112165}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"error"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757112222}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757112363}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757112439}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757112487}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757112859}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757130965}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757131061}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757131150}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AGE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757131198}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ERROR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757142934}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757143067}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" err"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757143151}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stack"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757143233}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757144889}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757145065}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757145147}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757145251}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757165578}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oto"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757165657}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757165768}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757165855}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757181311}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757181468}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757181597}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757181703}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757199355}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757199467}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757199543}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757199666}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757218715}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757218801}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757218898}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757219018}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757219529}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757219722}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757219794}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757219882}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757238395}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757238576}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757238635}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757238976}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757255828}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757255884}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757255934}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757256196}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757256480}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757256552}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757256607}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757256653}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757277992}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757278161}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757278209}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757278762}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757295459}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757295761}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757295842}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757295915}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757335875}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757335966}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757336028}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757336127}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757358669}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757358743}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757358879}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757359011}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757359516}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757359766}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757359814}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757359887}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757362539}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757362600}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757362732}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757363367}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757397892}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"250"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757397982}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757398054}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757398123}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757406921}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757407003}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757407145}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757407210}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"loaded"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757426890}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757426950}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757427075}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757427179}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757447365}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".title"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757447513}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"());\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757447630}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757449216}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757472839}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757472905}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757473033}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757473107}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757473572}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757473635}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757473758}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757473872}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757516561}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757516700}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757516795}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757517162}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757531692}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757531934}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757532165}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" !!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757532225}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757540234}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757541383}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"viv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757541793}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757541879}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"App"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757541931}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757542058}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757542150}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757542252}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757586467}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757586539}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"viv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757586611}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757586688}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"App"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757619343}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757619705}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757619789}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757620237}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757635734}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757635817}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757635940}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757636050}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757636219}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757636296}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"viv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757636372}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757636481}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"App"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757638229}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757638295}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eco"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757638338}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757638463}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757639877}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757640095}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757640378}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757640429}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757653002}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757653323}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757653413}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757653537}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757653809}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757654310}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757654379}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757654478}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757672939}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757672995}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757673076}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757673660}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757707917}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757708141}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757708202}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757709659}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757710915}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757710992}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757711055}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757711118}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757731738}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757732442}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" full"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757732493}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757736037}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757750677}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"false"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757750795}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757750892}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757750976}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757793067}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757793162}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".close"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757793248}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757793359}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757809549}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757809638}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757809719}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757809799}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757809872}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757809945}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757810017}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757810091}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757833992}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757834095}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757834178}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757834256}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757847231}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757847328}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757847439}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757849711}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757976463}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757976566}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1812,"ts_us":1792974757976648}}

data: {"id":"e7e8421eb008455d7942335a730cb2f8","object":"chat.completion.chunk","created":1792974756,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":214485,"completion_tokens":388,"total_tokens":214873,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":214016,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":52,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1812,"ts_us":1792974757976779}}

data: [DONE]

