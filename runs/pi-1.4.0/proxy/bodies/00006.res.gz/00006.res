data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776530353}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Variable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776530739}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" typ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776530808}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"o. Fix. Also g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776692918}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"auss unused."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776692976}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_lxhvi4b4a0kypks7d14e96vk","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776693113}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776693301}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776693672}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776693724}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776694208}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776694278}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776694322}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776694495}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776694552}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776694887}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776694969}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776695031}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776696757}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776696828}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776696910}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776697056}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776697141}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"link"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776697232}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776727044}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776727187}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776727315}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"26"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776728400}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776760757}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776760859}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776761074}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776761126}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776762654}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"26"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776762775}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776762884}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776763042}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776781345}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776781480}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776781739}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776782089}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776798085}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776798414}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776798513}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776798577}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776798902}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776798985}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776799242}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776799290}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776827859}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776827935}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776827994}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776828245}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776860635}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776860752}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776860889}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776860946}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776861370}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776861519}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776861620}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776861676}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776950242}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776950324}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1688,"ts_us":1792973776950456}}

data: {"id":"83dfcbc058bef918c056b218933a9191","object":"chat.completion.chunk","created":1792973776,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":39115,"completion_tokens":105,"total_tokens":39220,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":7040,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":11,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1688,"ts_us":1792973776950599}}

data: [DONE]

