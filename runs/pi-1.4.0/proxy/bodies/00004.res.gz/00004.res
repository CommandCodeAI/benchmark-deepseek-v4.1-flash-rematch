data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537593701}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537593809}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser. Can install?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537593866}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Network maybe no. Check playwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537674639}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" packages"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537674724}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537674804}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1fj9d229guuzeox6k3i40i8o","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537674905}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537674999}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537675059}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537675131}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537675209}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537675270}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537675328}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537675463}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537675529}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537685446}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537685538}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537693485}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537693575}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537693653}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537693731}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537693806}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537693883}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537825055}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537825136}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537825399}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537825469}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537858187}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537858248}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537858894}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537859180}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537859226}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537859300}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537859361}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537859628}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537910622}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537910957}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537911044}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537911587}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537911736}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537911872}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537912092}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537912175}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"upp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537912411}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ete"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537912552}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"er"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537913239}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537913317}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537914799}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537914863}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537915005}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537915337}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537977987}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537978323}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537978422}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537978570}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537978648}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537978795}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537978896}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973537978961}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973538047606}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973538047744}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973538047859}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973538047985}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":984,"ts_us":1792973538098822}}

data: {"id":"38d77b6c4e62ba1be037388bcecd08b6","object":"chat.completion.chunk","created":1792973537,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":6869,"completion_tokens":99,"total_tokens":6968,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":6784,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":14,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":984,"ts_us":1792973538099203}}

data: [DONE]

