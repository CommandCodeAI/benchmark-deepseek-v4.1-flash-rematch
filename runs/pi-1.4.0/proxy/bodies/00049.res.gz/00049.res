data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194400194}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_s7qpubfgqdjcycyi73jeoa06","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194400269}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194400310}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194400547}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194400600}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194400659}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194400892}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194419302}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194419359}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194419413}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194419551}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194438761}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194438886}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194439030}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194439116}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194439318}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194439436}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194440720}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194440803}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194458362}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194458485}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194458561}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194459076}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194482820}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194482949}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194483084}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194483161}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194483496}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194483610}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194483683}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194483822}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194501875}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194501956}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194502026}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194502085}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194537810}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194537971}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194538055}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194538185}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"270"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194538563}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194538618}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"930"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194538660}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194538767}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"570"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194563569}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194563666}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"res"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194563728}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ize"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194563825}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194577075}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"660"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194577137}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194577244}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194579955}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194580058}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"save"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194580113}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194580161}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194580209}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194624942}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194624998}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194625042}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194625103}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194637891}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194638021}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194638163}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194638229}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18203,"ts_us":1792975194703298}}

data: {"id":"917b600b7543d691e6ca982811a80c68","object":"chat.completion.chunk","created":1792975194,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":239473,"completion_tokens":90,"total_tokens":239563,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":239232,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":18203,"ts_us":1792975194703376}}

data: [DONE]

