data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375062073}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375062146}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need build single-file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375062984}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index.html inline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375196787}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CSS/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375196862}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"JS. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375196916}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375196961}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wd. Need plan design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375316709}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This is a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375316780}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" substantial design task. We need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375316971}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" implement working simulation, seeded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375317291}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PRNG deterministic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375403351}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", headless mode"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375403750}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" separate sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375404167}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375404222}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render, auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375556394}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375556462}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" N generations, controls integrated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375556517}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375556573}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lines by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375602629}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375602691}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"obs, tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375602743}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tips, keyboard,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375606044}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus, live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375741724}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375741793}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375741854}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes scheduled drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375741905}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plague"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375808585}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" third"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375808650}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" choice (e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375808845}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g. frost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375808886}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375897959}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bloom / wildfire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375898011}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375898501}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" direction distinctive."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375898544}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Naturalist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375988854}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" field journal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375988946}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375988994}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973375989094}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376074575}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bioluminescent observ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376074632}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"atory. We need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376074773}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" complete polished"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376074931}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HTML"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376212951}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376213006}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" workspace files."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376213072}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_wb83qk96269fsqszwfz1v0xg","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376213161}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376213271}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376213368}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376213463}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376213536}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376217780}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376217826}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376217968}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376218063}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376223688}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376242930}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376243021}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376243081}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376243131}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376243177}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376243222}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376243270}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376248368}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376248454}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376248498}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376248688}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376248767}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376248825}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376248900}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376248947}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376344896}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376344954}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376345033}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376345294}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376355612}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376355741}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376355997}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376356040}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376356503}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376356695}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376356739}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376358054}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376360141}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376360347}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376360441}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376360741}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376373790}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376373899}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376373967}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376374450}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376463599}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376463701}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376463793}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376463878}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376495276}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376495380}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376495453}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376495534}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376495670}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376497398}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376497492}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376497572}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376498838}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376498931}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376499012}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376499097}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376505104}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376505196}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376505296}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376505436}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376591459}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376591745}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376591802}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":912,"ts_us":1792973376595635}}

data: {"id":"0ba9364db1db6f254ad14837686bc3c6","object":"chat.completion.chunk","created":1792973374,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":2132,"completion_tokens":212,"total_tokens":2344,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":0,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":116,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":912,"ts_us":1792973376595781}}

data: [DONE]

