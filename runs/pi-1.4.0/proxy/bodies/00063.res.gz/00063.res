data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765856779}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765856853}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll 106"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765856882}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px; second species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765909365}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" partly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765909451}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765909530}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765909690}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trim 100 or leave"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765936533}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At 1440x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765936639}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"900, content extends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765936759}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975765936837}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"106 below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766022305}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Close"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766022478}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766022677}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766022855}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fit by reducing ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766163131}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100. Let's see report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766163193}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766163316}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_mebvi4xvq6lciwiy8it708a0","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766163786}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766163981}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766164064}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766164260}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766164386}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766164488}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766165665}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766165812}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766165870}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766166132}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766166209}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766166266}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766166320}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766338838}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766338920}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24608,"ts_us":1792975766338973}}

data: {"id":"9da6c436319f2ca891e309aa2b254123","object":"chat.completion.chunk","created":1792975765,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":255751,"completion_tokens":91,"total_tokens":255842,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":255104,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":48,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":24608,"ts_us":1792975766339075}}

data: [DONE]

