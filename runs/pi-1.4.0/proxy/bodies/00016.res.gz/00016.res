data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947081892}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Mind"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947081965}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" distance 0.09"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947081996}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yet kills 0!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947177304}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" There"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947177356}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947177405}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a bug in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947177461}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" condition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947325169}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947325383}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's inspect update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947325596}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Pred source."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947325650}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_p1qs1frpnizdx14ovgxvgo0g","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947325721}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947327304}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947327385}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947327456}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947327522}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947327578}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947327621}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947328054}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947328136}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947328198}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947328258}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947328353}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947366353}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"35"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947366421}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947366656}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"update"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947366702}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947367067}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947367158}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947367216}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947367378}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947381563}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947381629}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947381689}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947381775}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947402009}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947402080}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947402212}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947402269}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947440159}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947440304}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947440394}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947440484}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1615,"ts_us":1792973947507207}}

data: {"id":"a42da077c52e1b3933bd5602e6ceb31c","object":"chat.completion.chunk","created":1792973946,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":72338,"completion_tokens":85,"total_tokens":72423,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":71936,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":25,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1615,"ts_us":1792973947507422}}

data: [DONE]

