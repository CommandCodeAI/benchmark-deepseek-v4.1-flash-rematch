data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846364085}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_0nuyyvn0dy9fpi67bjem8j4b","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846364179}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846364210}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846382716}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846382785}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846382836}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846382931}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846406493}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846406546}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846406815}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846406941}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846427757}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846427841}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846427905}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846428014}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846559349}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846559675}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7481,"ts_us":1792974846559738}}

data: {"id":"8e5caf8140187fa795e3dc6e3a9f5cf8","object":"chat.completion.chunk","created":1792974846,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":220931,"completion_tokens":44,"total_tokens":220975,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":220416,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":7481,"ts_us":1792974846560085}}

data: [DONE]

