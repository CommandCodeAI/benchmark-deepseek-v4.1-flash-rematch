data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975709961950}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975709962015}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all controls visible. Good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975709962041}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710016098}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710016402}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710016491}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710016542}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710101909}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crisp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710101975}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Nice. Drawer looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710102026}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" packed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710102073}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but still organized"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710198574}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Observation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710198661}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710198802}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710198874}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice. Some labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710264817}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small but okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710265083}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The lens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710265121}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" position"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710265400}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over center"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710353554}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now. The status"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710353806}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" block etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710353968}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPotential issue: right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710354572}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drawer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710464352}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content has no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710464400}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" breathing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710464458}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" space"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710464505}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at bottom before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710520514}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" footer; Observation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710520559}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710520698}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710520749}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and footer 829"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710693291}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". fits. Looks good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710693345}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710693390}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710693456}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710750109}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and animals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710750158}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The map"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710750290}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710750331}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are more visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710815235}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n- Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710815320}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710815434}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth sparkline shows green"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710815519}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710906999}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It's gold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710907045}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710907098}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975710907142}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711098117}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" green?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711098193}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711098250}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a faint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711099157}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711147559}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-green"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711147636}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line. Fine.\n- Spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711292866}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line caption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711292976}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711293456}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711293547}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rait spread"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711293617}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" at right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711339269}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; its"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711339360}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line seems invisible initially"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711339438}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711339514}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711339580}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ulates. Good.\n- Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711339957}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparkline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711340043}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711340113}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ste"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711340201}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pper shows spark;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711522861}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay.\n- Weather rows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711522958}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711523025}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711523081}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line peaks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711590296}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; good.\n- The catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711590385}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711590435}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outputs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711590505}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show \"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711611474}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/10 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711611573}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"; nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711611621}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711611681}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NEXT GEN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711664054}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 06"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711664118}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\". Current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711664174}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711664311}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711756732}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1, events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711756783}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711756840}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6; no initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711756990}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711840325}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EXT GEN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711840373}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711840457}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on first? yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711840571}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- All to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711943913}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ggles \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711943991}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Br"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711944067}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ass lou"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975711944127}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pe\"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712039689}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"Graticule\"/\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712039757}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Refugia\" on."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712039810}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n- But the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712039862}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control \"Reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712116700}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712116784}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712116971}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.00x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712117693}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712225782}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712225852}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too close"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712225904}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712225958}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fine.\n- The footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712338907}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has Hold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712339002}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", Reset."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712339043}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n- The world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712339069}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712456453}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712456519}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712456579}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712456637}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"58"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712552281}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px tall; still tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712552334}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It's okay. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712552435}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712552471}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines stronger and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712664489}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712664545}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" markers at schedule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712664958}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712664998}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712740646}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nReport"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712740743}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with compaction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712740816}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712740883}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712859194}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712859289}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" view."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712859435}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xffduqiyk6l33k72qkbs5vyr","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712859620}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712859718}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712859798}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712859995}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712860093}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712888950}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712889060}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712889139}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712889312}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712903083}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712903344}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712903512}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712903569}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712904604}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712904733}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712904968}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712905034}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712906043}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"measure"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712906111}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712906286}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712906350}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712940841}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712940908}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712940955}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712941013}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712962618}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712962674}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712962762}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975712962926}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975713051059}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23719,"ts_us":1792975713051121}}

data: {"id":"f16850bf59c3aed79b8bd73d1d61f539","object":"chat.completion.chunk","created":1792975709,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":255110,"completion_tokens":380,"total_tokens":255490,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":254080,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":312,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":23719,"ts_us":1792975713051494}}

data: [DONE]

