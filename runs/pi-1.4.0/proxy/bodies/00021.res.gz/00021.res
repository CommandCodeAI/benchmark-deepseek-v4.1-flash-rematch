data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004411964}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004412113}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004412228}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crisis around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004482674}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 9-12,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004483500}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004483559}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004484047}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004581876}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004581957}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t regulate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004582233}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004583047}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004792289}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ab"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004792335}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"undant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004792400}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004792539}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They peak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004838833}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004838902}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" late. This is classic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004839093}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" delayed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004839173}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004860885}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dependence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004861109}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004862575}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population grows after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004862626}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey peak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004905517}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004905571}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then crashes them"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004906751}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The amplitude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974004906791}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005019177}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005019250}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We need damp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005019367}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"en."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005019888}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" More predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005095671}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial numbers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005095794}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005095892}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators initially only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005095946}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005143752}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005144403}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"58. Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005144481}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators grow to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005144570}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300 when prey crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005219609}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005220189}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" peaks "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005220283}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"140"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005220332}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005330719}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005330766}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005330976}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005331016}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005407908}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005407957}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005407997}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005408033}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prolific"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005597757}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005597933}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" system"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005598003}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s prey equilibrium without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005598138}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators is "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005655753}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005656099}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005656144}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005656339}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005679437}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005679480}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), but initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005679523}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom overs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005679563}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hoots 1400 then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005728473}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005728532}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005728669}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants? Cycle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005728722}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nTo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005841577}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" get nicer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005841625}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005841830}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005841875}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey reproductive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005923517}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005923599}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to reduce amplitude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005923675}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974005923842}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase consumption pressure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006140571}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Introduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006140650}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006140796}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dependent prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006140845}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction.\n- Use larger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006155243}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006155718}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator population to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006155787}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006155866}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006169419}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006169724}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006169766}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006170767}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006281420}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" delay/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006281906}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"stre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006282165}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ngth so they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006282416}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" peak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006309268}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006309837}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey, not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006309900}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after.\n\nActually predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006309965}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numbers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006395107}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" do grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006395160}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with prey:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006395260}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006395296}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006469881}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->35->51->39"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006470297}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->56->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006470369}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"81->119"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006470467}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->197->336"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006565427}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Prey 58"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006565489}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->320"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006565538}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->535"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006565587}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->860"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006693237}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->1139"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006693307}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->664"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006693407}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006693459}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"286->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006719595}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"33. Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006719685}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators peak one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006719746}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen after prey crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006725134}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Classic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006790004}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006790073}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006790133}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is faster earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006790191}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", they control sooner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006875905}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006875972}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wipe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006876028}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey completely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006876079}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The purpose is cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006942053}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006942292}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006942339}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974006942724}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007049294}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007049360}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" refuge:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007049408}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" e.g., plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007049508}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007128116}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ab"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007128184}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"itat complexity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007128226}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007128297}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" success"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007184490}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" declines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007184551}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007184595}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low prey density. We can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007184872}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" implement predator functional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007377836}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" response type"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007377911}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" II: search time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007377968}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007378027}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007423259}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduces kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007423327}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007423961}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007424031}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007439697}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007439757}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slower? Actually predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007439862}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth proportional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007440336}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007513355}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007513604}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low prey, harder"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007513682}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007513763}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need refuge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007574331}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": when prey count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007574395}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low, they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007574528}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007574941}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harder to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007666812}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007666894}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007666995}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vigilance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007667272}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007868405}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hiding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007868483}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007868540}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007868589}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe less. Conversely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007918446}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at high prey,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007918706}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" easier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007918771}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007920640}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator grows."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007940101}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That's natural.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007940629}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can make prey reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007940691}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower when predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007940737}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007992243}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007992457}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fear effect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007992500}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974007992982}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and prey speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008063703}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/cry"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008063757}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"psis"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008063857}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008063940}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008140901}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evolve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008141164}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- To damp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008141237}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"en"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008141667}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycle, make prey feeding efficiency"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008240391}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008240452}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"production negative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008240500}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008242508}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dependent at high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008306174}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008306521}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008306564}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" competition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008307309}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Add a local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008380344}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crowding factor or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008380412}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" global cap at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008380614}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008380677}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". With prey cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008477257}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008477315}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator can't boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008477361}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008479263}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; a stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008548026}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" level"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008548133}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Also initial prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008548204}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008550691}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower and plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008649194}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grow.\n\nA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008649471}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simple global logistic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008649546}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction factor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008650247}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008699134}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n```\nconst preyCap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008699194}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 450"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008699335}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";\nreproCh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008699415}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ance *= clamp(1 -"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008830575}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preyCount / prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008830663}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cap, 0.02"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008830748}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 1)\n```\nWhen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008830826}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008857673}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", factor ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008857760}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"56."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008857824}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Peak maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008858074}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008940062}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008940183}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators then ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008940458}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"80,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974008940582}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009015297}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009016666}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey down"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009016734}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009016804}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survivors"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009110034}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009110092}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This could stabilize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009110143}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009112260}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009170258}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009170301}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Similarly predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009170438}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009170969}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009247951}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But artificial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009248004}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps are less visible,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009248051}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009250490}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009318017}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dependence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009318108}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is reasonable. In a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009318380}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closed viv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009318481}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arium, finite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009439011}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" territories"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009439061}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can add \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009439126}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009439940}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ritorial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009514994}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009515051}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009515125}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009515232}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009558219}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not mention"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009558353}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need ensure control \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009558437}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"food reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009558492}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth\" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009642249}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matters;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009642851}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009642900}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at high counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009643689}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009712751}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009712831}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Could tie"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009712882}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap to plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009712986}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coverage: `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009789158}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009789233}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pro *="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009789286}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clamp((plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009789369}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Coverage - 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009865654}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"08)/0.25,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009865708}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009865904}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.05, 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009865949}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009945254}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009945330}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" partially"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009945426}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exists but only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974009945691}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up to .16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010038756}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; plants stay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010038806}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010038924}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20% until prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010038977}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010106740}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010106801}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cover relative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010106840}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010108959}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? At prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010172220}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1400, plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010172269}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 170"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010172314}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010172614}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010244423}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9%) ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010244471}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factor low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010244634}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010245089}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010326775}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010326840}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010326899}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010328534}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier, threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010409927}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coverage e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010409973}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g. 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010410017}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%: factor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010410145}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `clamp(co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010493397}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"verage/0.40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010493501}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",0,1)`;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010493577}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010493636}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coverage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010561284}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .224"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010561330}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -> .56"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010561365}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010561478}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010649998}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ved. But food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010650047}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010650166}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010650234}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coverage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010722737}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010723139}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrowth boosts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010723193}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could produce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010723235}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010808483}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" peaks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010808553}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010808610}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010808706}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".06"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010891145}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010891404}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.94*clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010891486}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010892007}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cov-0.12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010961160}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")/0.25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010961427}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",0,1)`?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010961471}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at .22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974010963180}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011092712}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.44"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011092793}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011092864}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" More physically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011092955}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011110136}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011110188}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" based on local plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011110241}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" availability ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011110539}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011197501}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") instead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011197572}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of global. If plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011197611}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are abundant ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011197768}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"they are),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011268116}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011268187}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAnother"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011268244}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" approach: increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011268407}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" metabolic cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011350518}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011350574}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011350759}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throughput to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011350799}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011433932}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011433984}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011434191}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011434281}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011540646}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011540716}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consume plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011540754}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 24, metabol"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011541012}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ize ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011669315}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011669366}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1/tick. Their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011669417}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011669528}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011710476}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cundity lets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011710524}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011710846}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011710888}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011748113}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" requires "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011748436}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011748480}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011750625}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011840540}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011840813}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can make them spend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011840858}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011841421}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011956097}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011956448}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011956491}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy is what"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011956554}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011981574}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Still logistic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011981630}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nTo get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011982004}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974011982069}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" richness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012055419}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012055589}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300 not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012055642}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 140"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012056381}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0. Target peak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012143154}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012143222}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"450"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012143287}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012145269}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012219453}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012219533}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012220125}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dependence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012220193}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012313480}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Global"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012313540}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012313578}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012313620}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012399101}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" based on current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012399176}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012399222}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012399274}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012481708}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 320"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012481759}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `cl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012481802}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"amp(1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012481889}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" - prey/500, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012546457}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.05, 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012546535}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")`. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012546590}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 58 ->0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012548685}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".88, at 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012619643}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"->0.4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012619730}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", at 500->0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012619844}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012619911}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This slows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012711250}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth. At equilibrium without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012711318}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators maybe 450.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012712132}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pred reproduction factor based on prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012712197}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" availability"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012791273}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012792057}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators can boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012792205}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012792302}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012876053}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 180: `clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012876147}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(1 - pred/180"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012876230}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012877763}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.04"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012946441}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",1)`. This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012946525}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is deterministic.\nWould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012946643}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoid predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974012947733}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wipeout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013027654}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? At pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013027740}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 336"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013027994}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013028078}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013218309}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". With cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013218364}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013218412}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"180, then predation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013218457}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pressure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013266009}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013266107}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey can survive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013266162}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But if predator eats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013266208}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey down"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013408537}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013408612}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ves to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013408669}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013408724}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013409031}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013409096}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013409152}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ensure prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013409204}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not extinct. Cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013449436}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013449550}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" help"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013449623}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013451588}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013605425}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013605496}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013605552}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high: factor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013605623}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013617741}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"clamp(1 - pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013617796}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013617842}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"prey*0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013617889}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5), 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013693386}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1, 1)`?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013693429}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013693558}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013694736}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013770801}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y ratio. Could introduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013770885}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fear. H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013771006}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm.\n\nAlternative design with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013771112}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"refug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013876969}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ia\" for prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013877031}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013877294}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numbers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013877339}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013939090}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey decline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013939131}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013939175}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974013939212}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014023417}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014023495}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014023561}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014023678}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" breed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014102073}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014102142}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014102199}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less competition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014102255}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but not enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014167715}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014167761}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s implement carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014167827}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacities"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014167876}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and density dependence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014271394}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and test."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014271459}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Specifically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014271513}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- prey reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014271682}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014352961}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"chance *= clamp((1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014353014}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" - this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014353163}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".prey.length/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014353263}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"600),0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014438941}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".03"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014439000}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",1)`.\n- pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014439037}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction `chance *= clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014439762}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"((1 - this.pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014518745}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".length/220"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014519107}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"),0.03"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014519197}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",1)`.\n- Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014519356}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also plant cover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014589106}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014589196}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as existing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014589249}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014589320}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014660291}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"58. Peak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014660366}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014660566}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014660634}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reaches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014882779}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014883035}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014883162}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators peak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014883256}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014922732}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200. Let's test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014922794}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no cats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014922843}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014922893}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_5ztzw1w8g768l7nknfw6cg39","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014922987}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014923074}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014923145}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014923206}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014923261}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014923323}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014923368}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014923406}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014924102}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014924328}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014924373}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014924615}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014925147}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014925230}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014926678}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014926751}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014939320}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014939373}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014939426}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014940790}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014942161}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014942224}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014942270}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014942975}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014944144}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014944222}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014944289}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014944443}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014957444}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014957739}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014957796}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014957979}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014977439}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014977600}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014977712}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014977771}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014979870}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014980012}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014980079}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974014980129}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015007432}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015007502}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015007565}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015007627}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015017475}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015017530}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015017583}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015017648}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015017686}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015017739}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015017804}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015017952}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015062529}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015062587}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015062649}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015062731}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015062989}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015063039}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015063075}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015063225}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015074176}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015074449}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015074495}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015074607}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015097671}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015097741}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015097988}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015098040}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015098679}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" eff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015098756}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015098874}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015098953}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015123342}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clamp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015123753}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015123847}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015123937}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015150639}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cover"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015150686}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015150737}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015150798}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015150860}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015150900}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015150950}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"16"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015150978}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015156612}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015156665}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015156703}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"08"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015156887}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015179706}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015179795}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015179881}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015179994}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015180337}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015180413}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015180482}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015180536}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015195886}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015195976}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015196039}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015196149}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015208561}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015208647}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015208717}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015210370}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015210959}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015211024}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015211114}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015211202}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015241233}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015241291}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" eff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015241364}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015241728}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015260440}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015260505}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clamp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015260561}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015260670}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015260738}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015260801}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cover"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015262734}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015262815}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015279575}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015279648}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015279711}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015279817}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"16"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015296346}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015296415}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015296470}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015296505}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"08"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015298330}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015298880}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015298947}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015299012}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015322066}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clamp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015322297}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015322346}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015322394}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015338952}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015339017}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015339072}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015339110}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015364111}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015364367}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"620"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015364451}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015364552}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015378610}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015378675}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"03"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015378747}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015378957}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015379357}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015379438}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015379561}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015381044}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015396258}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015396331}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015396524}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015396578}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015408930}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015409158}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015409250}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015409331}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"045"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015443760}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015443857}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015443938}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015444069}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015444146}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015444225}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015444401}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015444468}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015521737}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015521797}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-th"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015521865}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015521944}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015522017}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015522090}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015522161}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015522223}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015522273}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015522340}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015522408}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015522449}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" eff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015545342}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015545422}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015545467}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015545574}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015557332}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015557728}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015557781}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015558420}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015558472}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015558532}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015558643}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"045"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015558717}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015574976}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015575038}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015575164}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015575221}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015576705}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015576757}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015577110}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015577180}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015577273}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-th"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015577334}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015577576}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015577627}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015579531}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015579602}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015579672}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015579744}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015592909}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015592998}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015593081}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" eff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015593162}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015593285}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015593358}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015593425}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clamp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015593589}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015614880}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015614941}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015614992}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015616601}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015638982}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015639044}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015639098}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015639151}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"200"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015659421}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015659481}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015659637}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015659689}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"03"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015679905}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015679973}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015680032}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015680276}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015683570}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015683645}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015683716}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015683842}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015695938}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015696182}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015696255}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015696313}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015721618}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015721669}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015721737}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015721851}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015722412}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015722468}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015722521}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015722575}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015732553}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015732610}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015732670}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015732751}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015753014}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015753077}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015753121}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015753169}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015753216}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015753266}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015753304}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015753387}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015779655}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015779709}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015779767}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015779870}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015794016}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015794097}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015794159}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015795155}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015795288}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015795357}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015795426}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015795525}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015838794}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015838868}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015838935}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015839027}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015862525}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015862578}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015862646}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015862710}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"180"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015925732}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1689,"ts_us":1792974015925800}}

data: {"id":"ba06c89c15fa8255ee8f18a524fff5ca","object":"chat.completion.chunk","created":1792974004,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":84117,"completion_tokens":1586,"total_tokens":85703,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":81536,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1267,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1689,"ts_us":1792974015925883}}

data: [DONE]

