data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217431047}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_3px37itkkdm9okoulhegx8r8","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217431146}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217431200}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217466919}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217466969}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217467043}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217467110}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217489813}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217489871}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217490273}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217490370}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217518236}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217518977}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217519024}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217519118}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217602118}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19207,"ts_us":1792975217602268}}

data: {"id":"f09f2ce0b2b17f2defbb0aefd62b7c56","object":"chat.completion.chunk","created":1792975217,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":239578,"completion_tokens":43,"total_tokens":239621,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":239360,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":19207,"ts_us":1792975217602565}}

data: [DONE]

