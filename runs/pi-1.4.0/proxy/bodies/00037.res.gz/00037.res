data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834290828}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834290947}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" composition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834290994}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much better. Screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834388507}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834388627}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440x900;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834388703}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834388775}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fills stage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834471780}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834471848}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834471895}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cuts off"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834471937}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Observation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834614291}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggles, but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834614388}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll. Stage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834614445}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834614492}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nIssues to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834651311}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" address:\n1. There are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834651433}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many dark red"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834651701}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" triangles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834652066}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834826234}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"predators) and brown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834826330}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834826627}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834828579}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Looking close"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834850215}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834850281}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are tiny brown/och"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834850320}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"re dots maybe; predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834850356}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" red triangles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834944242}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible. The left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834944438}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834947778}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts show 157 gra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974834947869}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"zers but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835093667}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they blend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835093875}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835093978}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants. Need ensure distinct glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835094211}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" language visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835157230}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835157290}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" map"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835157351}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scale 4.0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835157450}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey size"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835274878}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe 3.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835274928}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Their och"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835274971}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"re is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835275180}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" close"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835350846}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to paper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835350897}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/plant, likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835351016}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard to see. We can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835351069}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835401513}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey size and contrast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835401566}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": add dark ink"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835401652}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outline and maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835401768}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835508865}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" filled te"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835508942}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835509002}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rop. Current glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835509061}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many thin strokes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835570999}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835571171}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" size, they may blend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835571232}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe draw them as little"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835571585}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" och"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835661263}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"re ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835661307}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with dark outline bigger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835661391}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835661453}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835748361}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as red triangular"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835748449}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835748513}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" glyphs clear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835748568}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in map"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835828468}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could draw prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835828521}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" larger,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835828562}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835830406}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g.,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835936373}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" size ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835936497}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" map.scale*1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835936624}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2 (≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835936669}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4.8) with darker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835988518}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outline. Also maybe pre-re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835988610}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"nder no;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835988696}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974835988863}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836077227}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use fill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836077329}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" och"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836077469}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"re darker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836077651}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and outline ink"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836172881}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836173085}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836173221}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" halo offset. We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836173304}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836252751}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add `ctx.sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836252800}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"adowColor` no."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836252849}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can fill antipodal."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836252895}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's zoom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836343844}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836343898}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crop using image mag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836351125}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick? Could inspect via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836351173}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836471300}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright screenshot clip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836471380}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of plate. Let's crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836471467}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836471514}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_0dauodd6ixj139np176frezj","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836471685}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836471815}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836471904}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836472024}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836498666}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836498734}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836498785}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836498833}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836498882}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836498958}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836499016}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836499061}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836517875}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836517936}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836518379}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836518484}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836539617}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836539888}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836539931}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836539996}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836540070}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836540129}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836540197}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836540257}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836558612}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836558702}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836558760}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836558912}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836585292}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836585363}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836585417}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836585506}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836617928}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836617994}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836618059}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836618125}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"238"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836643695}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836643800}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"160"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836644050}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836644118}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"104"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836683789}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836683837}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836683959}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"740"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836684005}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836684938}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"res"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836684993}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ize"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836685044}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836685246}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836753486}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836753542}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836753764}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"870"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836753815}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836753977}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"save"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836754033}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836754076}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836754103}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836780680}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836780730}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836780850}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836782622}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836799097}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836799168}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836799232}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836799280}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836871755}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836871892}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836871984}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836872097}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836872909}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836872989}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836873134}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836873359}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836883320}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836883535}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836883648}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836883869}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836968150}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7695,"ts_us":1792974836968276}}

data: {"id":"ec853ed04fcb48b336fd2dd7cf3f91bb","object":"chat.completion.chunk","created":1792974834,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":220497,"completion_tokens":392,"total_tokens":220889,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":219520,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":287,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":7695,"ts_us":1792974836968452}}

data: [DONE]

