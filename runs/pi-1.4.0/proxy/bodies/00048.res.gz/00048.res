data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167459276}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167459375}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test with browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167459407}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also note using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167529988}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" performance.now inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167530070}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" draw for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167530633}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" newborn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167530741}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" halo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167597515}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not crucial. Take"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167597689}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167597746}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_l6586encjywlummwhc0pow6r","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167598228}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167598706}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167598822}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167598951}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167598999}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167599050}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167599163}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167599213}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167600284}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167626752}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167626920}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167627154}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167627416}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167658913}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167659020}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167659157}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167659292}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167720740}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167720850}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167720937}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167721039}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19653,"ts_us":1792975167770529}}

data: {"id":"1b454a72c27f0d1a0c965291c6e64204","object":"chat.completion.chunk","created":1792975167,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":239347,"completion_tokens":80,"total_tokens":239427,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":233344,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":21,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":19653,"ts_us":1792975167771411}}

data: [DONE]

