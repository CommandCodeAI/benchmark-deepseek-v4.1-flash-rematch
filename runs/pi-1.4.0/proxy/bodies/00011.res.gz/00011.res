data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900790475}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900791201}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" massive prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900791243}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overshoot to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900862190}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1000, plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900862269}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900862339}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900862615}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" often don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900936685}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t survive due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900936733}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" similar"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900936836}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973900936888}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-bust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901007163}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901007212}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1847 has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901007341}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901007871}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" though"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901077828}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901077918}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901078185}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901078494}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901160384}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901160444}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901160671}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901161009}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" robust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901236934}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" across seeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901236995}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901237257}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901237319}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901307597}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use a single"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901307693}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canonical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901307816}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed with best"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901308064}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901388969}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Requirement same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901389121}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed reproducibility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901389244}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; random"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901391761}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901467309}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901467377}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901467421}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" produce varied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901468268}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs including"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901555954}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" collapses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901556166}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", okay. But defaults"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901556520}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901556576}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" produce convincing."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901616851}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can make default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901617073}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 1847 which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901617118}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901617360}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" persistence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901692665}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throughout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901692760}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901692833}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901692911}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901755923}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901756034}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901756677}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901756720}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"400 at events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901836869}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901836944}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901837012}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901837054}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"50. It looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901911071}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901911394}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" decent cycle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901911618}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901911690}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901976456}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 278"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901976519}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901976563}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973901976992}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred survives"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902057505}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902057612}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902057761}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1847 default. Yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902057972}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902165068}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902165181}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ext"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902165257}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inguish predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902165323}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902250741}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That's acceptable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902250814}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (ec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902250923}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"osystems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902251135}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can lose predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902307360}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). But dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902307417}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902307484}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902307530}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would have no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902472776}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902472841}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902474864}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902474922}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902525176}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"refuge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902525291}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902525443}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prevent total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902525561}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902554337}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction. For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902554417}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" robustness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902555387}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", perhaps reint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902555449}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"roduce a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902612946}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small number? H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902613008}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm.\n\nThe bigger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902613104}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue is the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902613301}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902688283}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902688366}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902688428}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902688484}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902773015}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902773079}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902773128}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 by gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902773181}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902841869}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902841948}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wild (but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902842218}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart log"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902843106}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902923258}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902923304}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902923389}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973902923564}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903003594}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve. The cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903003787}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903004104}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are plausible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903004237}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903095444}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-prey. But ecosystem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903095507}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903095585}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903096137}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ust each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903178495}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903178549}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe okay."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903179097}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903179949}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903281222}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and geological"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903281279}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903281432}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903281745}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903352985}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drop from "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903353148}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5000 to 800,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903353361}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903353513}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dramatic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903532256}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCan"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903532425}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we limit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903532532}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903536297}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with a density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903618133}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dependent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903618530}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factor? Let's try"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903618605}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adding global"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903618670}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" habitat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903677713}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limitation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903677784}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903678299}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903678361}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903755288}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" based on plant coverage:\n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903755505}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"```\nconst plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903756004}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Support"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903756043}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903787002}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(this.plantCoverage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903787473}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"()/0.18,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903787685}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903787816}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903887185}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")\nchance *= plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903887277}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Support\n```\nAt coverage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903887545}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903887626}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903943642}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903944257}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ->1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903944336}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; at below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973903944702}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904026727}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904027097}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904027160}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904027281}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overshoots plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904102893}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to ~500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904103089}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904103191}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".3%) before birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904103283}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stops. Population is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904181553}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904181622}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904182362}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they ate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904182436}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904254566}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904254680}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant 310"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904254841}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9 (14"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904254910}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904367587}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4%) =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904367639}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction stops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904367942}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" partly. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904367994}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they're"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904473723}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already 597"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904473818}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That would damp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904473882}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"en"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904474022}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". However reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904511005}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904511941}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904511984}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-3 with coverage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904512050}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >14"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904622351}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904622424}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904622542}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" coverage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904623445}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 23"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904672757}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%, 22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904673044}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9%, 20."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904673106}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7%, 14.4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904673231}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904757261}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904757331}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stop by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904757602}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen4. By"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904757647}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904847638}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904847743}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"597. Maybe."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904848081}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could prevent "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904848347}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1000.\nSet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904897439}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904897516}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904897608}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% coverage: above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904897689}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904961272}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"25 full,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904961443}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scaled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904961504}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973904961802}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905071031}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .234"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905071103}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905071161}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"93"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905071326}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%; gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905118607}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 .229;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905118719}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen3 .207=>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905118856}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"83%; gen4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905119002}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .144 => no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905201317}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905201381}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905201432}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905202160}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t grow as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905274809}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much after gen2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905274879}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905274925}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905275096}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905355758}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eaten down"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905355828}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" though from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905357957}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 500"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905358021}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 to 250"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905457430}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905457500}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen4 due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905457565}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 597"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905457628}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905515470}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator boost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905515543}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905515605}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905516817}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905598787}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905598867}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905598926}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905598985}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown to 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905682135}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905682217}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905682314}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" halves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905682372}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905749963}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" support"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905750031}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905750083}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"400. Birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905750132}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905833982}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905834058}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905837730}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 15/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905837805}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905921505}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"108"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905923451}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0/gen can sustain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905923521}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905923594}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- With less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905993113}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905993188}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905993322}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy lower,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973905993707}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906076727}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nLet's try"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906076987}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eatCd 22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906077067}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plantEnergy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906077514}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906159538}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906159691}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906159756}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906160028}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906247971}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906248035}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906248084}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906248132}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators catch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906322134}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906322197}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" easier. Reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906322264}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906322341}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906387860}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- At "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906387905}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"58"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906388316}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906388354}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", each can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906497568}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906497684}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 22"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906497844}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906497987}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3.3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906595454}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants/gen*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906595521}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24=79"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906595618}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy. Repro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906595661}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906665069}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906665522}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906665569}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 50 ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906665661}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906740471}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906741160}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906741207}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reaches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906742403}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906825642}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce once"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906825697}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906825740}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906826030}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 gens, bringing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906890307}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pop up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906890368}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906890870}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth 15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906891688}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906967952}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906968047}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 58*1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906968151}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/22=2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973906968204}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6 plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907056463}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907056525}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". As"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907056689}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907056970}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907117437}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption 13."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907117487}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6/tick; plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907117568}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth declines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907117700}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with cover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907204463}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Still could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907204990}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deplete standing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907205047}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stock"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907205081}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907308773}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907308964}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907309264}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" standing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907309305}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stock"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907355725}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4800; over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907355788}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907355838}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe consumed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907356045}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907551858}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907552261}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eating co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907552315}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown 12,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907552474}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907614547}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907614761}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" follow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907614805}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907615108}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's test with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907649897}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eatCd 22 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907649940}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907650127}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907650312}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907719086}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also reint"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907719130}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"roduce catastrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907719192}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later. Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907719243}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907855601}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24 run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907855660}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907855696}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_00wpbrt8dcyvz9b4zlql2vfd","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907856074}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907856268}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907856350}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907856423}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907856470}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907856713}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907856787}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907857829}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907857913}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907857974}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907858090}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907858146}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907858292}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907866531}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907866593}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907866714}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907866854}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907866944}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907876766}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907876848}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907876933}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907901898}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907901972}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907902015}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907902153}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907926802}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907926895}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907927073}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907927121}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907928415}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907928697}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907928742}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907928846}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907951283}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907951361}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907951440}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907951975}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907952038}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907952086}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907952473}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907952549}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907975267}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907975358}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907975399}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907975492}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907994927}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907994986}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907995121}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907995274}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907995979}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907996024}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907996376}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973907996472}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908004862}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908004969}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908005081}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908005221}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908025758}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908025816}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908025877}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908025964}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908067124}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908067232}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908067425}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908067508}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908068210}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908068522}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908068588}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908069254}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908093425}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908093549}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908093624}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908093715}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908093905}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908093948}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908094006}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908094102}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908106436}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908106481}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908106873}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908106916}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908131881}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908131942}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908132006}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908132141}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908132213}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908132759}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908132837}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908132891}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908144740}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908144824}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908144888}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908145447}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908169513}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"21"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908169618}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908169674}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908170387}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908189700}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908189764}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908189817}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908189865}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908229718}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908229855}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908229955}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908230035}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908232095}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"05"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908232205}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908232279}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908235992}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908236076}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908236150}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908236221}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908236290}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908250556}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908250645}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908250720}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-th"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908250788}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908275745}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908276321}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908276427}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908276512}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908276684}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908277033}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908277123}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908277244}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908298584}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908299929}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908300026}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908300113}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908324633}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908324739}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908324846}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908324943}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908346509}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908346593}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908346663}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908346733}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908346802}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908346879}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908346947}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908347027}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908359888}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908359988}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908360823}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" eff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908361065}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908391445}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908395585}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908395683}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908395791}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908395896}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908395979}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908396066}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908396142}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908493131}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908493217}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"055"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908493288}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908494363}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908515673}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908515781}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908515900}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908515972}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908516013}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908516993}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908517088}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908517126}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-th"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908522710}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908522787}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908522864}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908523782}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908530181}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908530426}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908530494}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908530627}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908530880}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908530948}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908531132}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908531225}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908568572}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908568745}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908568814}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908570353}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908571419}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908571534}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908571651}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908571722}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908573126}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908573424}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908573484}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908573884}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908577470}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908577596}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908577683}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908577764}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" eff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908578223}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908578304}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908578374}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908578439}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clamp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908578517}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908578633}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908578685}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908578758}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cover"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908582230}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908582449}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908582522}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908582620}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908586960}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908587045}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"16"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908587359}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908587432}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908587563}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908587633}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"08"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908587696}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908587905}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908587981}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908588044}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908588123}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908588170}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908606189}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908606520}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908606609}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908606696}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908606785}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908606850}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908607306}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908608045}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908662421}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"184"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908662516}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908662631}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908662677}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908678982}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"731"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908679030}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908679111}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908679225}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"204"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908679715}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908679764}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908679881}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908680758}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"88"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908723259}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908723634}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908723700}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"129"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908724369}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908725692}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908725991}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908726048}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908726201}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908726617}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908726685}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908726785}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908727047}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908737893}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908738290}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908738364}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"184"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908738728}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908750758}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908750824}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908750888}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"731"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908750964}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908751023}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908751079}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"204"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908751567}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908752961}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908772570}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908772806}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"88"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908772869}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908773494}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908786509}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"129"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908786559}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908786636}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908787215}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908787290}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908787354}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908787407}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908787486}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908805056}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908805177}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908805248}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908805297}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908844849}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908845799}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908845865}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908845957}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908846376}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908846426}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908846663}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908846720}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908877537}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908877638}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908877969}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908878043}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908878102}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908878162}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908878227}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908878674}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908974748}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908975129}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"180"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908975197}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1686,"ts_us":1792973908980520}}

data: {"id":"274a007bbb1daaf42c770050fd63bdf5","object":"chat.completion.chunk","created":1792973900,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":63915,"completion_tokens":1137,"total_tokens":65052,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":56704,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":803,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1686,"ts_us":1792973908980597}}

data: [DONE]

