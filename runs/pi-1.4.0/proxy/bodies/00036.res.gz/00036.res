data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823781584}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_wozc7hn96oasq5lrcmak40v5","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823781690}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823781736}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823816663}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823816957}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823817016}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823818751}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823819214}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823819298}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823819360}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823819396}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823840197}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823840284}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823840345}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823840468}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823929045}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823929246}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5546,"ts_us":1792974823929491}}

data: {"id":"b7573705c0e0968a173759158e7f7970","object":"chat.completion.chunk","created":1792974823,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":219629,"completion_tokens":44,"total_tokens":219673,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":218752,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":5546,"ts_us":1792974823929786}}

data: [DONE]

