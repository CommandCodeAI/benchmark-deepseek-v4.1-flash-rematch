data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975681918811}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975681919017}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drawer content exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975681919086}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrollheight"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975681956014}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 636 = body 635"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975681956253}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9. All controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975681956331}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible at 900, nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975681956641}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682042745}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682042797}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682042843}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682042891}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682135621}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Flash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682135697}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682135801}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" missing. Let's view initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682135864}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682211464}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682211526}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_349iq7k8c88phlcl38f25th7","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682211697}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682211751}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682221001}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682221342}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682221550}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682221597}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682221995}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682222310}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682222657}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682223838}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682239538}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682239746}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682239977}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682240034}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682329387}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682329701}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21098,"ts_us":1792975682329784}}

data: {"id":"3b829f5bda460740ff7939529c2e77aa","object":"chat.completion.chunk","created":1792975681,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":254198,"completion_tokens":89,"total_tokens":254287,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":250240,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":45,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":21098,"ts_us":1792975682329976}}

data: [DONE]

