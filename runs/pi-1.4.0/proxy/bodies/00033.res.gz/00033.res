data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779646057}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"View"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779646267}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779646327}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_x8mjscvmskcz8zcsj6gq8jje","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779646400}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779646468}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779646527}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779646588}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779666614}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779666728}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779666807}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779666869}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779683748}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779683830}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779683909}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779684045}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779704039}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779704160}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779704253}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779704601}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4288,"ts_us":1792974779769056}}

data: {"id":"3d546c5e3c06ca74b602c60be5c99c0f","object":"chat.completion.chunk","created":1792974779,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":215512,"completion_tokens":47,"total_tokens":215559,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":215168,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":3,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":4288,"ts_us":1792974779769219}}

data: [DONE]

