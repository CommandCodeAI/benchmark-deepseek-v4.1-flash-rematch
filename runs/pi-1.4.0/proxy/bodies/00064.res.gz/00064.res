data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975797930525}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975797930624}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975797930667}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798070269}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", now second"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798070397}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species row is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798070672}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible partly ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798070957}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"chart top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798173638}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798174359}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom cut. Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798174432}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798174493}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798195008}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need ~105px."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798195102}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798195197}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798195244}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798229677}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798229756}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height to 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798229819}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"dvh - 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798229858}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798283748}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"save 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798283831}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" px).\n- Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798283924}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pop chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798283984}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798412168}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798412231}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Currently 315"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798412281}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can reduce canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798412365}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798467415}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"220→"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798467486}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798467573}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (30)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798467739}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n- Reduce drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798546474}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798546564}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798546664}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"78→66"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798546903}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (12*2="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798636282}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798636341}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Dr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798636393}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ift row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798636454}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798747052}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc.\n- Reduce report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798747213}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" header "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798747863}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"115"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798747914}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"→100 (15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798819516}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n- Reduce summary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798819580}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798819641}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"58→50 (8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798819784}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n- Reduce main"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798890128}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" margins 12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798890244}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"→8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798890481}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975798891044}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799008757}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Footer maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799008829}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799008936}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799008979}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nTotal ~100. That could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799085731}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make all fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799085844}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but bottom footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799085955}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might not need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799086080}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799163979}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It would be nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799164074}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799164205}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799164337}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" charts at 66"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799279150}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px maybe too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799279286}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" short; but still readable with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799279367}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bands"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799279449}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The chart line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799378810}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compressed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799379010}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could make whole"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799380022}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799380091}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799442799}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two columns? Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799443054}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799443149}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" card"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799443316}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is ~?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799491295}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799491462}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" block 152"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799491549}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799491717}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"161; chart 78."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799634056}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If cards 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799634108}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", save "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799634186}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"36. Need "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799634273}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100. The report still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799742809}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has 865"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799743024}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799743141}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; client"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799743219}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 759. If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799762132}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we shrink header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799762201}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and chart and margins"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799762401}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by 100,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799762450}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799843548}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"765, plus header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799843607}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" client"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799843714}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grows? Sheet max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799843984}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799928483}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is 875 currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799928531}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", report head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799928567}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 115. Footer at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975799928667}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 928"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800010167}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" > sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800010218}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 889"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800010253}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800010303}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800114861}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800114937}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800115029}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not visible. If increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800115246}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sheet to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800202477}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 896 (height=100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800202613}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"vh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800202724}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800202872}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and header"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800297388}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800297594}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100, then scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800297735}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" client 796"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800297888}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800381673}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adjust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800381792}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need 865"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800381895}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800381982}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800544697}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800544798}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" <796 maybe."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800544880}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800544919}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remove"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800569254}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 69 from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800569353}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800570639}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" header saved"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800570764}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800661820}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t affect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800661874}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll client positively"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800661962}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800662018}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 15. If content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800758786}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 865-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800758928}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100=765"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800759135}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" < client 775"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800759289}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800928924}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n\nLet's implement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800928996}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more compact around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800929048}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800929076}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Report overlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800956273}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" padding 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800956635}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800956678}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aesthetic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975800956767}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edge. Could set 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801028627}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px. sheet 884"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801028700}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801028751}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801029283}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- header 114."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801131419}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8 ->100: reduce padding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801131515}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 14"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801131663}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801131945}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801218439}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), h2 maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801218782}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 39 (2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801219030}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), meta margin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801219075}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801271599}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6 (3)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801271729}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" save ~13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801271829}}

data: {"id":"38f08ac37aa8d00ae9137d64fbaab101","object":"chat.completion.chunk","created":1792975797,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- summary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":25094,"ts_us":1792975801272003}}

