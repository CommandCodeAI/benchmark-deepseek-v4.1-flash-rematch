data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979271443987}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272316689}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272481035}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272481116}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272481178}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272481239}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272481299}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272481354}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272481410}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272481465}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272498936}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272498995}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272508391}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requiring"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272508451}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272568396}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272568437}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272568476}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272568511}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272568544}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" temp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272568582}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scripts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272585413}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272598930}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272598973}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tmp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272599051}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272599131}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" needed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272615251}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272615311}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272629592}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272629632}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tested"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272629673}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272650242}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272650305}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272650359}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272650406}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" response"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272756830}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272756900}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272756944}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757008}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757051}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757107}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757148}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Built"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757205}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757243}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757288}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757326}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757363}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" single"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757404}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757534}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757585}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757641}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272757699}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concept"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272767413}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272781769}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272781813}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272797784}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Quiet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272797854}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Viv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272797932}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272814382}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272814428}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272814491}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ist"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272829739}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" noct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272829802}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ur"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272842690}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ne"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272842752}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" under"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272842805}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272859058}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272859098}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272879281}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cabinet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272879322}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272893013}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272893057}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" weather"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272918881}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272941026}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272941075}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272941126}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272941193}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272941248}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Key"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272941316}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" functionality"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272959263}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272975131}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deterministic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272975193}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272975237}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272988926}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" genes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979272988984}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273000822}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273000876}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" system"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273013691}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273029882}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273029970}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273049232}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273066119}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sparks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273075170}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273075232}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273090973}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273091047}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/key"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273091127}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"board"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273105308}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273105359}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273105428}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273105500}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273120375}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273135047}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273135120}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273149900}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273150026}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273150100}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273150162}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273165236}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273165310}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273165365}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273186245}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" usage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273186296}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" snippet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273198165}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273198209}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273198254}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273211342}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273211388}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273226590}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273243736}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273243783}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273257187}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273257249}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273257295}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273282359}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273282439}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273282491}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273291008}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ends"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273291068}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" automatically"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273307716}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273307784}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273307866}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Testing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273325102}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273325175}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273325217}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verified"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273343990}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" determin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273344064}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273356267}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273356330}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273356385}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273356453}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273378762}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273388604}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273388709}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273397115}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273397189}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273397245}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" details"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273397305}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273412048}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273412111}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" useful"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273412167}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273425900}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273426010}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273426084}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" asked"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273426140}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273441375}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273457696}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273457768}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273457837}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" confirm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273457888}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273472534}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273472592}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273472638}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"down"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273488447}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273488515}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273488573}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273488617}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273504022}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273504066}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sections"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273504117}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273518650}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bullets"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273518738}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273518802}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273535612}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273535687}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" snippet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273555348}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273555422}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Des"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273555476}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ired"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273570286}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273570346}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"verb"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273570433}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"osity"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273570487}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273570537}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273570589}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273581401}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moderate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273581457}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273595294}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273595367}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" images"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273595425}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273619890}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273628928}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273645476}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273645532}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Open"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273645600}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273657229}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273657305}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" directly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273657363}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273677503}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273693128}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273693175}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273693227}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273693273}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273693328}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" claim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273701679}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273701750}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inspection"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273722768}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273722854}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273735478}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273735549}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273735670}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273748078}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273748138}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273748201}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273748248}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" command"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273762439}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273762491}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"```"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273762533}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273776759}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273776824}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"window"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273776868}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".V"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273776922}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"iv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821043}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821084}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821153}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821223}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821274}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"({"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821341}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821397}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821448}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821515}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"73"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821566}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821608}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273821648}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273823182}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273823248}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273823305}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273823378}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273823435}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Rate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273839972}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273840016}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273840068}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273840106}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273840143}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"09"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273855130}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273855188}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273855241}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Reg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273855297}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rowth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273855353}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273855406}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273881009}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273881091}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" });\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273884537}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"window"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273884579}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".V"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273899820}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"iv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273899887}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273899922}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273899974}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"();\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273900028}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"```\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273920907}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273920976}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273921033}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273921084}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273933208}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273946761}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273946825}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273946865}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273946917}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273961614}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273961684}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979273975503}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"73"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274037660}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274037714}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274037779}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274037850}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274037906}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274037946}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274038003}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274038069}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274038136}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274038230}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274038313}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274038370}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reprodu"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274051809}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ces"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274051852}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274066992}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274067035}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274067117}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274067170}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274067242}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274082773}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274082818}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274098392}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Keep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274098446}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274098495}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274098550}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Built"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274112450}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274112504}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274130339}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274130387}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274151208}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274151266}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274151327}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" —"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274151403}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274151455}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" single"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274151526}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" self"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274159642}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-contained"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274159733}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274159775}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274159832}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274174525}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274191564}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274191607}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220341}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220476}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220520}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220576}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" libraries"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220641}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220683}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" fonts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220736}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220780}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274220829}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274235158}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" requests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274235214}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274235268}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274235334}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274235384}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" direction"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274250501}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274250552}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" *"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274266601}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274266689}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Quiet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274266745}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Viv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274281832}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274281879}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"*"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274281923}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" —"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274281980}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274282010}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" noct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274282052}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ur"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274295735}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ne"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274295795}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" natural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274295841}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ist"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274311298}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"’"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274311336}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274332182}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" plate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274332251}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274344040}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Warm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274344118}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" cream"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274362322}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274362417}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274376954}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" deep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274377043}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" moss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274377106}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274390799}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274390871}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" brass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274406350}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" instruments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274406410}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274420096}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274420164}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274433445}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" scientific"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274433488}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" typ"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274450718}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ography"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274450771}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274450814}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Latin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274463805}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274481196}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274498032}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274498106}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274498175}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" three"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274498241}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274511820}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" languages"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274511908}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274528251}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274540518}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274559679}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"oss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274559753}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" sp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274572335}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"rig"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274572413}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274572482}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274586924}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274586994}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"inder"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274604334}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" moths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274604458}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274604548}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274616744}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274616819}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" owls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274632339}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274652078}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274652182}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274662194}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"rophes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274662289}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" arrive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274662366}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274679212}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" pressed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274679269}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274679322}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"weather"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274694695}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" seals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274694758}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274694813}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274694865}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274709343}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274709392}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274709434}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" echoed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274709469}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274724484}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274724560}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274724618}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274740439}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274740506}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274756574}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274756646}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274756690}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274756737}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"cluded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274769871}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274769946}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"**\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274792412}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274792454}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274792490}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-start"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274803625}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274817073}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" deterministic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274817190}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ecosystem"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274817257}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274832445}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" evolving"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274832513}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" prey"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274851583}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"/p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274867312}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"red"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274877737}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ator"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274877787}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" gene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274877829}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" vectors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274895278}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274895322}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274895370}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274912188}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" vision"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274912229}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274912277}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" metabolism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274912316}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274924379}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" reproduction"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274924481}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" threshold"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274924526}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":").\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274940965}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274941013}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274941078}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" census"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274957410}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274972357}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274989265}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"/t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979274998957}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"empo"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275014521}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275033467}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"outs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275055111}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275055183}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275055280}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" dial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275060615}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275078400}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" sl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275091794}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"iders"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275091844}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275107229}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ste"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275107283}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ppers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275107359}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275107428}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275107494}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"gg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275121902}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"les"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275121968}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275122051}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275122137}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275136443}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275136496}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275151734}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275167471}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275167536}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275167586}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Config"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275167636}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"urable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275185232}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" drought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275185304}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275197221}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" plague"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275197287}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275213137}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275213184}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" eclipse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275213241}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" schedules"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275213285}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275230694}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" screen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275230783}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" tints"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275244310}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275244392}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" weather"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275244443}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" seals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275258428}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275258471}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" bullet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275258529}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ins"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275272739}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275272778}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275272830}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275272871}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"/ch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275287637}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"art"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275303673}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" markers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275303736}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275303779}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275303850}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Coll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275303929}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"aps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275319095}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275319158}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275319204}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" cabinet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275333979}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275334041}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275334088}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275349478}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275349605}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275349714}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" keyboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275349777}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" shortcuts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275364808}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275380050}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275380095}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275380150}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" states"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275380207}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275394442}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275394521}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" responsive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275394568}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" layouts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275410404}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275410446}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275410497}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275410533}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-generated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275439729}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275439788}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275440406}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275440468}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275456011}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275456108}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275471802}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" curves"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275471853}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275486873}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275486924}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" markers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275501720}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275517694}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275517748}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" four"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275517784}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275534427}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-dr"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275534501}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ift"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275549528}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275549611}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" showing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275549680}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" mean"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275549736}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ±"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275564135}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275564194}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"σ"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275580112}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275580180}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" both"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275594857}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275594911}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275610704}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275610778}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275610822}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" Fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275610876}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275625601}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275625648}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275639746}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" exposed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275654989}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275674440}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275674507}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275674561}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275674611}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275674662}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ```"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275674728}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275686580}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275686620}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275686657}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" window"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275686690}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".V"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275686728}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"iv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275700568}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275700615}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275700670}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275700736}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275700771}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"({"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275700818}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275719811}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275719882}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275719924}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"73"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275719971}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275730867}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275730904}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275730943}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275730978}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"24"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275731017}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" });\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275746168}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275746232}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" window"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275746282}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".V"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275746331}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"iv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275746390}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275746463}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275746507}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"();\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275762314}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275762373}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" ```\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275762427}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Verified"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275762485}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" deterministic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275776630}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" runs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275776688}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275790798}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" offline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275790872}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" operation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275807778}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275849319}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275849373}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275849423}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275852106}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275852155}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" scheduling"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275867415}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275910262}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" responsive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275910319}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" layouts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275910370}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275910410}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275910449}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275913144}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"/re"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275913193}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"port"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275929007}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" flow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275929048}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275943346}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275943411}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" zero"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275943443}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" console"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275959120}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275959163}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2106,"ts_us":1792979275975979}}

data: {"id":"1a09f81bbbf96d47e20a9abb6722d1e5","object":"chat.completion.chunk","created":1792979271,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":562573,"completion_tokens":612,"total_tokens":563185,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":562432,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":293,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2106,"ts_us":1792979275979019}}

data: [DONE]

