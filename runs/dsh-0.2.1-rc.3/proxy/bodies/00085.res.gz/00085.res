data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359141091}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359198177}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ledger "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359198336}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"402.7, row y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359198521}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"339"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359286133}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6. Good. Traits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359286268}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probably start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359286578}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~? The ledger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359286719}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359435099}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359435167}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" header padding reduced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359435225}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359435278}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359467563}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 339"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359467811}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6. Pop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359467951}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel likely 402."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359468049}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 or content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359673124}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 381. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359673261}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359673327}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report responsive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359673701}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359782496}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xi3defnrhukratnucezaz9bt","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359782674}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359782823}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359782937}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359783037}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359783143}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359783261}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359783372}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359783469}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359783568}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359783682}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"port"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359783807}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"responsive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359784375}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359784656}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359784869}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785009}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785125}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785243}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785422}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785575}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785702}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785790}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785871}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359785969}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IZE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359786069}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359786195}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359786315}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359800534}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359800622}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359800692}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359800761}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359800807}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359800862}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359800925}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359800995}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359801060}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359803543}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-me"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359803645}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"asure"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359803803}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359803856}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359823476}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" compact"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359823605}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ledger"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359823769}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359823835}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7017,"ts_us":1792977359934226}}

data: {"id":"52c8ad5cd0540824d3910e54a792411a","object":"chat.completion.chunk","created":1792977359,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":394928,"completion_tokens":133,"total_tokens":395061,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":389760,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":54,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":7017,"ts_us":1792977359934442}}

data: [DONE]

