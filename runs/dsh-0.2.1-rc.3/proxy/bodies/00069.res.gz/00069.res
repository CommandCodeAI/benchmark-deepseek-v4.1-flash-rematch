data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836713480}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836713579}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836713634}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" heights"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836861303}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836861411}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_42wudxeg60czsjckcwvmfaf5","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836861678}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836861781}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836861865}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836863001}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836863087}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836863173}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836863295}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836863386}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836863483}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836863581}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"measure"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836864101}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836864399}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836864500}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836864922}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836865035}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836865181}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836865280}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836865338}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836867469}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836867544}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836867606}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836867737}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836885916}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836885990}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836886040}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836886095}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836886146}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836886221}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"works"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836886316}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836886391}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836901333}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ab"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836901622}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inet"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836901700}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Scroll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836901852}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836931572}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836931756}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Foot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836931833}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836931881}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836948091}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836948176}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836948238}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836948423}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836967429}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Foot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836967501}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"):"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836967608}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836968341}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976836999902}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837000014}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837000088}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837000282}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837096282}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837096540}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837096608}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837096886}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" drawer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837100880}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" overflow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837101299}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837101377}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837101552}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2562,"ts_us":1792976837150548}}

data: {"id":"960eeeccd97799b12c43008926688131","object":"chat.completion.chunk","created":1792976836,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":336896,"completion_tokens":98,"total_tokens":336994,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":336384,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":4,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2562,"ts_us":1792976837150827}}

data: [DONE]

