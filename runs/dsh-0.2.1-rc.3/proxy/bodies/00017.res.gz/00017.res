data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892004227}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892004347}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892004382}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explode (birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892104146}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s crazy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892104256}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" between gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892105225}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 and 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892105294}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892168434}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892168492}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892168552}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20105"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892168621}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" total weird:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892246924}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my birth counter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892247110}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" monkeypatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892247235}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increments every tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892247435}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" once"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892328559}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy>=threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892329139}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892329220}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892329279}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" attempts, not actual; perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892419029}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aborted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892419104}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892419164}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892419293}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap? births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892529151}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 201"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892529199}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"05 means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892529274}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892529355}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" called every tick by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892577008}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many once"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892577086}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy threshold; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892577126}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892577184}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actually push"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892689074}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe capped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892689282}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892689529}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Regardless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892689842}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892748751}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reaches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892749150}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 620."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892749451}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Plants crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892749723}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892834188}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stronger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892834263}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892834404}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892834538}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892922067}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892922114}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" realistic plant model.\n\nWhy plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892922498}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974892922575}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893014908}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 even with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893014962}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1680 plants and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893015013}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893015061}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3? Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893083097}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893083164}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 618 eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893083208}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enormous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893083270}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893223111}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps. Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893223192}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" absent. Without predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893223248}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893223335}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eventually hit carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893272230}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity where"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893272299}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food-limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893272376}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893272440}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" do:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893372354}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893372452}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893372523}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893372628}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"33 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893469459}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893469531}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893469586}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-bust is normal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893469642}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893575682}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" severe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893575732}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893575920}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators can cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893576226}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" complete"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893600276}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction. If we include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893600529}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators, their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893600796}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles can stabilize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893601026}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893668017}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" collapse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893668095}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed examine predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893668150}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893668405}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893746232}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" balance."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893746360}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_6hkiwsfg9x0qo3g8kbv74k4j","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893746629}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893746870}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893752726}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893752794}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893752998}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893753263}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893775968}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893776021}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893776165}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893776215}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bug"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893792839}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893792909}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893793369}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893793450}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893830449}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893830595}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893830774}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893830835}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893877146}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893877256}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" revised"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893877331}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" predator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893877394}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893932373}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893932453}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" balance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893932689}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893932755}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2085,"ts_us":1792974893942006}}

data: {"id":"92bfc0c667fa57c5bf79e73f768cb010","object":"chat.completion.chunk","created":1792974891,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":69403,"completion_tokens":253,"total_tokens":69656,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":67456,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":191,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2085,"ts_us":1792974893942191}}

data: [DONE]

