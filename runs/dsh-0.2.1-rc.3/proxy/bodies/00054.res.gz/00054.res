data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528579655}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"App"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528579735}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height 1400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528579761}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528668176}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440 view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528668301}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"port—"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528668514}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528668559}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"uge!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528727145}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Something is wrong"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528727198}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" causing workspace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528727246}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tall."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528727298}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Likely the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528793786}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cabinet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528793930}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528794024}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"flows? `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528794066}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"app` min-height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528898764}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100svh but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528898834}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height auto?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528898893}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" On desktop body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528898953}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" app min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528953067}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-height but workspace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528953119}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flex; content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528953353}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" causing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976528953429}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529050511}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cabinet control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529050555}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content height maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529050619}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 900. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529050693}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529127797}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1400. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529127846}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the `.ter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529127888}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rarium` flex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529127928}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529197851}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529197902}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fixed height because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529198036}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529198075}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"workspace's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529282942}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min-height "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529282999}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 but app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529283121}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529283279}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t have height set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529355734}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; `.app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529355937}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` min-height:100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529356980}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"svh but content with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529357023}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529435678}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can exceed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529435737}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529435873}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to `.ter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529437166}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rarium` min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529588210}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-height 340 and controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529588264}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529588431}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529588699}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_7ewgvxctm0zmmxr4ihm7ba2h","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529588806}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529589061}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529589417}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529589506}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529589576}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529589667}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529589741}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529589840}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529603877}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529603964}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529604138}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529604304}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529611942}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529611989}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529612054}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529612117}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529633972}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529634028}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529634067}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529634123}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529655934}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529656030}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529656110}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529656187}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529656413}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529656489}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529656561}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529657235}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529671910}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529672024}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529672274}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529672354}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529690332}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529690429}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529690660}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529690745}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529716847}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529716940}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529717191}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529717273}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529717462}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529717563}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529717722}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529717945}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529728624}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529728714}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529728812}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529729402}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529747766}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529747869}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529747952}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529748039}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529785180}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529785259}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529785706}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529785779}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529862654}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529862725}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529862769}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2569,"ts_us":1792976529868924}}

data: {"id":"297c1c413531059931ee2bc8680cc340","object":"chat.completion.chunk","created":1792976528,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":287140,"completion_tokens":223,"total_tokens":287363,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":286464,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":135,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2569,"ts_us":1792976529869044}}

data: [DONE]

