data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465150900}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465217375}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" error because `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465217448}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"window.Vivarium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465217510}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".current()` returns `exportResults"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465251435}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` which lacks catastrophes."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465251510}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not app"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465251578}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug. Need adjust test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465251708}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465337831}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pressing Space with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465337991}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus on the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465338205}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465338279}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checkbox, our global"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465429002}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handler likely returned"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465429442}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465429514}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ButtonLike includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465429593}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checkbox; native to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465516194}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ggled. It did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465516333}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465516435}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; good.\n- When"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465516531}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465583195}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ggling enabled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465583286}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465583353}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465583421}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465684092}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465684148}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reflect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465684466}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465684527}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465798737}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5. Need test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465799591}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465799659}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465799701}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465883621}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40% for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465883696}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10/25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465884041}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yes.\n- Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465884139}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465939978}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5. good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465940037}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Tooltip not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465940124}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reached due test crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977465940401}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's rerun rest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466027796}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466028067}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `window.Vivarium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466028511}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".state()` for catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466028617}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes. Also note in `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466116131}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"current`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466116224}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466116292}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466117838}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"catastrophes`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466182850}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" absent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466182906}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466182960}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", API"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466183078}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466294198}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" returns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466294278}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim results. Could include config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466294335}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466294754}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" export;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466372168}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not necessary. Update test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466372255}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466372321}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8i0pa0mav3tvul9f6q07t1tb","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466372400}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466382597}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466382688}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466382891}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466383171}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466443721}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466443918}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466444025}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466444200}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466466634}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466466712}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466467006}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466467058}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466483310}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466483392}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466483446}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466483496}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466483749}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466483794}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466483843}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466483884}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466517905}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466517963}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466518107}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466518190}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466525419}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"control"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466525487}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466525540}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466525604}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466525887}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466525961}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466526028}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466526087}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466533494}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466533580}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466533638}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466534895}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466544310}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466544950}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466545024}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"next"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466545092}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466568691}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466568762}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466569331}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466569420}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466569592}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466569663}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Next"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466569734}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466571106}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466583577}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466583656}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466583709}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466583751}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466602894}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466603257}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466603316}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466603383}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466616641}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466616712}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466616784}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466616843}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466630818}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466630987}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466631173}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466631253}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466666437}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466666495}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"next"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466666624}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466666705}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466666862}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466667555}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466667630}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466667729}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466678726}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Next"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466678780}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466678859}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466678937}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Content"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466767582}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466767680}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466767771}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768048}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768144}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768229}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768311}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768410}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768501}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768572}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768664}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466768750}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466772299}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466772386}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466772469}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466772549}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466772626}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466772703}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466772779}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466772875}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466786140}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466786235}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466786315}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466786392}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466791767}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466791862}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"control"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466791940}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466792105}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466830293}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466830397}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466830478}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466830637}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466832037}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466832135}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466832420}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466832517}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466851013}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466851073}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"er"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466851164}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"un"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466851980}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" remaining"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466870998}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" control"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466871094}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466871165}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466871232}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13626,"ts_us":1792977466934272}}

data: {"id":"25b952d865c58d3bb398019f4e542891","object":"chat.completion.chunk","created":1792977465,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":404723,"completion_tokens":323,"total_tokens":405046,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":402432,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":166,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":13626,"ts_us":1792977466934381}}

data: [DONE]

