data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161532973}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161533074}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pkill matched itself"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161533120}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161619845}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" careful. Run balance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161619932}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161620000}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_34lfjzrtn8109k1z0b3qaku4","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622414}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622476}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622537}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622583}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622673}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622759}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622820}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622893}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161622969}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161829146}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"balance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975161829240}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162026900}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162026990}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162027062}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162027143}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162027219}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162027283}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162074989}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162075070}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ret"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162075133}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162075226}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" demographics"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162075400}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162075828}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" persistent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162075913}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" plants"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162075988}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162077373}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2611,"ts_us":1792975162077445}}

data: {"id":"3fc3286e1a1fc1c6caf1885b465ee489","object":"chat.completion.chunk","created":1792975161,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":89321,"completion_tokens":75,"total_tokens":89396,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":87296,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":13,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2611,"ts_us":1792975162077569}}

data: [DONE]

