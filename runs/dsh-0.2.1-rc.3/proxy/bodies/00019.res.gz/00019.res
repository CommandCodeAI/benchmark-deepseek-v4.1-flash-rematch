data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920122523}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920122623}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920122665}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but extremely static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920122856}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920122937}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey barely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920123010}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproducing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920123055}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (137"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920123147}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920123232}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920123277}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~140"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920123328}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920178797}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920178871}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920179017}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920179105}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slowly. Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920264341}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920264403}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920264493}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproducing despite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920264680}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920410411}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants and threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920410469}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lowered?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920410555}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Average energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920410854}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920431157}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920431199}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~80"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920431412}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920431720}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" don't eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920509137}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920509258}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920509521}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920509921}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920589082}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920589139}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count stays ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920589237}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"140, so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920589321}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" there"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920678395}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920678732}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be births offset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920678806}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ting deaths,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920678891}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920840741}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deaths. Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920840796}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920841271}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920841323}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_508xduj58tiwsewdris1juqh","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920841374}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920841453}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920841538}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920841987}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920842035}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920842082}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920842130}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920842174}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920842967}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920843180}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920843229}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920843270}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920897380}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"184"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920897430}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920897545}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920898158}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920959920}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920960121}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920960162}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920960443}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"09"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920967936}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920968051}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920968258}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920968662}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920968721}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920968912}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920970417}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974920970599}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921047408}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921047474}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921047840}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" revised"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921048358}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921053078}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921053378}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921053440}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921053577}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921198286}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921198374}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2589,"ts_us":1792974921198438}}

data: {"id":"18ef739fa57ad701ee8bee1e2d8e024b","object":"chat.completion.chunk","created":1792974919,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":73299,"completion_tokens":160,"total_tokens":73459,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":70144,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":86,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2589,"ts_us":1792974921199279}}

data: [DONE]

