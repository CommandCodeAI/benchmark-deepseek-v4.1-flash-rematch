data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979084713166}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Syntax"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085086952}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085220610}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085239101}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085239172}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085239224}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verify"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085239275}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085250508}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" variable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085250567}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" name"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085269295}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" conflict"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085269355}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085269411}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085283400}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085283465}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085283512}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Review"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085283585}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085301919}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"sync"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085301960}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085330981}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085331041}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085331290}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085331346}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085331382}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085331418}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085365078}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085365137}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085365176}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" (!"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085365260}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"els"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085393131}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085393182}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"peed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085393269}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Dial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085393334}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085393375}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" return"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085393442}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085407758}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085407827}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085407879}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" declares"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085407926}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085427549}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"const"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085427593}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sec"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085427734}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085427772}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085457006}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085457057}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085457118}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085457161}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085475439}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085475504}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" There"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085475546}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085475600}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085488859}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" later"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085488941}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085489004}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"const"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085497870}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sec"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085497941}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085497996}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085498026}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085498069}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085498106}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085511288}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085511350}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085511415}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085511486}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085511540}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085530241}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085530288}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085547766}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085547814}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085565525}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"sync"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085565606}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085579777}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"From"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085616651}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"State"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085616704}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085616776}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085616845}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085616888}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085616935}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085624352}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085624422}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" calls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085624486}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085624548}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"sync"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085624597}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085637907}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085637998}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085638062}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085638118}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" calls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085638167}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085638232}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"update"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085655698}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"T"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085655747}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"empo"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085655829}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Rem"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085655910}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aining"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085655964}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085656004}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085673301}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" references"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085673399}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085673477}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"state"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085673542}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085673616}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"im"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085692865}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085692969}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085693062}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085693148}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085709775}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085709992}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" updates"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085710064}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085727126}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tem"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085727216}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"po"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085727304}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sub"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085727384}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085737581}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085737666}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085737731}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085737790}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085737856}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085737920}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085750122}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085750199}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085750277}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085750366}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085766534}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085785016}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-g"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085785110}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085804534}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085804629}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085816057}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085816140}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085816207}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085829706}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085829796}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085845039}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085845129}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" y"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085845201}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-axis"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085859195}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085859269}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085876344}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085876391}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085892484}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085908687}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085908755}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085908845}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085921846}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085921907}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085921958}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085922012}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085922055}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085922103}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085949545}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085965296}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085991516}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"led"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085991563}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085991682}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979085991754}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086021029}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086021096}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086021148}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086021337}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086021412}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086044872}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086044921}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086044976}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086061101}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086061153}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086061192}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086079571}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086079636}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086094341}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086094412}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086115848}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086115935}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086116010}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086116065}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086116141}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086116260}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" attribute"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086116322}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178502}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178547}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178627}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178699}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178753}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178802}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178853}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178907}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086178952}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086179034}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086205146}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086205208}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086205363}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086205435}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" legend"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086216955}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086217013}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086245564}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086245636}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" href"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086245693}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086245742}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086245810}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086245907}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" symbol"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086275817}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" definitions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086275952}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086303991}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086313876}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086328464}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086328531}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sprite"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086328592}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086328687}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086328725}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086342073}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086342139}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086342241}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086342316}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086342366}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086362712}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086362793}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086362841}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086362889}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086371534}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086371576}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086410561}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086410619}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086410654}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086410720}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086436728}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086436788}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086436835}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086439034}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086459978}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086460028}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086460082}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086460131}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086460185}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086460240}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086474517}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" date"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086474571}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086486301}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086486346}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086511580}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mobile"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086517273}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086517342}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086517399}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086538457}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086538507}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086562763}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086562846}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086562898}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" improvement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086563046}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086563123}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086563170}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086592228}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086592278}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"sheet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086602723}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" number"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086602800}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086619850}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086636374}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086636453}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086646468}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086646519}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086659479}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086659540}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Already"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086659597}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086675549}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086675595}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086675658}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086675718}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086675768}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086675812}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086675864}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086691177}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086691223}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086707932}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" single"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086707973}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086723452}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086723518}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086723560}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086723620}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086723696}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086741832}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086741874}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perform"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086741927}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086754824}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086771202}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086771256}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"full"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086793986}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086794068}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" smoke"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086794136}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086810959}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086825735}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086825781}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086825825}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086846659}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086846709}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086846790}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"900"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086856979}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086857025}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capturing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086857094}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086872157}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086872232}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086889211}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086889262}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086889315}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086906108}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086906170}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" console"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086906219}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086921792}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086933149}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086933194}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086933236}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086933294}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" image"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086948645}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086963880}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086987987}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086988037}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086988089}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" metrics"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979086998517}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087011599}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087011657}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087011723}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087026980}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087027035}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087041779}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087041857}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087060176}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" match"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087073940}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087091887}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087107461}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087107513}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087107573}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087122897}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087122950}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087140168}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087140234}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087140276}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087140328}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087140406}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087162969}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087163014}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087177503}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087177557}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087189483}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087189549}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087207357}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087207418}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087207470}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087207536}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087219582}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087234069}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087234140}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087254368}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087268135}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087268218}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087268311}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087268376}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087281674}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087281746}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087281799}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087281851}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087281904}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087307146}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087307225}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087307272}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087307321}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087335107}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087335170}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"102"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087335283}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087335350}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087335401}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087354572}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087354659}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087393455}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087393519}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087393574}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087393647}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087393701}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087398229}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087398290}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" suite"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087416601}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087416688}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087432709}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087432785}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087432847}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087432882}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087545967}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546108}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546162}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546285}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546342}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546393}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546447}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546561}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" determin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546613}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546733}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546807}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546884}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546934}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087546977}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087547157}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087547204}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087547691}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'ll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087547746}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087547798}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087565544}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087565614}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087565667}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087587910}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087587962}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087607008}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087607052}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087698574}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087698658}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tested"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087698706}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087698890}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087698952}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699016}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699074}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699333}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699401}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699452}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699567}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" assets"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699667}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699764}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699811}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'ve"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699860}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" done"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087699938}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" most"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087718194}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087718260}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087718300}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087718360}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087718411}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087730664}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" consolidated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087730737}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087745210}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" QA"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087745273}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087763510}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" against"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087781920}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087781985}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087800786}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087800844}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087800905}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Load"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087800966}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087813605}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087813701}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087813782}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Assert"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087813852}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087825931}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087844480}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087844538}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087859497}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"bound"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087859565}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087874517}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087874619}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087908014}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087908108}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"port"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087908165}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087908222}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087908294}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087912451}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087912519}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087912571}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087912623}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087912736}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cabinet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087929940}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087930021}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087946338}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979087946392}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"538"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088005915}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088005995}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088006055}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Wait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088006120}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088006186}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088006227}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088006264}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088006302}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088012093}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088012156}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088024921}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088024983}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088025037}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088025088}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088044498}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088044572}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088062608}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088062694}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088062774}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" until"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088062833}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088076460}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088092679}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088117350}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088127264}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088145841}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088145915}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Full"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088145981}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088161453}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088174237}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" takes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088174316}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088174389}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"15"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088194504}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088208956}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088209038}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088209123}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'ve"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088209194}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tested"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088228951}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088229032}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088229113}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088229181}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088260365}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088260459}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088260526}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088260590}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088278893}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" console"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088278986}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088296811}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088296918}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088296984}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088297052}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088316713}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088316801}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088316865}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088329971}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088330066}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088330130}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088330213}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088342741}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" click"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088342976}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088343056}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088359519}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088372412}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088387748}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088387799}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088387835}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088387871}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088401178}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088422093}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088422165}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Take"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088422217}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088422272}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088435900}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088435962}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088436040}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088452588}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088478459}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088478521}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088478573}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088492462}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" “"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088501953}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088502004}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088518957}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088530102}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" faster"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088547723}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" than"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088547778}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" real"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088562966}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088563012}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"”"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088563057}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088563102}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088563160}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088578159}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088597203}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088597255}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088627752}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088627817}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088627967}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088628026}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088644773}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088644833}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" instrument"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088644884}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088662860}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088675606}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088691122}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".draw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088691168}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" isn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088705966}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088706024}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" called"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088706064}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088706108}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cond"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088706143}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ensing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088726883}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088737653}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088737711}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088737798}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088753798}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088753845}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088753887}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088753942}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088809359}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088809437}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088809509}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088809557}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088809598}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088809659}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088818156}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088818216}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088818255}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088849945}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088857839}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088867977}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088868032}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" embedded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088893251}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088893295}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088908501}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" own"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088908583}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088932019}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088932072}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088932127}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088932257}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088932313}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088959247}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088975617}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" separate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088993412}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088993473}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088993521}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088993638}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088993688}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088993733}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pattern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088993795}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979088993856}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/*"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089021134}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"__"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089021201}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089021257}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ORE"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089038375}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"__"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089038434}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"*/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089038557}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089038631}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" replaced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089038684}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089055641}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089055720}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089055799}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089055864}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089055923}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089070987}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" DOM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089071076}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089071136}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089089261}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089089334}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089110205}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089110290}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089110383}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089110431}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089110511}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089110585}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089139426}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089139499}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"type"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089139538}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089139778}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"module"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089139858}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089139906}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089165369}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089165433}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"://"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089187466}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089187584}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089187640}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089187677}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089218176}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089218232}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089218272}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089218326}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089218370}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089218397}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089243520}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089243587}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089267222}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089267293}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089267361}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"raw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089282315}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089308118}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089308179}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" none"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089313872}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089334946}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089335016}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089335075}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089349816}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089349885}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089349934}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089349976}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" about"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089366090}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089366136}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089366208}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089366292}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browsers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089380393}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" without"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089396189}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089396240}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Bit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089411029}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"stream"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089426205}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Charter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089426271}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089445981}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089446038}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089446081}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089465178}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089478520}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089478566}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089498775}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089498841}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089498879}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089522857}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089522920}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089522973}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arrow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089523091}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089523173}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089523210}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Georgia"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089523251}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089552862}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089552944}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089552992}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089575262}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089575336}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089575401}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089575453}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089575563}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089575615}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089575657}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089603456}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089603601}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089603656}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089603719}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089603776}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" {"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089603830}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" white"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089603890}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-space"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089627992}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089628064}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089628121}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089628182}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" }"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089628239}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089628283}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089648105}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089648159}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"106"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089663328}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089663401}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089663444}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089663497}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089663535}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" container"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089680728}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089680782}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089695132}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089707989}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089708094}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089720438}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089733354}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089733411}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"59"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089746534}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089746594}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089746633}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Georgia"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089746696}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089762763}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089785264}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089785373}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089785428}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089796142}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089810700}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Quiet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089810744}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Viv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089828651}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089828709}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089828750}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089828807}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"17"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089828864}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chars"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089845814}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089845879}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" average"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089863852}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089863917}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089863954}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089887196}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089887258}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"52"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089887306}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"em"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089887343}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089887380}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"30"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089887413}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089904511}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089904554}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089904616}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"*"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089904654}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"17"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089920340}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089920388}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"522"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089920442}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089934174}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089934218}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089934285}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089934335}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089946506}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089946568}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"106"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089957428}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089957474}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089957512}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089974319}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089974364}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"532"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089974413}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089990174}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089990223}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089990260}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"43"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979089990307}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090002916}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090002967}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"43"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090021992}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"*"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090037140}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090037189}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090037225}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"52"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090037260}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"*"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090053125}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"17"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090053172}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090053207}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"380"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090053241}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090066468}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090066534}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090066592}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090066641}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090081778}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090081849}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090081905}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090081947}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wrap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090098064}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090098105}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090113867}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"390"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090113931}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090132562}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090147102}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" white"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090147155}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-space"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090147207}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" normal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090161310}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" under"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090177428}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090195504}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"106"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090195558}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090195604}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090195655}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090195695}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090195754}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090209685}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deck"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090209754}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090209802}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090225514}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090225583}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090225637}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090242501}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" metrics"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090242565}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090257983}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" make"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090258037}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090258085}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090275469}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wrap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090275516}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090290892}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090290938}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" flex"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090291039}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090306901}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090306976}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expand"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090320782}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" heights"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090320845}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090338592}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090352983}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drawer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090353071}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090370447}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090370490}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090385332}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ide"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090406579}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090453308}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090453363}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090453420}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090469331}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090486925}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090509215}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090526133}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090540587}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090540644}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090540704}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090540752}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090562490}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090562543}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090567237}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090578729}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accessible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090578792}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090593486}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090593531}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090593584}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090593635}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" micro"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090593687}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"type"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090609422}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090626102}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" heights"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090626164}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090641542}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090641599}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090641646}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090658834}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090658879}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090658975}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090659050}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090674849}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090674897}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090674952}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090674994}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" installed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090707811}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" differently"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090710669}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090710711}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090733330}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"back"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090733405}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090733447}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ospace"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090743338}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090743392}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090743428}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" support"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090754032}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090768736}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090784317}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"№"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090784379}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090800830}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090800879}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090800956}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"−"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090815569}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090815617}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090815662}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090832696}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"×"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090832760}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090832813}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Most"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090832855}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090847588}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090863976}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090864023}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090864075}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090864116}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" characters"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090883531}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090883583}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"❧"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090912773}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090928323}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090928381}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" toast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090928414}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090942816}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090942867}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090942918}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090959966}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090960015}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090960078}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090975440}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-mark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090975493}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090975549}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090975602}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979090993452}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091009971}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091010038}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091010085}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" literal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091027561}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leaf"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091027603}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091039019}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"❧"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091039078}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091039128}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091064441}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091086220}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091096865}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" markup"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091096929}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091096960}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Search"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091112607}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091112681}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_RPH8Qf5HTI9dHF9lKYDu5015","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091146799}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091160860}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091160966}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091161027}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091161072}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091178359}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091178433}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091178497}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091178530}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091195142}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091195193}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091195241}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"❧"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091195319}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091195411}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"№"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091203584}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091219971}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"−"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091220025}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091240229}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"×"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091240293}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091240344}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"σ"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091240401}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091256468}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"·"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091256548}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091269086}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"—"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091269165}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091293089}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"–"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091293148}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091300594}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091300652}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091314610}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091314671}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"emplate"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091314789}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091314850}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091314917}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091314964}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091330161}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091330216}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091330295}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091346837}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091346889}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091346966}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091357873}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091357943}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091358006}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091358064}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" special"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091375661}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" glyph"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091375728}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" fall"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091375772}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"back"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091396191}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" usage"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091396239}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091450052}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1901,"ts_us":1792979091450140}}

data: {"id":"96d27238a5a1aba75f8ee7f985bad9bd","object":"chat.completion.chunk","created":1792979084,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":540996,"completion_tokens":1030,"total_tokens":542026,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":540416,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":942,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1901,"ts_us":1792979091455327}}

data: [DONE]

