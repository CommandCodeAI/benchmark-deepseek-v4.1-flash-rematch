data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451212778}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451212876}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright installed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451212922}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need see"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451262393}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browsers."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451262453}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_6sy49ocjmwvb8dhf3loq4aq4","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451262816}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451268447}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451268522}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451268595}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451268661}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451268723}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451304607}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451304681}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ~"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451304848}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451304995}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451305181}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451305407}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451305554}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451305816}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451358903}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451358984}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451359054}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451359117}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451409697}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451409769}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451409830}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451409916}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451433207}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"root"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451433280}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451433339}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451433397}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451442120}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451442185}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451442240}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451442297}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451449977}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451450025}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451450070}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451450113}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451506231}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451506314}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" playwright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451506384}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451506454}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451527694}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451527775}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451527848}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451527919}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451581103}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451581182}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451581243}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451581305}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451581362}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451581419}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451581474}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451581529}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451601388}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451601474}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451601538}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451601599}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451611762}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451611902}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451611974}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451612040}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1050,"ts_us":1792974451679792}}

data: {"id":"cbe1b19a8a6f0a43e36765705879c283","object":"chat.completion.chunk","created":1792974451,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":15753,"completion_tokens":102,"total_tokens":15855,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":15360,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":8,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1050,"ts_us":1792974451680226}}

data: [DONE]

