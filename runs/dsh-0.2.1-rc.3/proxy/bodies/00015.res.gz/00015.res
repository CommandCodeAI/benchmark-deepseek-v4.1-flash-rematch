data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876183298}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876183371}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s chewing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876184464}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876254613}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 98% CPU. Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876254986}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876255034}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876255086}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"238ms then second run hangs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876413973}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Could be because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876414064}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876414141}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after \"ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876414315}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 238\" not flushed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876464944}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The second simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876465039}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876466558}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; maybe determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876466649}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism test infinite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876543099}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because of RNG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876543183}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or array"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876543235}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876543285}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Wait `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876646081}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"sim2` new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876646149}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876646190}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm. Did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876646239}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the first output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876746694}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876746870}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show all "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876747820}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24 gens and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876747905}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ms; so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876797576}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876797738}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" done. Then new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876797950}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876798007}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should be same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876887320}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe memory"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876887390}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The loop condition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876887454}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876887516}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (let g = sim2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876971507}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generation; g < gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876972156}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";) sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876972233}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.step();` doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974876972286}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t update g!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877050986}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Ah yes first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877051049}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop updates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877051100}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" g inside if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877051155}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; second loop no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877127407}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update. It runs until"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877127469}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877127521}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24 yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877127554}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" g remains "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877280748}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877280806}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" infinite. My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877280918}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test bug, not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877280976}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim. Kill background job."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877297675}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_vbz4kh03ezf0fxyt5wogoh4z","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877297769}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877297833}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877298567}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877299981}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877300956}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877301216}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877301296}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"kill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877387673}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877387749}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"428"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877388428}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877388496}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877388555}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877388619}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877388676}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877388725}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877398333}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877398415}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877398469}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877398526}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877416792}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877416845}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877417355}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877417485}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877419628}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877419703}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ef"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877419795}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877419849}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877465941}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877466012}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877466064}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877466420}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ode"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877466590}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877466670}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877466754}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877466821}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877466952}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877467033}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877467097}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877467168}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877505081}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877505172}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877505345}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877505426}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877523354}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877523433}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877523493}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877523569}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877539508}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" infinite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877539606}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877539720}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" process"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877539815}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877617622}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2064,"ts_us":1792974877617712}}

data: {"id":"04755fd6f06726b4d775f566ab4cb52b","object":"chat.completion.chunk","created":1792974876,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":66915,"completion_tokens":247,"total_tokens":67162,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":62592,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":159,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2064,"ts_us":1792974877617826}}

data: [DONE]

