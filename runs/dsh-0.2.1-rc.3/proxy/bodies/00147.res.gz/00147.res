data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979266431679}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267458536}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267633900}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267663739}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"28"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267663790}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267663843}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267663902}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267667108}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"hots"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267667175}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267667228}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Remove"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267667255}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267682179}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267682231}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_dM4Rbiy8gR7fsRYfQt5u2630","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267732230}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267732294}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267732340}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267746258}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267746328}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267746377}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267746434}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rm"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267758566}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267758619}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rf"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267758698}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267758787}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267775629}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267775682}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/cl"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267790555}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"aude"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267790640}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267790702}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267790745}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267805700}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"home"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267805755}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-user"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267805800}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267805841}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267805879}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267805919}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267837774}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"172"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267837860}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267837932}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267838000}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267838067}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267838129}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267838169}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267838266}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267838320}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267838385}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267838486}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267853371}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267853458}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267853509}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"71"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267853580}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267870756}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"905"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267870816}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ce"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267870879}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"402"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267870954}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"614"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267871016}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267884692}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"scr"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267884779}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"atch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267884857}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267884926}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267884996}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267904248}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267904360}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267904424}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267904482}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267904563}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267904628}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267921090}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267921148}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267921195}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267921273}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267921350}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267936272}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267936346}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267936405}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267936449}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267954346}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267954467}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267954548}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267954618}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267954678}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267964578}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267980742}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267980817}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267980887}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267980956}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267981027}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267997013}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Remove"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267997080}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" development"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267997122}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" artifacts"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267997175}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979267997220}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" keep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979268013712}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" deliver"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979268013802}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"able"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979268013867}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979268013940}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1800,"ts_us":1792979268026571}}

data: {"id":"03dbe5ee2d2bae6a8f1a47229484c517","object":"chat.completion.chunk","created":1792979266,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":562333,"completion_tokens":131,"total_tokens":562464,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":562048,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":12,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1800,"ts_us":1792979268057331}}

data: [DONE]

