data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831073018}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Measure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831073164}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output includes Node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831073227}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" warning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831166867}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831167001}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stderr hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831167528}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831168227}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ["},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831309810}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"stderr] etc not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831309868}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" JSON? It prints"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831310007}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" object with un"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831310058}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"quoted keys. Use grep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831406694}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831407114}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_i6kdy15109030mq9ogn8larc","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831407202}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831407317}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831407530}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831407604}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831407977}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831408478}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831411363}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831411464}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831411632}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831411743}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"measure"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831413669}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831413846}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831452029}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831452126}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831452212}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831452287}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831452353}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831452459}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831453044}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831453337}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"35"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831453382}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831453428}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831470243}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831470324}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831470392}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831470454}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831495610}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831495693}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831495762}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831495824}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" layout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831571395}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" measurements"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831571752}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831572527}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3369,"ts_us":1792976831588471}}

data: {"id":"6bfebcaf2728497521275bc33261b5a0","object":"chat.completion.chunk","created":1792976830,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":336493,"completion_tokens":100,"total_tokens":336593,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":334080,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":31,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3369,"ts_us":1792976831588565}}

data: [DONE]

