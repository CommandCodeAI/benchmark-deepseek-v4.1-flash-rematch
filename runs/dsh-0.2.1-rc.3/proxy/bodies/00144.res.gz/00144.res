data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979212998599}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213358087}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" built"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213465016}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" twice"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213481767}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213481817}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213481888}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213494943}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213494998}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213495061}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213495133}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213495186}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213513702}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213513764}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213513831}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" always"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213530275}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213544688}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213544732}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213544803}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213565016}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213565088}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213565148}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213565229}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213565289}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213565341}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213574959}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213575040}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213591715}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213591769}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213591819}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213607065}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ol"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213607120}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213607218}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213607311}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213607350}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" interactive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213623102}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213623174}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213639645}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" allowed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213639689}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213656026}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213656095}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" provides"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213656151}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213673442}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213673578}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213688078}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213688134}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213688174}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213688222}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213704214}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213704276}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213704334}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213704387}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213704446}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213720763}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213720907}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213734702}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213734767}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213734806}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213769655}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213769715}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213769760}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213769809}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213782288}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213799425}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213816757}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ol"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213816822}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213832917}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" outline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213846421}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213862811}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213862891}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213863022}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213863127}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213863192}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213881107}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" refine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213881186}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213894555}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213894634}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213911128}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vertical"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213911181}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" size"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213928381}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213952762}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213952826}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visibility"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213962320}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213962392}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213977606}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213977673}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overview"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213977729}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213977819}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213991783}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213991866}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213991928}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213991983}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979213992044}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" titles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214009279}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214009336}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" acceptable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214025332}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214025449}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214025569}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214025643}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214044437}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214044516}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214044583}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214059235}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" judged"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214059322}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214059385}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214074829}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214095979}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214118028}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214118105}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" prompt"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214118170}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214124241}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214136953}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214137033}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214159821}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214168315}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214168400}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214168469}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214168536}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214168606}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" want"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214186690}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214186776}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214186841}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214201209}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" without"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214201300}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" compromising"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214217896}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214274555}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214274671}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214274756}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reduce"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214274831}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214274913}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214274992}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214275071}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214275151}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214295593}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/b"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214295667}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ottom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214298462}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" padd"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214298529}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ings"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214314994}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214315067}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214329713}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" size"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214329786}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214362573}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214362641}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214362693}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Currently"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214362750}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214376446}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214376512}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214391841}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"222"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214391919}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214391972}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214407487}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214407571}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214423444}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214423527}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214462457}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214469003}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214469061}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"57"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214478710}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214478781}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214487936}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214488019}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Tra"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214488095}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214507420}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" titles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214507493}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214519481}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214519543}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"776"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214519614}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214519691}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214519737}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214535206}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reduce"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214535262}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214535311}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" card"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214535354}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214550891}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214592372}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214592458}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214592515}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214592601}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" start"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214603549}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214603668}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214614793}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214631469}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214631548}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214631609}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reduce"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214647410}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214647476}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214647514}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214663646}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214663709}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214663752}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214679124}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"260"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214679203}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214679264}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" match"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214679322}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214694735}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214694809}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214712735}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214727565}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214727623}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214727694}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214727748}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"403"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214742723}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214742814}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214742870}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214742919}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214760148}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214760212}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214760280}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214760338}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214774325}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214774390}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214774443}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214797845}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214797926}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214811842}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214822328}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214822371}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214841868}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214841949}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214842015}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214842070}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214855624}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"403"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214855692}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214855748}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214855799}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214855873}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214873344}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reduced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214873414}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214873469}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" making"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214887864}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214887975}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214888042}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214902958}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214903026}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214920384}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214920447}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"currently"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214920501}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214934016}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214934086}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214934142}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214952056}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214952113}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" census"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214952166}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214969555}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214969612}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" compact"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214986234}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214986311}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214986402}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214999180}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979214999269}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215013951}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"380"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215014016}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215014070}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215014124}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shifts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215030450}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215030527}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215046562}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215046638}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"23"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215066318}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215066431}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215066484}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215083589}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215083644}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215083696}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215104395}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215104449}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lose"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215110969}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215126891}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"20"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215126947}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215126991}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215145282}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215158171}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" start"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215158221}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215158298}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"733"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215179248}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215179348}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215179420}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"167"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215190594}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215206023}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215206091}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ->"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215206136}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215222236}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215240945}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"some"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215240996}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215256175}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215271959}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215272017}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" slight"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215272061}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" improvement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215288023}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215288068}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215288141}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215288215}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215288259}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215288327}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215303538}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215303584}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215321729}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215321782}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215334208}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215334281}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215334328}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" card"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215334405}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" headers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215351205}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215351259}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" users"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215351359}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" know"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215370299}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215386101}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215386173}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215386228}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215386280}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" won"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215386341}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215403203}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" compromise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215403257}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215416250}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215416331}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215416390}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215434573}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215447904}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requirement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215447963}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215467193}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215467240}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215479261}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" answer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215479309}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215479383}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215495197}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" how"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215495281}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215495334}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215511094}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215511166}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215526710}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215526757}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215526814}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215547557}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215547632}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215547686}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215547737}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215547788}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215566985}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215567066}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215567122}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215588357}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215588448}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215593080}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215593131}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vector"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215608897}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215624481}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215624547}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" neural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215624606}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" net"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215639529}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215639598}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215639651}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" allowed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215639696}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215672211}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215672264}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Genes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215672301}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mutate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215690811}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215702252}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215729800}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215729842}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215729885}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215736557}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215736632}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215736680}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215736789}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215757264}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215757317}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215776443}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215776484}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215797716}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215797762}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215797843}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215797929}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215809216}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rowth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215825647}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215825719}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215825785}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215825880}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215840978}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215852435}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215852503}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215852563}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215864831}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215864887}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215864934}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215864988}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215865067}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215865145}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" evolution"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215878899}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215893088}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215893151}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215909480}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215924983}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215925033}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215943496}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215957797}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215957875}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215974407}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215989583}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215989658}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979215989712}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216008224}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expected"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216008268}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216021875}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216021942}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216021999}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216037501}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216054513}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" affect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216054594}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216070111}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216087254}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216102638}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" selection"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216102703}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216119460}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216119540}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216119594}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216140011}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216140084}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216140281}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216140351}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216150109}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216150180}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216150242}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216165335}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216165411}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216183259}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" effects"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216183305}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216203364}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216224575}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216224638}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216224694}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216237847}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216237916}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216249390}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"about"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216249450}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216265775}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216265818}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216265894}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216284960}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216297772}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216297845}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216297883}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216297922}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216314486}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216314561}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216314600}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216314649}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216329693}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"D"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216329763}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216348959}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216349021}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" immediate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216349079}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216368610}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" damage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216380385}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216380433}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216394430}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rowth"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216394473}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reduction"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216410173}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216426620}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216426687}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216426764}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Pl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216442228}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ague"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216442299}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216442345}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216442425}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" c"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216459136}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ull"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216459198}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216459265}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ongoing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216459307}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mortality"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216488449}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216498283}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216498349}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216498426}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216498497}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"clipse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216498564}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216498599}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vision"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216509522}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reduction"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216509580}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216527926}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216527975}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216528041}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" effects"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216528092}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216543737}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" distinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216543851}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216560318}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216655816}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216655890}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216655948}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216655987}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visuals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656031}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656093}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656135}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656190}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656262}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656301}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656340}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656377}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656418}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656522}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656572}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656636}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656697}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" third"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656761}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656799}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" name"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656847}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216656877}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216666703}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"clipse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216666771}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216666827}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216666875}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216666925}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216686313}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216686389}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216700238}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216700305}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216700362}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216700415}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216700464}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216712652}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traditional"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216712708}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" resource"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216728687}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sense"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216745523}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216745620}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" environmental"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216745660}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216761762}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" allowed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216761813}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216777665}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216792716}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" choosing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216792761}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216809794}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216809868}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216809938}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216809992}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216810049}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216826862}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216826908}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216826961}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216827007}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216827082}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216827144}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" examples"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216841393}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216841459}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216841509}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rought"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216856163}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216856212}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plague"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216856269}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216856314}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216856369}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216873252}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216873296}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" your"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216873349}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" choosing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216873411}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216873452}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216873499}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chose"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216888657}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" eclipse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216888730}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216888806}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216905854}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216905906}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216905948}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216905999}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216906040}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216906086}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216922883}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216922948}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216923011}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216940352}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216957090}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216957133}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216971812}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216971884}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" draw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216971942}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" them"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216991972}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979216992011}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217012236}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217012279}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217026617}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217026660}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" faint"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217026729}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217043711}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217058224}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217058275}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217058346}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217058406}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217058467}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217071850}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217071895}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217071961}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217072022}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217072073}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217072130}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217072168}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" markers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217085438}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217101845}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217140753}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217140820}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217140881}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217140926}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" explicitly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217140988}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" named"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217144461}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217161113}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217175762}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217175842}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217175901}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217175938}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217191070}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217191121}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217206943}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217207007}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217207087}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217207163}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217207210}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217207266}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217222583}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" All"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217222643}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217222688}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217222773}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217237507}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ases"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217254822}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217254887}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217254979}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217271356}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217271445}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217271518}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217291644}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217301030}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217301115}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217318085}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217318141}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217318186}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217333072}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requirement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217333132}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" didn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217350348}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217365935}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mandate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217366006}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217366063}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217366127}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217366182}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217366241}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217382263}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" specified"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217382320}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217398009}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217398055}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217414777}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217414841}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217430587}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217430639}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217430691}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217447390}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217447439}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217447524}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217447599}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217447652}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217464445}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217482449}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217482529}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" World"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217482611}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217498541}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217498604}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217498662}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217498720}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217498773}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217514979}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217515072}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217515165}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217515228}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217515343}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217515405}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217529737}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" SVG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217529808}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217529860}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" allowed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217547178}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217563925}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" They"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217563983}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" said"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217564047}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217564099}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217580359}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217580436}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" small"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217599168}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217599235}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217599279}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217599329}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217611269}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessarily"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217611340}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217611396}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217631029}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217631084}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217646268}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217646312}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217646366}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217646434}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217646472}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217662314}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" User"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217662367}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" asked"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217662399}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217662447}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217679721}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drawn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217679777}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217695852}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217695896}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217695961}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217696011}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217711185}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217711267}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" language"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217711347}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217711405}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217711468}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217725525}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217725595}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217747882}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217758853}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217758922}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217758974}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217759027}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217759079}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217776984}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217777046}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217777105}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217777184}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217777242}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" runs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217791423}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217804891}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" N"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217804974}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217822660}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217840837}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217853142}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" own"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217853216}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217853284}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217853345}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217876034}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217876110}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217884539}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" handling"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217884628}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217903629}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" outside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217903708}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217917473}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217917521}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217934516}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217934599}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217950294}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217950365}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217950427}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217950477}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217965180}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217965246}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217984373}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217984431}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217984479}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217984522}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217984580}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217984657}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pauses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979217998746}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218012540}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218012584}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stops"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218041755}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218041816}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" until"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218047054}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" resume"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218062064}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218062136}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" normal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218077771}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218077871}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218077937}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218077997}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218092543}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218092606}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218092671}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218092727}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218092783}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218092843}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-st"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218111258}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218111309}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218111353}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218111392}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessarily"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218124601}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218142638}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218142732}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218156441}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218172814}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218172867}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218188904}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218188966}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218189059}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218189112}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218189183}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218189226}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218204568}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218204636}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218204687}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seeded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218240136}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" PR"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218240217}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"NG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218256792}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218256864}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218256911}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218256963}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218273172}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218288725}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218307306}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" random"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218307370}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218335188}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218335235}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218335494}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218335533}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218335567}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218335604}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218335643}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218335679}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218364658}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218364724}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218364777}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218364827}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218364879}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218365073}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218365126}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" schedule"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218389686}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218414569}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218414633}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218414688}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218419517}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218419571}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218419622}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218445067}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218445123}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218445312}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218445362}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218459774}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218459833}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218475682}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218475772}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218475826}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218493787}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218508095}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218508154}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218527910}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218527967}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218528017}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218528260}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218528313}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218528363}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Determin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218544992}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218545064}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218545124}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218545193}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218566266}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218572034}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218591418}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218606579}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218606629}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218606670}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218619539}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" confirmed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218619600}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218635031}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" What"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218635086}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" about"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218651022}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218651088}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ausing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218669559}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218669624}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218669682}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218682246}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218682327}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218698866}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218698942}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" affect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218699001}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218713326}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218713391}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218713450}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218729907}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218729961}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218730021}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218730059}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218730110}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218730151}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218730190}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218765174}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218765223}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218765278}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218775679}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218792147}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"las"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218792195}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218792269}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218792321}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" randomness"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218792365}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218807221}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218807291}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218822198}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218822260}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218840560}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218840617}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218854937}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218855009}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" positions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218870676}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218886643}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218886726}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218941496}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218941568}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218941632}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218941736}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218941811}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218941877}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218941933}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218941989}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" output"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218942091}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218942162}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" depend"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218949395}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218949460}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218949517}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218972727}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218982654}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979218996398}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219014867}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219014937}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219030361}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219030432}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219030487}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"),"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219047698}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219047755}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219047835}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219047914}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219067910}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219067987}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219078371}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219078448}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nond"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219078502}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"eterm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219094390}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219094454}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"istic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219094500}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219094528}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219139342}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219139410}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219139467}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219139519}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219139590}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219141182}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219159186}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219159265}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219159318}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219174987}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219175065}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219175136}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219175195}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219175339}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219175389}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219175449}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219188961}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219189042}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219206744}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219234310}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leading"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219234402}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" zeros"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219239883}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219239963}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219240025}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219255532}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219255611}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219255677}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219255737}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219255801}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219255863}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219255947}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" update"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383311}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383405}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383474}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"state"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383536}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".se"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383602}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383661}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383724}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383789}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383852}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219383948}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" new"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219384033}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219384108}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219384186}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219397193}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219397277}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219397345}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219397412}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219397472}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219397539}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219397603}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219419535}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219419620}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" allows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219427621}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219447042}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" digits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219461138}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219461199}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219478646}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"change"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219478705}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219493104}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219493181}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" typing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219513754}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spaces"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219513814}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" strips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219513856}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219524943}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219542638}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219542689}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219542735}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219562671}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219562739}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219562796}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219562851}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219562905}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219562956}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219579758}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Station"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219579847}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219595354}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219613192}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219613256}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"04"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219628121}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219628178}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219628225}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219628290}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Plate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219645512}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" VII"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219645568}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219658737}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219658783}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219673622}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219673731}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219673808}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"073"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219686237}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219686330}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219686410}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219686493}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219699636}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219718762}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219718816}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219729503}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219729559}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219729619}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219729665}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219729746}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219729797}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219744592}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219744656}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219744697}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219759355}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"73"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219774938}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ->"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219775006}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219775070}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"007"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219775134}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219791423}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219791551}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219791646}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219809545}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219809630}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219823285}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219823429}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219839548}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219839616}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219855531}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219855609}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219855673}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219855723}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219872275}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" example"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219887134}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219887175}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"73"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219887245}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219902591}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219902669}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219902727}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219902765}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219918503}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219918566}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219918621}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219918677}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219918735}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219918794}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219942800}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219942863}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bulletin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219942898}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219958928}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219972111}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219972187}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219972256}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219972313}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219985162}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979219998708}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220013646}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220029755}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220029799}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220029839}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220029903}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220029978}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" automatic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220048008}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visitation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220066406}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220066463}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220081526}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220081598}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220081638}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220081685}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220101201}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220117105}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" explains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220117174}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220145289}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220145342}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220145396}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220145445}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220145500}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220145542}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220145604}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220171612}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220179502}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220198065}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220218246}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220218323}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" explicit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220230664}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220230737}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220247168}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220264812}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220264880}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220275707}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" their"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220275769}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220290195}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220290258}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" beyond"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220290321}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220306250}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" neighboring"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220306304}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220320851}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220320919}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220320975}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220321033}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"every"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220342839}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ["},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220342917}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220350538}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"]"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220364743}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220364794}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220364840}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220364891}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220364979}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" next"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220365064}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220383094}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220398161}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220398236}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220398295}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220398360}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220414987}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220415045}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220415095}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220415144}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220415195}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220415244}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220431203}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220431263}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220431314}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220448054}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220459946}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220460010}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220460065}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220479975}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gene"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220480039}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220494267}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220494349}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220494446}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" slider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220494515}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" value"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220508986}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220509045}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220526151}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220540149}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220540210}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"25"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220540261}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220557655}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220557746}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220557835}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" decimal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220578966}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220579048}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220579110}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220579161}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220579219}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220579271}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220587836}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220587944}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220603705}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220603752}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"×"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220603816}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vig"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220623840}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220623896}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220623987}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220624092}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220637262}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" slider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220671329}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" endpoints"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220671404}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220677247}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220677321}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220677384}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220677441}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" study"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220687200}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" length"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220687249}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" units"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220699464}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220699509}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220725956}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220726000}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220726063}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220726127}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" units"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220726165}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220731130}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220731211}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220731265}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" All"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220731309}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sensible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220745673}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220745719}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220745799}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220745876}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220745934}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220745986}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220762821}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220762888}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tempo"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220762944}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220778983}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220779026}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220794505}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" E"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220794555}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"TA"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220810192}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220810255}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220810318}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220824864}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220824923}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220840644}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220840710}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220840761}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220840829}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"remaining"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220857147}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220857241}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220857318}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220857383}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220857444}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220881377}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"format"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220881423}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Clock"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220891335}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220891395}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220917128}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":ss"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220917202}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220922803}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220922882}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220922943}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220922998}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" E"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220923065}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"TA"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220936459}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" removed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220936531}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220955680}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220955729}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" duplicate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220968691}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220968778}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220984436}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220984488}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220984544}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220984601}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979220984658}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gener"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221003326}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221019294}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Tim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221019374}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221019431}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221019485}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221019560}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221019622}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" unnecessary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221032096}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221032221}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221050614}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221050657}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221063996}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221064074}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221064137}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221064177}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221079186}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221079248}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221079300}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221079348}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221079423}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221079467}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221096226}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221096278}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221096332}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221113308}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221113392}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221113456}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" beyond"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221127913}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221127995}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221148280}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221160248}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtitle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221185382}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221185454}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"280"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221194562}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221194604}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221194645}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221210131}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221210231}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nice"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221210292}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221228223}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221228294}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221228350}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221228474}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221247870}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273125}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273193}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273263}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273350}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273405}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273469}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273532}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273695}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221273757}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221294133}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221309312}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221309384}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221327317}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221327396}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221327439}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" normal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221338487}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221338553}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221352442}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"00"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221352507}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221366477}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"56"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221366544}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221366599}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221366652}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221387252}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221401444}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221401488}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221401523}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"00"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221416561}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221416622}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"16"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221416674}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221428803}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221428879}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221446401}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221446486}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221446539}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221446603}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221477645}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221477876}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"active"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221477954}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Ms"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221497838}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221511266}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221511334}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" real"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221511389}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221538894}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" elapsed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221538972}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221539038}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" including"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221548281}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paused"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221569468}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221569535}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221574627}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221574694}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221574749}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221574804}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221589168}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221589237}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221589290}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" On"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221589346}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221589399}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" normal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221589453}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221604951}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221605021}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221605078}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" clock"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221605132}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221629961}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221630033}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221639523}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"00"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221639599}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221639700}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"56"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221639846}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221660542}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221660611}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221669897}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221690495}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221700432}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221700501}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221700555}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221700612}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221714911}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"00"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221715005}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221715072}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"56"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221715143}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221715216}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221715286}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221731883}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221731969}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221732042}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221732114}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221747309}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221747389}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221763404}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221763471}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221763522}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221778361}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pauses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221793260}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" effectively"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221809549}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221826408}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221826477}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" active"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221826541}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" clock"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221847964}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221859599}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221877393}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" counting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221877463}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221896493}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221896560}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221896611}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221904893}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221904949}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" than"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221920890}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221920956}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221921040}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221936078}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221936143}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221936202}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221936271}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221952634}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221968381}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221968482}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221968560}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221968635}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979221968766}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222001827}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222001896}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222001955}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222002014}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222002081}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222002134}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222002200}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222002269}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222002322}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222002370}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222022181}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222022251}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222032945}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222049229}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"00"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222049298}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222049349}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"05"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222066295}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222066356}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222066424}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" weird"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222086283}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222086323}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222086361}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222099088}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222099131}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222111910}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222111963}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222112033}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222112082}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222112128}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222126975}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222127041}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222127093}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222127132}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222127184}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" date"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222142805}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222159506}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222159575}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222176401}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222176482}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222176540}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222190303}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222190367}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" start"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222210774}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222210841}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" negligible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222210908}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222221651}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222221712}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222221834}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222221957}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222222046}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222222140}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222239555}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222239670}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222239760}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222252665}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" store"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222252741}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" completion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222268821}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222286007}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reload"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222286078}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222301323}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222301387}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222318346}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222318426}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222318489}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222318567}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222318630}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222318698}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222334347}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222334430}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222334499}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222349164}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222364754}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222364808}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222384107}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222384152}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222398642}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222413415}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222433815}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222433860}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222448226}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222448275}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222448331}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222448378}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222448417}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222448469}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222468529}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222468605}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222468664}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222468719}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222479159}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" passes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222494064}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222506665}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222506734}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222506788}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222506841}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222506892}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222506942}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222506995}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222523309}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222523417}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222523486}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222541290}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fav"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222541377}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222554171}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222554257}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222554319}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222554379}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222568966}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222589444}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" URI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222589514}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222589573}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222603335}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" both"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222603429}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222603487}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222620959}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222621019}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222621073}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222621160}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222621213}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222621264}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222632748}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222632804}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222632856}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222662699}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222670064}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"R"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222670132}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"NG"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222717277}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222717354}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222717421}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222717490}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" random"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222717540}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222730255}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222730327}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222730393}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222730460}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222730517}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222747120}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222747204}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222747272}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222747349}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222747429}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" answer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222761943}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222762011}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222775880}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222792555}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222792636}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" technical"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222792691}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222811204}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222811284}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222825526}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222825592}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222840414}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" key"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222840480}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222858112}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222858154}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222871817}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222871920}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222871996}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222872055}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222872104}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222887143}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222887217}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222887269}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" clean"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222887326}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" up"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222887379}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222906696}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" folder"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222906766}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222924048}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222924123}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222924165}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222944428}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222944524}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222950400}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222950495}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222950572}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222950642}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222966487}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222966565}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222966638}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222990776}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222996552}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979222996638}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223015276}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" patches"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223015357}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223015423}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223029345}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223029439}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" syntax"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223029514}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223048575}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223048654}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" obvious"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223061688}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" artifacts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223081381}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223090644}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223090725}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223090793}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223090855}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223111101}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223127721}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223127816}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Play"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223148631}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223163831}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223163940}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" console"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223164025}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223171794}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223186394}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223186499}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223186575}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" most"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223202302}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223202397}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223217747}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223217860}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223241722}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223241796}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" template"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223241861}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223256723}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223256814}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223265182}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" light"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223265266}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223265329}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223283983}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223284054}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" measure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223284108}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223284190}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223295836}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223295909}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223314086}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223314153}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223314209}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223315700}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223331197}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exact"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223331270}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223346293}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" And"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223346357}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verify"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223358808}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223374890}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223374999}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223391837}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223391909}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223416643}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223416729}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223416798}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223416855}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223426647}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223426722}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223426781}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223426847}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223426926}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remove"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223443873}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223443946}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223453722}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223453795}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223453851}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223453932}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223469171}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223469220}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223469275}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"README"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531068}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531129}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531191}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531237}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".**\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531297}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531398}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531473}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531522}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531605}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531665}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531708}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223531974}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" added"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223549934}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223550024}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223550080}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223565092}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" micro"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223565171}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223580022}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223602479}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223602547}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223602601}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223611354}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223611420}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223611479}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"x"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223611538}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"900"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223611594}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223631867}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223631926}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223631977}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223632029}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223642391}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223642473}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223642529}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" small"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223660180}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223674716}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" evaluate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223674772}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223690442}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223690527}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223690660}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223709540}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223709607}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223721641}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223829222}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223829299}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" humans"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223829456}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223829639}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223829704}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223829834}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223829878}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223830004}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223830108}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223830173}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223845263}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223845312}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223845346}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"14"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223845395}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223908860}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223908937}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909018}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909081}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909159}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909222}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909266}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909346}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909400}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909459}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909529}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drawer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909612}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909715}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909760}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909917}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223909973}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223984700}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dense"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223984770}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223984810}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223984858}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223984921}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wanted"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223985043}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223985108}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" variable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223985168}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223999701}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979223999771}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224063928}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" main"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224064031}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224064185}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224064244}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224064289}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224064442}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224064510}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224064560}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224068851}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224068912}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224068982}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224069060}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224069121}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224069175}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224084568}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224084632}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224100455}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224114923}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overshadow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224136395}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224146112}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224146173}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224162030}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224162088}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224162137}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" balance"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224178759}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224197142}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224197195}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" anchors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224213056}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224227105}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224247686}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224259084}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224259162}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224259220}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224259286}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224259367}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224259421}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224273206}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224273283}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224273337}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224273412}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" titles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224289832}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224289931}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224305799}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224305858}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224319636}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224319717}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224319788}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224319833}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224335232}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cohesive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224335285}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224350625}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224350700}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224350755}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224350820}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224350874}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224367733}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224367833}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224367906}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224367978}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224368047}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224383161}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224398532}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224398612}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224398685}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224398738}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224413461}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" much"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224413511}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" space"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224413555}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224431099}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224431154}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"133"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224445242}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224445309}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224445382}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224474315}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224474390}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224474464}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224474543}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224474631}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" composition"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224480058}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224480130}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224480186}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224492245}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"plate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224492312}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224507799}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224535038}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224535084}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224535158}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" specimen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224537657}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224537712}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" instruments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224537767}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224554429}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224554483}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" footer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224554528}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224572454}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Strong"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224572510}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224586818}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224586874}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224586943}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224587014}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224587057}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224587104}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224607978}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224608037}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224608090}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224608140}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224614911}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224614964}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224636143}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224636194}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224646093}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224668966}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224669011}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"00"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224669056}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224677793}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" updates"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224677843}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224716395}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224716438}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224716510}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224716570}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224716612}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224725092}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" look"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224725169}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" like"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224741497}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224741539}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" large"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224741601}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" faint"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224741657}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" number"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224756355}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224756398}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Nice"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224756452}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224776834}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224776881}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224777018}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224777061}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224788142}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224802134}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224802187}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224802239}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" compass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224802287}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224818778}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224818858}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224818933}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scale"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224819011}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224838433}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224838502}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224838554}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Measurement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224838625}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224838707}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224850370}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224850431}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" These"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224850488}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" make"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224850541}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224867508}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" signature"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224867559}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224897129}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224897176}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224897265}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224897343}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224897400}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224897435}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224897479}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224914313}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224914368}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224914411}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" appears"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224929955}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224930015}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224930054}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224946225}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" right"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224946288}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overlapping"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224946330}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224959473}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224959530}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224983621}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224983682}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224983733}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224983782}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" major"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979224994169}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" signature"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225005324}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225005372}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225023466}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225023510}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225023556}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" curved"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225023610}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225038091}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225062416}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225062479}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225073438}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225073483}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225073545}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225073606}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225087984}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225088047}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225088091}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225088149}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" weather"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225102076}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225123113}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hide"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225123168}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225133098}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225133184}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225148994}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225149041}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225163187}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225182825}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" critical"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225182866}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225194129}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Temporary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225194178}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225209645}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225209700}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225226109}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225226182}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225226222}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225226278}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225226329}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225226399}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225242334}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225242387}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225242464}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225242533}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tint"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225257433}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225257493}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225274787}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225288809}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225288862}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225304110}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225304163}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"--"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225320771}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"wash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225320848}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225320894}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" alpha"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225336917}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" low"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225336966}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225337004}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" combined"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225351891}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225379977}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225380018}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" blend"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225380060}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225381810}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225381920}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225381982}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225382037}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bulletin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225398877}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225398923}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Requirement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225415070}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225415120}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rest"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225415170}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rained"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225436251}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225436297}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225446834}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225446913}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225478136}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225478184}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225478240}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225478288}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225478340}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225478380}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225478439}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225494778}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225494826}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225513126}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" markers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225523524}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225541926}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225556102}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225556165}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225571505}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225571568}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225587889}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225587932}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225587990}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225603192}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225603235}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225649908}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225649979}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" coherent"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650038}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650093}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650152}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650210}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650269}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650325}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650381}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650812}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650880}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225650956}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225651037}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225665996}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225666052}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225666101}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nice"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225681346}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" motif"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225681435}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225696710}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225696755}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"I"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225696813}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" think"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225715895}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225715948}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'re"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225732106}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" done"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225732150}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".**\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225732218}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225732286}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225746170}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225746217}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225746272}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225746343}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" light"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225746387}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225760270}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225760324}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225760364}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225760409}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" files"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225776469}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225792923}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225792978}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remove"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225793047}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225793116}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225809453}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225809503}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225809545}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deletion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225824568}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225824625}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225824708}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225839630}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" want"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225839676}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225839728}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" keep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225855330}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225855409}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225872577}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225872616}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225872657}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" logs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225889008}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225903530}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225903602}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" required"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225903655}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225903710}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225918109}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deliver"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225918185}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225918229}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225918303}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225934563}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225934627}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225951837}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225951908}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225951962}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225952042}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225952123}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225952233}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" folder"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225966192}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225966247}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225966302}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" referenced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225982203}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225998549}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225998613}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979225998675}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226015226}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Removing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226015305}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226015365}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" safe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226033890}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226033989}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226034041}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Verify"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226034089}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" path"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226049409}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226049546}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226060494}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"real"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226060562}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"path"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226060607}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226077087}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226077151}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226077202}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226077252}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" policy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226093701}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226108357}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226108433}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226108487}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226124781}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226124853}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rf"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226124894}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226124947}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226138402}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Policy"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226138465}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226154976}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226155043}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" delete"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226155121}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226155189}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verify"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226172136}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" resolved"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226172182}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226172230}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226191623}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226191672}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'ll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226191712}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226191753}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"real"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226206777}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"path"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226222177}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226222243}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226242352}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226259235}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226271148}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226271190}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226284040}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" workspace"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226284080}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226284134}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226300807}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remove"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226300862}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226300901}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226321378}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226335267}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226335310}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226335374}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226335435}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deletion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226356124}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226356188}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" instructions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226356256}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" require"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226365934}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verify"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226365971}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intended"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226391744}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" path"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226407152}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226409249}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226409294}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226423228}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226423274}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226423317}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226438736}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226458305}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226458367}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" keep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226458433}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226458485}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226458545}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" future"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226470946}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226471018}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226471104}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" task"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226489050}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226489121}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226489181}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226509022}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Clean"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226509073}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226520684}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226520759}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226520827}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226520895}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"git"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226535320}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" directory"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226535372}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226535413}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226558822}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226558904}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226565384}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226565438}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226565512}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226565574}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226584159}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226602276}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226602317}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226602393}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226602450}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226614167}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"l"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226614240}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226614305}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226630473}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226630519}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226630586}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226649042}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"sha"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226649093}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"256"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226661211}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"sum"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226661287}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`.\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226661344}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226661393}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226676872}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226676923}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226692735}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226692787}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" once"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226692833}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226707385}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226707429}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" error"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226707494}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226725620}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" using"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226725666}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226725708}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226741603}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226741688}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226756059}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tmp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226756105}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226756146}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226771443}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" removal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226786495}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226786553}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226804547}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226804619}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226804687}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226804747}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" removal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226818172}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226833998}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226834067}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226834151}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226834209}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226834285}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226851471}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ensure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226866392}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226866455}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"__"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226883509}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ST"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226883569}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Y"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226900260}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"LES"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226900311}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"__"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226900353}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226900395}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" place"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226900464}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"holders"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226917923}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" replaced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226917969}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226918023}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226918067}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" placeholder"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226929917}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leftovers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226929966}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226948223}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226948266}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226948318}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226948359}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226948414}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226948465}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226969337}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226969381}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" references"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226969450}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226969498}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226978868}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" files"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226998877}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226998918}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226998959}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226998994}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979226999029}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ype"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227009937}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227009980}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227010026}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227010069}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227010122}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227010185}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227029409}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227029463}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227046531}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" HTTP"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227062303}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" server"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227062351}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227076569}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227076623}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227076660}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227089474}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227089524}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requests"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227089566}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227105367}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227122004}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227122055}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227122092}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227122149}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227122188}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" without"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227161732}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" network"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227161783}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227161842}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227166595}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227183972}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" done"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227184031}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227200621}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227200654}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" There"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227200693}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227214889}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227214978}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227215035}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227215065}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227230233}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227230278}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227230323}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227245707}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227245769}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227245810}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227245876}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227264178}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227264227}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"</"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227278888}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"style"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227278928}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227278968}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227279004}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227294772}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227310053}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227325263}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227325312}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227325349}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227341396}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inserts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227341451}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227357613}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227372767}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227389074}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227389119}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227403835}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227403873}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227403930}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227403968}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227404006}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227421335}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tag"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227421379}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227436516}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227436561}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".js"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227452846}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227486664}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tag"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227486721}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" both"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227486758}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227486866}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227500042}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227500124}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227500186}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227500246}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227500284}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227515261}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227515301}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227531363}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"window"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227531416}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".V"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227531468}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"iv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578058}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578121}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578180}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578248}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578302}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" defined"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578341}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578392}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578440}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" previous"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227578477}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227579390}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227579441}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227579477}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227595457}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227595500}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227595554}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227610543}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227610587}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227610641}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tags"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227610686}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227628995}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227629049}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227644932}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227644979}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227645017}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227645057}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227658034}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227676021}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227676066}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227676117}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227676176}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/*"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227689822}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"__"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227707258}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227707320}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ORE"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227721265}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"__"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227721336}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"*/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227721388}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227721447}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" replaced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227721491}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227721516}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227736683}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227736761}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" source"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227755958}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" including"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227756023}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227756073}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trailing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227770704}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" new"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227785181}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227809518}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227809595}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227809653}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227809806}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227809891}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227809947}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" source"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227816541}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227831460}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227831526}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227831579}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"</"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227849075}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227849147}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227849206}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sequences"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227849250}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227849338}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227866263}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227866316}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227866369}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" comments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227883032}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" don"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227883096}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227883144}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227883202}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227898870}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227898916}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" literal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227898982}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227913054}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"</"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227913099}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"script"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227913162}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227913228}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227913291}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227913334}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inserted"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227926327}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227952237}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227952284}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Search"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227952334}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227958260}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979227973568}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228012689}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_BdnZgaIxz88FHtEdtbWM5491","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228020659}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228047712}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228047781}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228047843}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228061538}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228061612}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228061657}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228061756}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228068674}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228068729}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228068781}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\"__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228068861}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ST"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228068913}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Y"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228069066}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"LES"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228084003}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228084086}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228084151}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228084218}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228084278}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ORE"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228101468}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228101527}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228101576}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228101630}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"APP"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228101681}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228101739}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228116436}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228116484}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228116535}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228116579}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228161448}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228161533}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228161608}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228161680}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228161744}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\"</"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228161815}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"script"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228161883}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228161966}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228162038}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228162078}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228162153}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228163273}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228163338}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228163382}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228163436}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228163487}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\"<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228178451}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"script"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228178500}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228178591}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228178672}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228178757}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228178828}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228178896}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228194480}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228194575}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228211654}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228211720}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228211831}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228226016}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228226071}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"lh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228226115}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228226174}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228226246}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228226324}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" sha"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228241138}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228261049}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sum"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228261111}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228261337}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228261399}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228261445}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228292436}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228292494}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228292572}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228292689}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228292765}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228310148}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Final"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228310242}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" file"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228310301}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" sanity"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228320163}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" checks"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228320218}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228335772}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2350,"ts_us":1792979228335856}}

data: {"id":"66966d5b0cc327f7390adae6cb231312","object":"chat.completion.chunk","created":1792979212,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":558464,"completion_tokens":2546,"total_tokens":561010,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":558208,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":2430,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2350,"ts_us":1792979228362952}}

data: [DONE]

