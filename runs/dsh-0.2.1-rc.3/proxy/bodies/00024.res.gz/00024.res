data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021479533}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021479622}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change! The first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021479662}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replacement may not have applied because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021523176}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" source structure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021523242}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differs?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021523305}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's inspect predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021523381}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021548818}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_9repdomf4atw6yfz78s23mpb","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021574832}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021574907}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021574970}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021590328}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021590397}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021590448}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021590521}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021590581}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021590703}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021603321}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021603398}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021629215}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021629319}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021629426}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021629481}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"update"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021629529}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Pred"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021629583}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021629617}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021629660}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021669080}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021669288}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021669366}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021669440}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021780467}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021780556}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021780686}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"70"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021780745}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021794470}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021794707}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021794803}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021795021}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021828438}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021828524}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021828592}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021828654}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021877026}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" predator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021877104}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" update"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021877169}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975021877225}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975022014340}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3452,"ts_us":1792975022014424}}

data: {"id":"d01fa3d030b1d15b4df2b4ab03097474","object":"chat.completion.chunk","created":1792975021,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":78867,"completion_tokens":97,"total_tokens":78964,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":76416,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":21,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3452,"ts_us":1792975022014530}}

data: [DONE]

