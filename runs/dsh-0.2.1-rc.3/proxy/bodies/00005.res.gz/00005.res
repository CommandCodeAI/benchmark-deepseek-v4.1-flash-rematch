data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974453976825}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974453976891}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser cache listed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974453976916}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe chromium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454073242}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" elsewhere"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454073297}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454073340}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_nvc69cuh8f65lbfos2548uhu","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454073518}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454073850}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454074083}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454074252}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454074556}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454091204}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454091254}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454091313}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454091374}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454096667}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454096717}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454097030}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454097150}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454097317}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454097641}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454097804}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454097894}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454117234}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454117438}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454117498}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454117585}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454142285}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454142353}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454142405}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454142481}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454142536}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454142589}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454142795}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454142844}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454186691}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454186774}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454186841}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454186888}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454187016}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454187077}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454187134}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454187168}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454187565}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454187615}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454187661}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454187708}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\\)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454241627}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454241684}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454241727}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454241798}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454245186}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454245249}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454245294}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454246669}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454249245}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454249313}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454249388}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454249484}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454262618}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454262867}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454263130}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454263178}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454264521}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Loc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454264743}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454264798}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" installed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454265028}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454340001}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" binaries"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454340193}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454340262}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1008,"ts_us":1792974454344793}}

data: {"id":"b06092a5d5db24796a6139a1c0f1af30","object":"chat.completion.chunk","created":1792974453,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":15875,"completion_tokens":109,"total_tokens":15984,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":15744,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":9,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1008,"ts_us":1792974454345293}}

data: [DONE]

