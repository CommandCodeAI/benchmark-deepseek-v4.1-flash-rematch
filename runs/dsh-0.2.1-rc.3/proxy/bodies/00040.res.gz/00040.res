data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396462438}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396462548}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396462586}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count = 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396540184}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396540230}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396540406}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" schedule 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396540579}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" types"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396597731}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interleaved"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396597904}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396598448}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6? Expected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396598509}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396684630}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396684755}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 7,14,21"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396684905}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (3), plague at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396685069}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"11,22 (2),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396773189}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eclipse at17 (1)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396773233}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396773497}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6. Good. ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396773612}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"I earlier added"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396922849}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396922948}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396923263}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSeed 73"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396923442}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has P526"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396966304}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D44 and peaks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396966563}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396966741}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1193 D44"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975396966827}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397062960}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397063182}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only grows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397063300}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397063400}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Seed 1024 has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397142196}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" P211 D69"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397142260}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397142319}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397142450}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator ratio"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397223513}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397223638}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more dramatic. Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397223715}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1620"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397228876}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 495/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397359336}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40. Seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397359425}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"199"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397359475}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9 502"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397359519}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/37. Default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397405041}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397405138}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be 73"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397405317}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397405364}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 184"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397469229}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7. 184"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397469274}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397469386}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397469862}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397596843}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397596925}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may show cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397597262}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397597306}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s inspect seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397657511}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"73 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397657604}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397657749}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 counts over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397657843}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time, check catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397737750}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes effects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397737788}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and trait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397737896}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397737940}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Choose"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397819527}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed maybe "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397819586}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1847 for historical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397819795}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397820146}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397961763}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" being 6 at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397961822}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed189"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397961903}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 is too low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975397962042}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 1847 D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398021802}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"17. Could set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398021868}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398022017}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398022093}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 14 to increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398126742}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398126813}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398126866}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398126904}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398168916}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nDefault seed should produce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398169172}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398169361}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398169614}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398246517}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398246798}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398246838}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398247053}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398331382}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398331546}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 73:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398331585}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D peak "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398331784}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"44, final 44,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398489681}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good. P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398489726}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398489950}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 526. Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398490001}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398544820}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D 69"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398545158}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398545486}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" P211"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398545573}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; huge predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398629464}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398629560}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398629619}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nearly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398629818}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398689825}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398690132}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Seed 73 seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398690933}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice. Try"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398691491}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 73 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398783612}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398783726}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and events. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398783812}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" choose seed 73"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398784041}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as a tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398881779}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" specimen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398881856}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" number."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398881912}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398881991}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1847 has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398950413}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a certain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398950477}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" museum vibe."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398950561}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We could show seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975398950769}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as \"1847\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399063901}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399064229}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D 17."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399064640}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 17 predators still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399064729}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399178241}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399178336}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Trait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399178409}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drift for seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399178468}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"73?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399273612}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's inspect. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399279061}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399279154}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effects."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399279232}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_b23n608c5dezdc5fvxhnwpn7","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399302994}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399303066}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399303179}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399303466}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399306280}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399306423}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399306865}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399306934}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399330576}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399330633}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399330754}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399331935}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399332000}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399332055}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399332685}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399332742}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399378772}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399378823}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" core"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399378871}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399379014}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399379175}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('./"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399379225}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399379269}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399379314}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399385759}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399386115}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399386199}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399386295}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399542272}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"process"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399542391}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".argv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399542770}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399542859}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399565285}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399565355}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399565451}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"73"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399565592}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399568372}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399568521}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399568686}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399568771}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" core"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399569537}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399569791}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"imulation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399569849}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399569972}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399578209}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399578258}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399578299}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399578344}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399595428}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399595566}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399595657}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399596183}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399639245}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399639343}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399639394}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399639450}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399656818}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++){\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399656884}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" while"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399657064}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399657142}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399657820}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399658471}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399658513}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399658581}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399664223}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399664381}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399664461}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399664577}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399678102}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399678187}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399678325}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399678406}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399683145}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399683335}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399683383}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399683763}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399684175}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399684225}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399684289}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399684354}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399689369}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399689469}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399689624}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399689698}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399690330}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399690455}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399690513}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399690857}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"raits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399699210}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399699329}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399699459}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399699713}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399709436}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399709551}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" td"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399709624}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399709686}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399727930}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"raits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399728004}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399728082}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399728156}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ator"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399729098}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399729158}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399729209}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399729307}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399765338}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399765425}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(String"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399765493}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399765889}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399765969}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399766061}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399766159}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399766235}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399828576}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399828665}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399828733}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399828799}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399878688}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"String"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399878765}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399878816}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399878879}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ants"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399879000}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399879069}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399879130}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399879190}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399890357}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399890594}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399890654}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399890854}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399916523}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399916612}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"String"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399916826}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399916901}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399917549}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399919210}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399919292}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399919353}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399919409}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399919479}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399919533}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975399919580}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400041055}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400041165}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400041238}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"String"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400041289}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400090114}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400090176}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400090230}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400090334}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400091717}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400091777}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400091872}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400092231}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400120957}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121242}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121301}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121352}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121570}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121645}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121727}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121809}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121922}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400121998}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400122083}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400122164}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400143982}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400144055}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400144117}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400144305}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400151440}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400151521}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400151611}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400151672}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400172736}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400172814}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400173178}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400173273}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400173418}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400173629}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400173694}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400173752}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400186570}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400186627}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400186787}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400186840}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400246785}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400246886}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"et"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400247006}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"abolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400247097}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400247921}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400248006}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400248079}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400248140}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400248963}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400249098}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400249165}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400249220}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400250769}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400251065}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".th"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400251138}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400251200}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400260976}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400261072}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400261140}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400261516}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400261810}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400261912}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400262372}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400262436}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400266492}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400266580}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"td"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400266686}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400266737}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400269538}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400269652}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400269731}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400269771}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400270356}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400270420}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400270477}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400270577}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400277761}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400277829}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"td"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400277945}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400278010}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400287892}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400287979}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400288109}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400288203}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400289301}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400289380}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400289439}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400289547}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400358054}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400358152}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400358223}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"td"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400358297}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400367602}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"et"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400367671}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"abolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400367717}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400367798}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400367878}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400367939}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400367981}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400368034}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400372152}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400372223}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400372300}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400372393}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400392003}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"td"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400392080}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".th"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400392173}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400392265}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mean"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400393184}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400393306}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400393383}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400393691}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400411661}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400411750}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400411827}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400411905}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400449871}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400449947}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400450013}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400450078}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400453960}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400454039}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400454100}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400454156}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400454316}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400454420}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400454479}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400454560}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400479112}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400479193}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400479304}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400479364}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400509981}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400510079}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400510159}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400510232}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400510308}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400510382}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400510453}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400510524}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400561156}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400561254}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400561333}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400561407}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400589454}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"73"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400589552}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400589630}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400589709}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400616775}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400616870}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400616975}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400617056}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400617132}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400617218}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400617578}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" per"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400618222}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400631344}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dynamics"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400631620}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400631709}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400631921}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400693644}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"73"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400693751}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400693845}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975400698329}}

data: {"id":"c2cb27c596545f05a80f9ff55ab4dc0e","object":"chat.completion.chunk","created":1792975396,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":110969,"completion_tokens":688,"total_tokens":111657,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":108672,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":345,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1628,"ts_us":1792975400698505}}

data: [DONE]

