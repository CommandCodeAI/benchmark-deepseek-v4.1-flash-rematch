data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979094210014}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Characters"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979094814577}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" like"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979094949083}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" №"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979094966697}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979094966751}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ×"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979094966795}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979094981775}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ·"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979094981846}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095018145}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ±"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095018199}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095018258}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" σ"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095018315}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095029642}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095029692}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" supported"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095046525}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095046572}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" De"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095064552}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ja"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095076807}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Vu"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095076880}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/J"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095076923}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"et"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095206657}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Bra"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095206729}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ins"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095206775}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095206825}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Ch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095206984}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207049}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207095}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207221}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207280}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207376}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207413}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207447}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207480}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"❧"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207600}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207680}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207739}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207866}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207904}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095207939}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095208084}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Search"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095208145}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095208202}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_9NjQGAsjgkkjn6k0ybAP1024","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095236736}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095236812}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095236869}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095252570}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095252629}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095252697}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095252783}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095269273}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095269404}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095269510}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095269561}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095269616}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"to"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095269650}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095284246}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-mark"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095284316}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095284365}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095300781}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095300865}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095300928}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095318976}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095319032}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095319105}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"emplate"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095319169}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095319220}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095332703}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095332790}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095332855}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095332927}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095333017}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"❧"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095349719}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095349788}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095349836}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095349911}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095349988}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"emplate"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095366272}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095366360}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095366427}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/app"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095380607}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095380674}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095380719}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095380823}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095396163}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095413032}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095413120}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095413182}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095413278}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095413370}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095429898}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095429992}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ornamental"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095430065}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" character"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095445138}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095445243}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" toast"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095459786}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095459835}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1903,"ts_us":1792979095475984}}

data: {"id":"ceaf0c390751daeb7aab52605159e5dd","object":"chat.completion.chunk","created":1792979093,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":542730,"completion_tokens":133,"total_tokens":542863,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":541952,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":42,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1903,"ts_us":1792979095503165}}

data: [DONE]

