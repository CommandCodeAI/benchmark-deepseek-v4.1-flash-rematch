data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250432551}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250433396}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250433446}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use __dirname"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250573467}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250573680}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ejmg8ynfyhy0ehjlpz5vtqvb","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250573977}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250574038}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250576639}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250576718}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250576782}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250576872}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250576979}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250577079}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250577169}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250577260}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250602863}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250603523}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250603601}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250603757}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"./"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250603980}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250604276}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250604528}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250604576}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250634854}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250634903}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dirname"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250635190}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250636667}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250648718}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250648990}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250649047}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250649890}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250649962}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250650030}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250650138}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250650360}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250690150}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250690208}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250690252}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250690593}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250693271}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250693570}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250693650}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250693799}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250722653}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250722896}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250723102}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250723572}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250733969}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250734524}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250734571}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250734624}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250760778}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250761010}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"er"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250761312}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"un"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250762241}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" high"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250772549}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250772826}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dynamics"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250772886}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250777916}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250860100}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1628,"ts_us":1792975250860162}}

data: {"id":"fece186fa53788f287ce3125b58704b0","object":"chat.completion.chunk","created":1792975250,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":98998,"completion_tokens":98,"total_tokens":99096,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":98048,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":7,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1628,"ts_us":1792975250860331}}

data: [DONE]

