data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448368459}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448368512}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s plan entire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448368552}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" implementation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448475186}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nFiles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448475458}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448476280}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index.html. Testing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448476321}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448528263}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim-core"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448528404}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".js generated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448528519}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from embedded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448528733}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448609727}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Could write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448609770}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" JS core"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448609819}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" separately for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448609867}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tuning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448684005}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448684298}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448684346}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448684441}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448804861}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" must be single"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448804913}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file. We can write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448805026}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448805123}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".html with script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448835121}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448835261}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448835303}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via Node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448835450}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448917193}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less testing using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448917238}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regex. Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448917338}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" develop separate sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974448917403}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".js then inline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449072392}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Better create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449072754}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `sim.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449072796}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` test,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449072856}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449094227}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" embed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449094397}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" However require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449094493}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449095577}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" logic in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449127719}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index.html. Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449127821}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed maybe use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449128062}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449128185}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449234826}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"creenshot to inspect."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449234948}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check available tools"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449239240}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449239282}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ackages."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449259094}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_gvgewqd0q08qzjtvjp01sh03","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449259217}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449259630}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449259682}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449263437}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449263861}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449263957}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449264008}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449289780}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449289878}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449289959}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449290061}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" npm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449290120}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449290166}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449290984}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449291029}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" which"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449298637}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449298759}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449298944}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449299018}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449314851}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449315175}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449315221}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449315296}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" playwright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449315461}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449315865}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449315947}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449316005}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449333094}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449333197}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449333285}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449333348}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449354120}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"usr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449354175}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/bin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449354216}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449354341}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449354960}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449355026}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449355130}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449355200}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449366482}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449366637}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fire"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449366694}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fox"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449367982}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449424375}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449424447}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449424504}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449424566}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449424628}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449424728}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449424788}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449424830}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449432413}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449432657}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449432706}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449434057}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449478754}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449478922}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" availability"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449479096}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449479175}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1071,"ts_us":1792974449526928}}

data: {"id":"a774540d484600c37bacc1e14056829e","object":"chat.completion.chunk","created":1792974448,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":15470,"completion_tokens":197,"total_tokens":15667,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":6016,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":102,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1071,"ts_us":1792974449527056}}

data: [DONE]

