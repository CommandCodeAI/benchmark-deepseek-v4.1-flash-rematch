data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233175389}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Bas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233175447}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eline stable but prey always"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233175479}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap. Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233235494}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233235559}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/v"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233235611}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arious. Catastrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233235660}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with pl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233379831}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"agues/d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233379901}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"roughts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233380000}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may crash them"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233380488}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233424133}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233424274}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" balance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233424384}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that doesn't rely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233424752}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on cap and can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233462054}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" withstand"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233462509}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events.\n\nWhy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233462564}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" do prey always"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233462627}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hit "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233586930}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"620? Because reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233586991}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is very high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233587071}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and mortality"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233587220}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233650784}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233650915}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233651103}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233651210}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproductive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233723700}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233723805}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233724012}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" availability so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233724273}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233819138}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233819234}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233819670}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233819899}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233922595}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to wipe out"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233922750}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233922890}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233923608}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233986639}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? But births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233986697}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233986849}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suppressed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975233986927}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234081684}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234081870}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234081938}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234081975}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234194320}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numbers low because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234194666}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234195212}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234195290}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234270758}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate low? They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234270897}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234271148}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" little"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234271400}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why? Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234330113}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234330181}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 620 but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234330293}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234330337}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6, their energy maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234412537}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234412761}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They are limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234412829}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234412933}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234592026}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234592113}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234592180}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234592241}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 kills/gen) and reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234600288}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234600342}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234600417}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" going"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234600506}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct due cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234678793}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and plants persistent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234678879}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234678975}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234679040}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234775264}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rise more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234775551}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if kill energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234775598}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" were higher."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234775965}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" With high prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234907383}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234907528}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", they'd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234908225}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234908304}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234936358}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough. But they are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234936455}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 6."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234936522}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe most"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975234936593}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" die"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235029295}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235029640}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" old"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235029688}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235029841}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" few"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235118286}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235118391}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235118543}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235118582}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235218851}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235219152}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is slow."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235219207}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This is a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235219535}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235298981}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235299302}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" where"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235299352}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235299655}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap and predators low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235388380}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235388439}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235388496}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235388638}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235459388}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235459661}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". To have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235459727}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235459848}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235561864}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interesting ratio"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235561992}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", perhaps make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235562220}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey cap 450"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235562293}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and predator 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235623311}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235623404}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235623615}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235623683}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remove hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235707149}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235707213}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instead let prey population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235707312}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be controlled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235707372}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235795795}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235795876}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a natural density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235796131}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dependent mortality due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235796348}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crowding/d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235918067}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"isease ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235918221}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"not weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235918365}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975235918533}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But then same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236042477}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236042558}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236042667}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236042727}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236073843}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236074004}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236074145}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236074373}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236178062}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intrinsic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236178162}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236178599}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236178671}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236373704}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 620"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236373752}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236374077}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" binds."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236374183}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Introduce a soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236410118}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carrying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236410200}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity instead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236410260}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236410325}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hard:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236430925}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236430976}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probability"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236431393}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" declines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236431546}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236477892}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236478026}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" approaches K"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236478413}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and/or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236478485}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increased"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236550889}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mortality above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236551056}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" K. Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236551156}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236551407}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236624124}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236624323}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 620 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236624613}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" variance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236624752}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Choose"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236731725}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" K=380"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236731857}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236731999}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236736886}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236810939}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236811139}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" isn't visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236811303}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Define"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236811447}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `K"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236945130}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236945177}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y = 380"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236945226}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` based on environment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975236946015}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237060431}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237060517}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237060653}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" - n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237060758}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/K)` when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237078933}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237079168}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237079426}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237079492}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237152559}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237152624}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237152686}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can exceed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237152820}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237222385}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use logistic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237222445}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237222530}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237222574}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237371052}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capacity, energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237371112}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237371164}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increases"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237371328}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237506122}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction fails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237506184}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237506302}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s set soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237506349}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237540591}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"480"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237540739}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237540780}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 138"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237540822}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". As prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237680695}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" approach"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237680745}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 480"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237680797}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237681132}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237736852}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237736922}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interactions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237737014}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237737460}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237771879}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237771966}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could still overs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237772104}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hoot plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237772371}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237868334}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237868432}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"est"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237868519}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hetically,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237869072}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237953565}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-500 prey across"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237953645}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237953761}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975237953802}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k cells = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238086905}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2-4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238087006}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% occupancy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238087096}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238087147}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238174867}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s sparse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238174938}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238175040}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238175090}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238255290}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 138"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238255424}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238255570}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238255710}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238366445}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238366688}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The environment will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238366769}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" settle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238366855}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238435554}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mostly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238435639}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey at soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238435695}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap, predators maybe10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238435788}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238479362}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238479445}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"480"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238479600}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and top-down"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238479696}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238536482}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238536599}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flat.\n- Lower plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238536819}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" productivity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238537105}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238597470}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238597700}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238597762}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238597884}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238797190}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Current plants at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238797279}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 260"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238797342}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 leafy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238797405}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and biomass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238802983}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5300; prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238803070}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238803132}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 620 are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238803198}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not starving"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238845712}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238845795}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238845864}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238845935}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Cut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238930073}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant biomass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238930157}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238930217}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth and energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975238930277}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", or raise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239021513}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239021564}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239021812}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239021861}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" naturally limits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239127468}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239127564}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239127691}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap. But earlier no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239128724}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239267050}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"redator prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239267205}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grew to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239267316}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"620 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239267952}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239327237}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashed to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239327310}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low (because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239327724}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" roots were deleted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239327799}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). With roots, what"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239340311}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239340390}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239340493}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239340546}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" without predators? Lik"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239418064}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ely 620 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239418209}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants maybe lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239418312}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's test no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239418422}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239501431}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"redator with roots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239501628}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and inspect equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239501692}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239501818}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_v375chgn4d18uzvaz46r6wow","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239502648}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239502716}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239502775}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239502887}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239536169}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239536589}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239536674}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239537888}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239551004}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239551146}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239551233}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239551750}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239551838}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239552077}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239552163}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239552303}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239594443}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239594530}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239594607}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" core"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239594678}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239595184}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239595314}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('./"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239595592}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239595669}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239607884}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239607968}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239608132}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239608852}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239624458}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239624599}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" core"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239624697}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239624826}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"imulation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239625878}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239625966}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239626031}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239626101}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"184"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239674520}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239674678}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239674775}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catastrophe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239675379}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Enabled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239703856}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239703983}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239704043}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rought"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239704155}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239705191}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"false"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239705270}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239705390}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239705476}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ague"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239714206}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239714367}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"false"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239714426}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239714915}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"clipse"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239736936}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239737160}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"false"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239737233}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239737390}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239737545}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239737670}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239737833}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239737945}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239760360}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239760539}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" [];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239760589}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239760682}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239786488}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239786537}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239786618}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239786763}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239802484}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239802609}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239802753}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239802813}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239803259}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239803431}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239803490}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239803939}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239858222}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239858354}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" while"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239858478}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239858588}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"im"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239858673}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239858864}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239858977}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239859058}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239859132}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239859233}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239859301}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239860154}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239900431}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239900702}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239900825}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975239900925}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240080417}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240080502}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240080579}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240080656}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240080742}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240080817}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240081424}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240081528}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"amples"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240081614}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240081703}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240081783}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240081859}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240255731}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240255842}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240255925}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240256092}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431126}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431190}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"roots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431228}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431283}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431335}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431398}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ants"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431446}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".size"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431565}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431617}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"leaf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431657}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431716}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240431776}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240435457}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240435524}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ants"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240435573}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240435660}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bio"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240435721}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240435782}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240435841}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240435892}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436096}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Bi"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436168}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"om"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436222}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436283}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436346}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436423}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436490}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436539}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436601}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436652}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436705}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436832}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436918}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240436961}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437002}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437049}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437103}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437145}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437185}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437239}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437290}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437346}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437385}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437426}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".reduce"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437575}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437657}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437703}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437776}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437854}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240437916}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438016}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438087}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438151}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438210}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438263}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")/("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438369}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438433}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438502}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438552}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438592}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438638}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438684}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438728}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438823}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240438924}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439055}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439112}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439173}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439282}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439398}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439483}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439537}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439860}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439936}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"op"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240439976}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"red"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440054}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440128}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440194}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440239}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440628}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440704}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440761}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440812}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240440857}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240441334}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" prey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240441403}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240441456}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240441514}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" equilibrium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240441989}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" without"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240442044}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" predators"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240442667}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240442719}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1896,"ts_us":1792975240478928}}

data: {"id":"ec3357337ed979e09a1ab64f6efcc0b4","object":"chat.completion.chunk","created":1792975233,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":96647,"completion_tokens":877,"total_tokens":97524,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":95872,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":641,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1896,"ts_us":1792975240480411}}

data: [DONE]

