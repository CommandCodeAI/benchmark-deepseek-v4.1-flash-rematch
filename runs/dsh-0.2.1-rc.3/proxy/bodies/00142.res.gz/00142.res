data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979155461874}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156389265}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156570997}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156571084}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156571154}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156571217}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156571284}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156587289}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156587381}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" request"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156587454}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" log"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156587515}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156602170}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156602250}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156602321}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156619847}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156641320}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156641406}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156656380}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156656464}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156656526}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156656593}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156676963}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156687541}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156687630}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156687706}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" see"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156718593}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156718708}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156718784}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156718870}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156718948}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" image"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156726404}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156726497}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156726574}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" model"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156737679}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156737756}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156750430}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156750552}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" package"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156750627}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156765202}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156765289}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" possible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156765364}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156765434}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156782549}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" perhaps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156782628}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156782712}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156782793}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inspect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156797499}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dominant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156797584}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156816146}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156816248}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shapes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156831267}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156831316}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156848999}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156849086}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156849160}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156849215}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156861609}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"python"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156861690}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156861740}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156861803}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" create"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156879964}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156880046}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simplified"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156880101}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156897741}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"SV"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156897814}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"G"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156913940}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" recreation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156913991}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156927687}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156927800}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156927876}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156945511}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156945580}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" blocks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156963706}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156975682}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156975729}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156994149}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156994223}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" necessary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979156994298}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157009358}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157009431}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157024295}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157024377}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" OCR"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157024420}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157040280}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157084141}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157084210}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" snap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157084267}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"shots"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157088839}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157088909}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157088981}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" assume"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157089048}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157104238}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157104299}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157104371}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157129221}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157129269}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157129320}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" metrics"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157129383}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seem"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157137441}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" balanced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157137488}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157155196}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157155244}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157155285}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157155332}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157155466}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157155510}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157178036}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157188220}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157188277}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157188394}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157209536}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157219216}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157237558}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157237611}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157251853}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157251908}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leading"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157267573}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157267639}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157290230}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157290291}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157301929}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157301988}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157302035}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" equal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157302118}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157316679}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157316727}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157331713}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157331757}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157331796}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" appears"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157348162}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157367790}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157367840}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"776"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157367888}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157381251}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157381308}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157381374}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157399436}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157399479}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157414272}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157414317}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157430568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157446126}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157446179}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157461538}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" look"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157461589}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" polished"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157461634}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157522793}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157522866}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157522921}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157522979}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157523041}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157523081}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157523129}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157523219}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157523271}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" noise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157523304}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157523353}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157530717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157530769}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" barely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157530824}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157541992}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157542037}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157542078}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157542114}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157558912}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157558982}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" opacity"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157559037}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157559079}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157559129}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157559173}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157577445}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157577523}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157577611}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" look"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157591810}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" flat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157591864}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157591930}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157612105}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157612164}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gradients"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157623653}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157623698}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157656317}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157656369}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157656413}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157656457}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157656503}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157656539}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157656583}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157704901}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"D"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157704962}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157705026}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157705144}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" effect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157705232}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157721167}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157721219}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157721261}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157736511}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157736600}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157736676}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"heen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157752271}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157752330}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gradients"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157752377}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157768068}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157786671}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157786746}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157786803}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157800824}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157800892}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157818858}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157818979}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"05"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157819027}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" opacity"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157834930}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157835003}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157835083}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157853930}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157853989}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157866824}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157866905}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157881540}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157881606}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157902400}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157902448}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inner"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157916877}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" border"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157916999}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157930294}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157930363}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" strengthen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157930417}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157959747}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157961995}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reflection"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157962075}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157962129}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157978883}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157978964}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" emphasize"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157979022}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157994982}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" signature"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157995033}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979157995110}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158029615}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158029669}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158029715}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158046807}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158046865}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"heen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158046946}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158047005}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158047083}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" radial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158047112}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" highlight"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158059004}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158059057}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158101467}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158101516}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158101559}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158101602}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158107246}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158124329}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-left"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158124377}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158124437}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" linear"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158124512}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" streaks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158141321}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158156749}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158156832}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"055"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158156891}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158156951}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"035"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158172725}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158172796}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" On"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158172849}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158172893}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158172949}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158188784}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158213734}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" these"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158213815}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158213858}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158213911}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158224200}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" faint"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158224261}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158238234}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158238286}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158238328}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158238373}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158238444}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158252986}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" larger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158253052}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158269544}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" softer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158269618}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" diagonal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158290008}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" light"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158290087}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" band"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158303533}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" across"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158303598}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158303652}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158317676}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158317747}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158317805}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158335297}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" arc"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158335373}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158335471}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158354307}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158354382}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158354435}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158354488}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158354540}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158371320}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158388375}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158388440}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158388494}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158401523}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" slightly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158401583}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158453030}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158453100}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"07"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158453171}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158453236}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"05"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158453289}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158476298}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158476384}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158476445}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" much"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158479891}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158496708}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" obscure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158496769}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158515620}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158533895}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158533963}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158534032}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158534091}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wanted"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158534167}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158545198}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158545284}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"living"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158560978}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" specimen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158561036}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" under"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158561085}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158561140}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158577781}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158577838}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158577897}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158592992}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158593038}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" she"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158609857}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"en"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158625441}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158625528}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158625568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" increase"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158625623}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158685667}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158685728}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/sh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158685776}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158685877}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158685962}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158686002}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158686061}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158686107}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158686149}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"r"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158690780}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158690845}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"::"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158707126}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158707219}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158707270}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inset"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158707307}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" border"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158707375}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158723490}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158723557}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158741276}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158741327}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rgba"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158741421}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158741509}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"11"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158754893}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158754938}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" low"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158755021}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158771292}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158771356}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158771444}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158771501}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158771551}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158788696}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" edge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158788764}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" highlight"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158805277}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158805355}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158822024}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158822096}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"box"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158822148}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-shadow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158853947}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158854002}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inset"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158854067}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158854131}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158856506}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158856568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158856613}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158856654}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158856706}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158856744}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rgba"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158868999}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158869097}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"230"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158869176}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158886889}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"240"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158886970}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158887012}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"220"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158887053}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":",."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158903948}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"16"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158904029}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158920062}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158935493}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158935539}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158935588}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158935639}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158959948}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" she"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158960008}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"en"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158960054}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158967529}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" streaks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158967592}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158986260}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158986359}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158986413}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158986471}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158986537}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158986571}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979158999941}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"dust"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159000012}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speck"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159016045}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"les"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159032508}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159032594}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159047555}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159047610}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159047655}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159047749}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159064020}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" box"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159064095}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-shadow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159080804}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dots"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159080873}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159097593}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159097654}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159097737}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159112453}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159112501}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" internal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159112562}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dust"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159128653}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159128697}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159128760}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159128813}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159128867}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" signature"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159147616}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159147661}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159161578}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159161640}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159177842}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159177899}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159202447}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159202506}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159202566}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159212812}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159212873}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159212921}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159212966}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" palette"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159213013}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159231618}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159243123}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159243175}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159258316}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" warm"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159258366}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cream"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159274691}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159289916}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159289967}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159290009}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159306643}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" green"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159306690}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159323066}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159323137}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" brass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159323194}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accents"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159338740}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159338809}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159338893}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159355364}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159355411}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159371361}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159371416}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159371463}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159371512}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159388492}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159388568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159388628}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159388670}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159388724}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159388754}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159405644}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159405699}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" creates"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159424563}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159437826}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vign"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159437882}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ette"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159452504}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159452583}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159452630}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chrome"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159452719}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159505757}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159505817}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159505918}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159506010}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159506073}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159506145}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159506192}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159506250}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159506301}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159520007}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159520058}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159534183}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Latin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159534237}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159548379}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159565044}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" natural"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159565101}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ist"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159581291}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159581366}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159581419}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159581500}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159581580}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159581652}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159602716}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159614257}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159631621}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159631677}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159631724}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159646363}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159646452}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159646525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159646601}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159646667}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159646720}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159664193}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159680504}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159680562}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159680697}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159695028}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159711509}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mono"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159711555}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159711630}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159726694}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" type"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159726746}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pairing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159742955}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intentional"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159743044}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159743103}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159743157}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159743198}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uppercase"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159761308}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" micro"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159761370}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159775517}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159791337}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159791429}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159791490}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159808262}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159808360}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159808443}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" concern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159808561}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159808630}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159808700}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159824635}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" asked"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159824750}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159824858}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159840762}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159840855}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"single"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159840943}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159856373}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159873019}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159873118}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159873195}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159890752}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159890880}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159890976}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159915570}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" step"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159915680}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159915747}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159921441}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159952258}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159952346}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159952416}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159953744}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" comments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159975296}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979159987140}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160002417}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160002476}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" style"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160018225}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" block"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160035483}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160051181}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160051227}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160051287}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160051341}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160066772}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160106177}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160106251}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160106306}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160106379}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160106463}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160106523}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160106567}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160117343}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" files"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160132576}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182227}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182313}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182374}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182432}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" external"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182491}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scripts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182601}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182668}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182718}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182765}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182916}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160182971}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160199277}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" console"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160199350}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160212647}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160229149}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160229224}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Play"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160229270}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160245532}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" console"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160245593}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160263931}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" captures"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160263983}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160264058}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160277312}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160293048}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" parse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160293125}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160310157}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160310239}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160310294}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160326054}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160326106}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160326154}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inspect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160326231}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" styles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160344460}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"heet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160344520}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" css"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160344585}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Rules"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160360595}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160360643}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" see"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160360706}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160360759}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" any"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160373655}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" declarations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160373700}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" invalid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160391973}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160407862}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dropped"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160407910}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160428926}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160428994}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" needed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160429050}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160441589}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160457306}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160457414}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160457495}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160457563}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160457621}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160475577}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ix"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160475637}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160475687}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" support"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160475736}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160499168}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160499252}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160499299}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160499330}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"min"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160499375}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"()`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160531962}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160532017}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160532069}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cl"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160532139}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"amp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160532200}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"()`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160532261}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160532300}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160532354}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160532383}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160540530}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160540582}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160540632}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"@"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160560118}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"media"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160560177}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160560240}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pre"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160574948}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"fers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160575031}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-re"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160575110}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"duced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160575188}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160575233}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"otion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160575328}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160601743}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160601812}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160601874}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160601928}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160601977}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160611276}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"100"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160611328}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"sv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160624562}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160624639}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160624722}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160649300}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160649346}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Modern"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160649392}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160689574}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160689650}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160689712}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160689777}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160689988}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" HTML"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160690058}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" validation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160690179}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160740896}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nested"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160740990}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" buttons"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160741123}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/l"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160741208}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"abels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160753203}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160753275}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160753350}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160753426}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160753535}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" switch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160769201}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160791960}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160800290}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160800361}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160827699}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spans"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160827771}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160835580}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160835635}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160835680}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160850389}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160850449}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160850498}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160850540}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hint"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160850599}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160865282}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160892526}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160892574}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"name"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160895162}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160895215}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160914430}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160914532}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160937654}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" another"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160937721}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160937778}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/l"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160943489}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"abel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160943535}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160943606}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160962452}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160998672}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160998755}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160998813}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-name"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160999101}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160999164}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" div"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160999219}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979160999272}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161009201}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161009264}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161025549}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161025645}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161025762}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161025833}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161044859}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161044926}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161057273}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161057330}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161057379}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161057426}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161057480}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161057563}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161073365}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" switch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161073437}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161087875}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161087926}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" separate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161087964}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161104905}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161104993}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161121162}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161121233}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161121292}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161138858}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161138930}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" class"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161138977}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161139053}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"int"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161152016}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161152088}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" inside"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161152145}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161152195}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"control"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161173363}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161173446}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161183967}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161184015}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161184051}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" div"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161202016}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161202086}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161202132}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161202185}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161217801}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" element"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161217877}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161232239}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161232308}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161232375}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161232433}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161232478}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161249259}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161249341}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161270926}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161282356}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spans"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161282442}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161298264}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161298337}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161298391}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" nested"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161314523}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" interactive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161314613}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161314681}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161331309}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161331378}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161331432}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161331483}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" draw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161345837}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161362692}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" separate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161391474}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161391572}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161418714}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161418793}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161418861}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161418923}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"click"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161418980}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161419180}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161419243}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161435788}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161435847}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161455555}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161455615}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161455663}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `<"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161455729}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161455783}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161462036}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161476326}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161476399}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161476452}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161476507}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161495420}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161495470}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161495517}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161495557}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161507509}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161507560}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161507620}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-exp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161507666}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"anded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161530240}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161530322}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161530389}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cabinet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161530454}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" toggle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161542196}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161542245}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" true"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161557191}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161557308}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161557406}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gg"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161574047}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ling"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161574109}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161589639}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161589709}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161589785}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161589837}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161589898}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161589963}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161607795}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161607843}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ert"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161623339}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161623432}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" attr"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161623484}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161637787}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" collapsing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161637861}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161658866}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161669647}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" support"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161669700}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161687646}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161687715}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161687783}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" icon"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161687849}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161707167}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161745843}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161745905}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161745966}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" collapsed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161746016}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" spine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161746069}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161752161}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161769797}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161769865}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161769917}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161769972}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161770040}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161786591}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161786682}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161786738}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161786792}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161800307}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161800372}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161818691}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161818750}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161833831}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161833880}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161847987}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161848060}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161848137}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161848202}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161864464}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161864527}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Announce"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161864586}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ments"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161864638}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161880170}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161896827}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161896910}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161897008}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161897081}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Ann"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161913787}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oun"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161913857}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161913914}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161913967}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161914024}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" updated"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161929446}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161929522}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161929577}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161946283}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pause"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161946369}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161960817}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cat"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161960895}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" toggle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161988811}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161988889}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161996336}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979161996417}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162009979}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162010049}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162010107}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162010162}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162010220}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bulletin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162032089}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162051267}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162059930}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162060035}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162060105}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162060172}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162060233}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162060281}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162077450}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162106835}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162106915}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162107015}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162107068}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144278}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144344}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144399}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144451}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144502}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144556}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144611}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144665}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144748}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162144844}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162161581}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162161793}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162161847}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162176467}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162176551}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162191193}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162191269}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162191320}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162207362}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162228245}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162228362}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162228435}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162228530}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162327178}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162327263}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162327658}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162327752}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162327829}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162327917}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162328202}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162328281}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162328547}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162328635}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162328957}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162329038}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162329119}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"colors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162329329}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162329426}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162349049}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bulletin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162349136}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" announces"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162371850}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162390165}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162390268}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162390346}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" T"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162390418}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oggle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162490107}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162490207}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162490385}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" position"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162490629}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162490710}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162491113}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162491194}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162491270}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162491338}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162491492}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" solid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162510568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162510668}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162510751}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162510824}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162510901}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162525343}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162525429}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162525498}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162530897}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162531009}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162531082}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162531165}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162531250}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Reduced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162531319}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" motion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162548852}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162548931}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162548998}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162549058}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162584967}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dis"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162585107}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ables"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162601024}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" transitions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162601089}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162601138}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"anim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162614201}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162614287}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162614360}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162614434}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162614520}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reveal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162651460}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162651541}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162651583}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" World"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162651652}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sway"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162661243}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/d"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162677771}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ust"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162694278}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" freeze"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162694340}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162694420}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162823930}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162823986}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162824044}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162824215}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162824393}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" moving"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162824474}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162824706}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" essential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162824775}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162824928}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825132}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825174}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825216}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825259}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825312}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825465}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" appears"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825637}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" instantly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825708}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162825775}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162838234}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tint"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162854943}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162855010}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162870151}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162870231}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162870321}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162870371}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162870418}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162870460}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162870504}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162888757}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162888828}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162888893}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162888954}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162889016}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162906908}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162906997}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" four"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162907042}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162925642}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162933698}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162933754}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162933793}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162950199}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162950270}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162968416}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162968491}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"124"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162968544}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162982334}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162982417}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979162982480}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" become"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163003936}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163004030}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163004110}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"×"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163004181}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163017721}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163017790}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163017844}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163033543}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163033600}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163033646}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-grid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163048510}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163063749}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ordering"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163063820}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163097738}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163097796}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163097854}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" DOM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163097899}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163112561}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163112633}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163112673}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163133068}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163133125}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163133179}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163133229}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163145953}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" vision"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163146008}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163163312}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" metabolism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163163359}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163163427}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163163482}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163180678}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163180743}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163180781}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163180830}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163180903}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163193225}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"124"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163193284}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163193361}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163193427}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163193469}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163208729}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163208801}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163208857}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163208906}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163225278}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163225354}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163225423}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163240674}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163240768}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163240828}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163240890}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163240950}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163258676}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163258764}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163258831}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163273311}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"led"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163273391}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163273467}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163273524}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163273597}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163290502}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163290591}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163290687}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"vision"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163313477}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163313555}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163313607}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163313674}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" metabolism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163313760}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163325029}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"threshold"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163325120}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163325178}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163325219}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163337985}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163338048}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163338117}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163338181}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" <="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163338238}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"980"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163364999}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163365067}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163365120}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163365252}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163372860}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163372946}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"full"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163387872}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"),"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163387971}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163388028}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163388087}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163388159}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163388218}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163401043}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163401108}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163422187}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163422280}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163454869}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163454945}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163455604}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163455667}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-col"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163455723}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163455781}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163455845}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163469001}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"vision"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163469064}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163469130}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" metabolism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163483420}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163483496}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"threshold"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163483553}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163483601}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163483655}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163503791}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163503845}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163503947}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163504033}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" <="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163504126}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"720"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163504184}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163504233}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163519131}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" col"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163519202}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163538361}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163551544}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163551634}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163551695}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163551758}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163551807}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163551851}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" heights"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163565072}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" adapt"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163565148}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163583581}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163583648}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163583722}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163583779}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" red"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163583824}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"raw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163610498}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163610557}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" resize"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163615781}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163630813}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163630893}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163630968}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163646632}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163646717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163646765}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163646826}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163646887}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163669511}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163669601}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163669663}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"align"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163680711}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-items"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163698075}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163698149}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stretch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163698209}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163698264}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" makes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163698309}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163715371}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163734391}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cards"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163747287}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163762399}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163762473}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163762527}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163772516}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163772563}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163772604}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163772641}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163772680}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163793437}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163793513}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" HTML"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163793576}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163793631}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163807004}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" heights"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163864780}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163864846}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" differ"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163864885}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163864946}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wrap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163865013}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163876378}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163876540}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163892329}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163892409}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163908171}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" slightly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163908257}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" different"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163924475}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" y"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163924548}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163924615}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163934474}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" card"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163950147}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163950209}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potentially"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163950318}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mis"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163950379}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"al"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163969447}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"igned"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163969514}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163969579}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163969635}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163984878}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163999234}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163999287}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" titles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163999339}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979163999389}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164014240}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164014307}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164030508}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164030585}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164030645}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164030699}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aligned"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164046215}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164046289}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164046342}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164046395}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"102"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164046445}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164046499}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164063515}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" columns"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164063591}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164063630}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164079267}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"468"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164079345}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164079399}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164079449}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164096871}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164096959}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164097013}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"390"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164097061}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" full"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164109801}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164128516}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164128581}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164128650}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164145237}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164145299}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164145357}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164145415}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164145464}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164145508}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164160267}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164160341}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164174816}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" heights"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164174888}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" match"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164191975}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164192064}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" both"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164192146}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164207168}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ends"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164207245}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164225074}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164225163}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164225217}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164239251}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164239327}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164239405}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164239456}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164239513}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164239568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164260711}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164260797}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" right"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164260908}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" legend"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164274947}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164274994}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wrap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164288713}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164288762}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" narrower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164288822}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" widths"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164305098}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164305165}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164305215}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164305265}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"102"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164320881}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164320945}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164320990}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"633"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164321036}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wide"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164336448}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164356577}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164356632}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164356677}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164370302}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"54"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164370357}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164370413}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"342"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164370517}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164388284}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" three"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164388340}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" items"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164407537}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164407616}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"220"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164407662}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164419740}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164419811}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164419879}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164433677}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164433751}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164433804}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164433859}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"390"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164433916}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164433973}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164450260}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164450337}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"47"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164465630}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"%="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164465691}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"168"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164465745}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164481982}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" items"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164498245}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wrap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164498323}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164498389}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164516070}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164516147}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164528793}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164528864}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164528920}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164545911}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164546021}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"60"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164564205}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164564269}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164564308}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164564353}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164582623}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164582675}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164582716}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164616411}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164616520}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164616605}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164616676}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164616753}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" card"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164616825}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164626966}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" always"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164627064}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164642820}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164642920}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164664019}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164684325}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sub"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164693051}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164720311}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164720393}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164721747}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wrap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164738336}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164787998}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788082}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788141}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788210}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788276}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788340}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788406}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788476}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788537}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788603}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788680}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788746}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" axis"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164788813}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164814450}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164814543}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Pred"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164818225}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164835484}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164850199}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164850302}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" clipped"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164850377}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164866205}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164866293}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164884772}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164884857}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164898356}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164898428}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164916379}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"390"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164916446}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164931220}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"358"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164931315}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164947018}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164963622}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164963688}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164963755}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164963837}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164985360}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164985437}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164985494}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164985557}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164985646}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" big"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979164985689}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165002067}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165032770}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165032824}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165032881}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"390"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165032923}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165033084}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165033144}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"72"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165033200}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165050694}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165050767}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165064233}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165064298}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165064350}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":");"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165064409}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165075717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165075775}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" header"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165091648}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165108571}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165163624}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165163690}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165163741}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165163861}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165163940}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165163996}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165164048}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165164107}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165164173}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165164243}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165176306}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165190438}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165204656}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165204704}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165219789}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165219867}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165219944}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"390"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165219998}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165242534}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wrap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165253642}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165253703}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165269385}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165269437}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165285132}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165285178}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165285236}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165300690}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165300768}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"126"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165300837}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165322957}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165323049}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165323106}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165323161}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165335391}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165335457}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165335503}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165335580}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165356980}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stays"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165357043}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165357117}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bottom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165375126}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165375198}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165375236}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165375279}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165384785}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165384844}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165384910}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165396482}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" census"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165396539}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165423675}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165423723}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165429649}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165429729}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165429796}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"320"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165444429}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165444481}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165444525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"466"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165467823}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165477190}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165477264}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165477319}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165477367}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165477414}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165495498}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165495555}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165495606}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165495674}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165495747}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165495811}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165510228}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" printed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165510295}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165525663}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165542186}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" required"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165542256}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165542296}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165559215}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165559305}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165559368}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"@"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165574014}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"media"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165574065}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" print"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165574099}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165574153}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165574202}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165574269}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165591827}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165591883}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165591946}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165592013}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165592085}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165592169}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165608130}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165608191}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165623656}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165639692}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165639751}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165639787}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165656566}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165670331}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165670397}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" II"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165687734}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"FE"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165687807}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165687862}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165687939}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"module"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165703865}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".exports"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165703937}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165704029}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165718904}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165718954}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165719006}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165743672}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165743738}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165757913}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165757983}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165758028}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165758121}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" someone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165758157}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" opens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165768165}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165768239}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165790030}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165790102}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Node"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165790154}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165799433}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" They"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165815244}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165815308}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165815346}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165815412}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165836354}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165836404}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extracting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165848650}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165848713}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165848770}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165862966}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165863046}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165880388}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165880466}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165880525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165880568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165898117}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" call"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165898203}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165912131}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165912187}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165912235}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165933061}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165933128}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165933181}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165933223}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165933281}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requirement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165933319}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165944395}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165944457}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165959701}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165959788}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165959858}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165959898}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165982346}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" satisfied"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165982446}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165982501}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165995121}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exposed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979165995173}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166010070}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166010162}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166010221}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166028701}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166028774}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166028828}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166054112}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166054165}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166054221}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166054299}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166054354}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166061985}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166062063}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166062120}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166062173}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166074581}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166074661}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" options"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166074717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166089613}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166106613}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166106692}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166106746}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166123299}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"gener"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166143760}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166143832}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166143902}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166143976}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166153793}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166153837}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166153896}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166153940}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166169767}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" takes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166169852}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166169894}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166187150}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166187218}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166187276}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166187318}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166187404}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166187488}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accept"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166202307}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166202365}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166202412}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166218645}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166218701}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".S"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166234165}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"imulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166251390}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166251456}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166251534}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166251593}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" needed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166265107}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166265175}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166265230}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166265284}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166265331}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166284655}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166284700}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166284764}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166284817}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166284868}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166301615}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166301699}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166301771}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166315537}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166315598}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166315647}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166329139}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166329205}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fresh"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166344855}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166344929}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166344978}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" runs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166345028}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166361767}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166361819}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166380762}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166380833}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166380886}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166404484}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166404559}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166404621}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" UI"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166415112}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166415179}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166415230}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166432508}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166452367}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" documented"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166452435}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166462741}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" options"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166479387}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166479459}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166479529}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166496399}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166496466}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166496520}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166496576}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166496617}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166496698}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166517015}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166517094}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166517148}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ulation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166517200}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166528989}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" constructor"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166529045}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166529101}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166543767}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" validate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166543849}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" options"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166560936}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" types"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166561027}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166576094}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166576170}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" relevant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166594133}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166594179}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166594258}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166594333}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166594384}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166594439}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166607523}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166607590}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166607642}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166607695}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166628162}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" DOM"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166628242}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166642779}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" verified"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166642868}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166669173}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166669240}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166669296}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166673377}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" call"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166673447}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166688808}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"window"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166688880}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166705033}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166705109}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" II"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166705179}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"FE"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166723449}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" global"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166723516}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166740586}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166740678}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166740725}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166740774}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166740850}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166757776}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166779209}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166779279}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"global"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166779334}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"This"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166804408}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166804463}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166804512}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166804571}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166804631}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166804673}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166804712}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166823143}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166823194}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166823237}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" separate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166837075}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166837149}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166837202}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166837255}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166837309}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166837353}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166852418}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166852485}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166852530}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166852582}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166871018}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166889060}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166889106}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166902060}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166902132}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166902175}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" created"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166916477}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166947487}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" init"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166947561}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166947616}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166947704}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" someone"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166947763}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" runs"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166968598}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166968672}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166984653}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" console"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166984726}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166997807}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166997855}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979166997937}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167010914}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167011001}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167011064}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exposes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167011101}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167027318}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"current"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167027390}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167027447}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167059274}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" constants"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167059357}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167059460}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167059509}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167059568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167059630}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167075007}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167075092}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167075144}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167075207}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167075295}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167075358}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167092342}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167108995}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" name"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167109045}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167126543}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"V"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167143629}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"iv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167143689}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arium"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167143727}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Core"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167155906}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167155973}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167156031}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167182865}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" globally"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167182941}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167189128}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167189186}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" conflict"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167203498}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167203584}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167220456}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167236041}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167236107}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167236147}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" app"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167236257}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167236337}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" II"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167256828}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"FE"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167267393}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167267470}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167267525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167267576}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167267640}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167294328}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167294405}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167294465}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167294521}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167294619}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"F"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167301180}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167337216}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shortcut"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167337268}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167347841}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167364935}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167365050}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167381696}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focused"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167399922}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167399979}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167414041}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167414107}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167431809}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167431874}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" surprise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167447173}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167447226}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167466346}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" documented"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167466429}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167466484}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167476967}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167493650}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167493739}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167493929}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167494005}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167494090}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167494154}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167508713}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167508762}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167525603}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" outlines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167525654}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167543867}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167543923}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167563296}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" brass"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167563353}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167563480}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167582169}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167582231}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167590193}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167590241}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167605626}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stage"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167605709}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167605757}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167635850}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167635920}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167658712}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167668144}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167668227}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drawer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167668290}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167686798}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167688819}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167688908}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167688980}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167689047}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167701954}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ables"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167719357}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167719505}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167719598}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167719677}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167733758}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" none"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167751011}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167751133}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167751229}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167782886}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167783007}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167783102}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167783199}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167783305}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167783398}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167783500}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"bars"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167799603}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167820044}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167820160}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167820235}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167834524}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"light"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167834602}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ranges"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167876129}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" custom"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167876200}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167876250}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167880373}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167880452}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167880508}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167880560}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167880643}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167880710}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167894562}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reduced"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167894623}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167894679}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"otion"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167910559}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" static"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167910636}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167910682}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167926451}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167944674}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167944745}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" RED"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167944810}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"UC"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167958920}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ED"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167958992}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"_"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167959039}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"QU"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167985653}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ERY"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167985713}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" matches"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167985763}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167985813}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979167991884}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168010804}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shown"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168024609}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" until"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168024666}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168040112}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168058549}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168058614}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168075963}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168076030}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168076073}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168097606}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dust"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168097667}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168108882}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" skipped"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168125251}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168125308}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168125358}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168139604}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sway"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168154232}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" frozen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168154283}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168168341}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168168398}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168168447}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sp"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168188406}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rites"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168202717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168202767}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" move"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168202830}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168236263}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sim"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168236329}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" positions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168236403}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168236484}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"essential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168236544}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168251852}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168251922}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168251973}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wob"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168252022}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ble"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168281438}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168281509}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168281616}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168281692}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168281743}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" move"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168301645}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168314729}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168314834}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168314914}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168314969}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168362361}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168362429}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168362483}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" transitions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168362549}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" suppressed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168362654}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168383185}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168383266}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168383331}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168383394}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168383453}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168383512}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168392873}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168393021}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168409448}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168435299}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168435366}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168435419}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168449528}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168449595}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168459813}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Under"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168459874}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168475013}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168492296}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168492368}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168525525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168525628}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168525703}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" suspended"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168525767}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168525831}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168525888}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" paused"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168525944}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168539007}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168539072}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" pulse"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168539111}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168553516}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168553581}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168571472}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168571551}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168571605}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168571664}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168571747}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168571792}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Click"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168571848}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168586649}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168586745}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168586788}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Con"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168600501}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"clude"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168619924}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168619972}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" button"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168620022}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" triggers"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168620069}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" finish"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168632710}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168632751}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168649735}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168649834}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168649897}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168669017}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168669081}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wonders"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168683092}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" what"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168683171}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" happened"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717246}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717326}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717384}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" veil"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717435}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717586}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717660}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717714}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168717780}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168731010}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168731095}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168731156}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168731209}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168731264}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bulletin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168731316}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168748477}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168762411}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168762489}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168781396}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"=true"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168781473}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168781549}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168781606}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168794610}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168794703}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ann"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168813432}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"oun"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168813498}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"cer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168813560}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168813634}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168832332}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" big"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168832413}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168832466}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168845173}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168845220}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168864664}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-hidden"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168878573}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168878637}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168878986}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168879057}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168879116}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168879175}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168903717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168903792}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168913758}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168913841}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168927618}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168941314}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168941363}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168941439}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accessible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168963470}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" names"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168963522}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168969688}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" name"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168987717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168987785}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168999690}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979168999778}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169028432}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169028480}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169028566}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169028646}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169028706}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" empty"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169028737}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169034952}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" contains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169048474}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169048538}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169066738}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169066794}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169066862}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169066911}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169067041}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ases"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169083872}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169083939}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169084004}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169112219}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169112303}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169112386}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169112445}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169112486}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169112540}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169112587}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169132120}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hover"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169132180}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tool"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169145866}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169145935}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169163212}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169163268}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" update"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169163328}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169177823}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169177888}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169196788}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169196874}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169196941}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" include"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169208774}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169226533}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hover"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169226597}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169226644}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169226709}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169243689}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169259046}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169259123}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169278984}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" summarizes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169279040}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169289309}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169289387}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169305289}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169305358}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169305414}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169305470}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169305533}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169305563}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" When"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169321929}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169321981}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169322045}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" animate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169340495}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169354045}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169354099}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169354186}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169354253}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169369414}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169389482}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" remains"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169389552}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169401517}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cancel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169401563}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169401631}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169416510}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" window"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169416562}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" resize"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169416648}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169435285}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169435341}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169449664}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".red"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169449729}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"raw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169469362}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169469422}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169469471}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169469522}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cancel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169469607}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169482927}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" animation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169483001}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169483056}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169498200}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reveal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169498270}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169521133}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" resize"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169521276}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" draws"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169521362}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169528270}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169528340}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169544788}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169544834}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169544922}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" animation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169564142}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" loop"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169564208}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" continues"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169583771}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169583835}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169583914}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169596548}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potentially"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169609275}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" flick"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169609334}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169626428}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169626499}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Rare"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169626548}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169641239}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169641302}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169641367}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169641423}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169657530}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169657594}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169657668}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169657726}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" An"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169657799}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169657855}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169673924}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-l"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169689374}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ive"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169689440}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169689494}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" region"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169689552}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169707184}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169727796}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" long"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169727875}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169735055}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169757531}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169772311}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169772385}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169772438}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169772490}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169772539}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169772589}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169788238}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169788296}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169788365}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169788414}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169788464}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169801957}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"::"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169817897}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"before"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169817958}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169818009}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" removed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169833320}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169833388}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169833442}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fixed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169856297}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grain"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169867656}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169867708}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169867748}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169881171}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" performance"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169900063}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169900183}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169900257}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169900324}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169900391}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169900443}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169916592}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169916661}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169916732}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169916786}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"body"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169930376}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169930465}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169969613}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" noise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169969707}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169969765}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169969817}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169969869}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169978273}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169978333}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169978383}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169978432}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" additional"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169978480}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gradients"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979169993472}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170018368}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170018421}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170018457}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170027020}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" appear"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170045521}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170045613}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speck"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170065945}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"led"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170077548}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170077609}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170077663}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170093313}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170093390}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170093456}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170093508}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170093571}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170093632}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170111702}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" big"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170111773}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" book"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170111827}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ish"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170125774}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170145333}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170145385}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170162659}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170162730}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wide"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170162782}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170175046}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170175116}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170190725}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170204755}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170204843}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" measured"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170204901}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170224543}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170253963}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170254059}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170254136}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170254201}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170268958}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"back"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170287512}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170287616}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170287696}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170300673}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" than"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170300759}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Charter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170321211}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170333426}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170333509}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" white"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170333574}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-space"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170352084}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170352175}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170352236}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170352303}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170352369}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170366016}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" column"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170366102}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170366165}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" push"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170392696}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170398122}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deck"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170398211}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170398280}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"status"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170412913}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170413032}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170428252}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170449022}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" columns"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170449125}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170449203}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fixed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170460249}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170460348}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170460420}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170460496}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170476467}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170476568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170476647}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170476724}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" into"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170493433}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170493519}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" next"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170493585}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" column"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170510133}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170510228}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" causing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170528142}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overlap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170555057}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170555133}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170555199}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170555263}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170555322}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170562979}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170563069}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170563139}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" column"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170574500}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170574579}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170574639}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170574711}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170574770}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170589226}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170589332}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170589405}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" measured"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170607770}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exactly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170619159}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170619229}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170638712}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" environment"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170653279}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"—"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170667801}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"border"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170667882}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170684587}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170684660}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170684718}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170684774}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wider"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170700128}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170716272}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"back"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170716331}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170716401}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170733767}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" used"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170733830}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170733880}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170733947}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804455}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804512}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804590}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" into"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804673}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804730}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" deck"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804780}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804847}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804912}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170804979}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170805024}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" real"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170805085}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cross"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170805188}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-platform"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170812525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" risk"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170827391}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170827462}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170827525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170827580}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170827633}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170827670}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170843280}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"m"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170843350}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170859399}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"head"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170859452}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170859528}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170859607}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170859703}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170859743}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" measured"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170879599}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170890868}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"761"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170890937}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170905814}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170905892}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exactly"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170906055}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170921429}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170942339}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170942402}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" item"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170942449}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170953619}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fills"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170953688}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" available"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170953727}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170971720}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170971783}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170971825}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170971913}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979170985616}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" narrower"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171001189}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" than"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171001250}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171001302}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171027937}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171028011}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" element"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171028075}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171034055}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171034119}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171034172}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171051621}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171051699}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171051740}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171066526}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171066572}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171085295}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171085339}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" h"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171099906}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171099953}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" element"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171100018}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171116499}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171116583}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" equal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171116640}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171133831}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171133890}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" column"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171133946}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171134033}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171147286}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"fr"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171147339}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171147393}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171147442}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" block"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171170166}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171181983}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171182040}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171196190}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171196265}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171209390}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171209475}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171209530}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171224377}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171224451}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171242590}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"550"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171242661}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171256397}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171256471}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" element"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171256519}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171277569}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171277635}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171277686}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171277785}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171291531}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171291603}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171311185}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171311273}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171311340}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" equals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171321577}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171321636}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171339058}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171339121}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171339176}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" exceeding"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171354296}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171354365}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171370684}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171385380}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171402696}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171402761}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171416877}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171416985}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171434372}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171434448}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171434558}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171434717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171450046}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171450140}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" much"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171450209}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171465436}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171465525}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171465594}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"white"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171483192}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-space"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171498906}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171498978}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171499034}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171499085}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171499149}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171499202}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171512768}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171529850}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171529934}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reveal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171545344}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171573547}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171578329}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171578393}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171578454}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"144"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171593230}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171593306}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171593361}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171593423}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171593490}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171593540}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"client"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171608669}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171627566}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171627632}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"762"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171627686}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171627741}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171627821}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171627873}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171642241}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171642310}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171642365}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171642418}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" margin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171658168}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171672368}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" How"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171672437}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" close"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171688814}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171723330}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171723410}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171723473}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" measure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171723535}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" using"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171723587}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171736692}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171736753}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171736876}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171752746}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171752803}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171770274}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171770336}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171770398}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171798261}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171807415}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171807487}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171817613}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"59"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171817661}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171831597}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171849121}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Charter"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171868937}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171869035}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171869134}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171869195}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"455"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171881888}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171899839}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171899912}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171899967}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171911569}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171911631}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" using"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171911677}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171911789}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"get"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171927122}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"B"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171943476}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ounding"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171943553}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Client"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171943620}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Rect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171943681}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171943742}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171943792}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171963454}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171963526}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171963586}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" There"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171978465}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171993292}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171993356}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" span"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979171993407}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" around"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172007406}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172023135}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172023203}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172023260}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Canvas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172023318}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" measure"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172038711}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Text"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172054579}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172054701}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" computed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172054790}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" font"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172070528}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172070622}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172070678}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172089793}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" calculate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172089866}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172089924}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_ZPSmfypH8rOd2Fomqwqt3548","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172120279}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172133705}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172133772}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172133822}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172133883}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172133944}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172152078}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172152136}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172152182}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172152224}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172165791}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172165872}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172165938}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172210561}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172210652}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"JS"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172210717}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172210794}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172210903}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172210976}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172211063}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172211124}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172211210}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" require"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172211270}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172211346}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172211385}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172214723}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172214799}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(async"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172214872}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172214934}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172214997}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172215058}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172231232}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172231305}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172231364}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172231426}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" chromium"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172231485}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".l"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172231544}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172247951}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"unch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172248024}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172248085}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"exec"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172248152}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"utable"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172248214}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172248275}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172263089}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172263165}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172263228}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172263284}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172263341}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172263384}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rows"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172278110}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ers"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172278205}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172278273}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rom"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172278349}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172278444}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172278501}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"124"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172293380}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172293487}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172293567}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172293645}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172293703}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"inux"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172293761}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172309432}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172309537}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172309609}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172309691}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"args"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172309759}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172309819}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172325499}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"--"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172325585}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172325654}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172325715}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172325772}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172325851}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172344288}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172344381}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172344464}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172344550}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172344643}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172344702}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172358123}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172358218}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172358278}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172358382}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"viewport"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172358459}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172358534}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172374593}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172374667}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172374718}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172374805}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172374874}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172374948}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172392076}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172392177}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172392246}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172392328}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172392409}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172392489}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172423999}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"oto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424085}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424145}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424353}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424434}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'+"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424499}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"process"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424563}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424625}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424688}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424750}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"+'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424808}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172424873}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172437265}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172437382}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172437463}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172437551}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172437647}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".wait"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172437751}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"For"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172455551}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Timeout"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172455694}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172455777}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172455850}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172455949}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172456046}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172470760}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172470839}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172470933}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" page"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172471011}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172471066}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"valuate"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172471164}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172486488}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172486615}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172486704}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172486771}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172486824}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172486918}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172501367}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172501491}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".querySelector"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172501618}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172501750}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172501847}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172501926}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172519230}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172519328}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172519406}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172519475}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172534524}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172534625}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=get"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172534703}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Com"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172534781}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"puted"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172534865}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Style"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172534940}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(h"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172550455}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172550558}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172550640}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172550710}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172550779}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"document"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172550863}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".createElement"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172567593}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172567703}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"canvas"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172567785}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172567862}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172567938}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Context"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172568017}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172579444}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172579551}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172579629}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172579706}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172579777}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".font"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172579853}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=`"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172604537}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172604638}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172604715}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".font"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172604790}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Style"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172604868}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172614578}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172614695}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172614783}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".font"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172614873}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Weight"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172614957}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172615036}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172631723}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172631827}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".font"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172631916}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Size"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172632003}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172632089}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172632171}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172648267}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".font"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172648412}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Family"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172648493}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}`"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172648568}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172648713}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172648792}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172662092}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" title"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172662197}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172681621}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172707609}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"The"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172712272}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" Quiet"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172712365}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" Viv"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172712453}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"arium"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172724581}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172724683}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172725088}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172725172}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172725278}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"=c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172741067}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172741171}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"measure"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172741262}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172741344}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"(title"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172741426}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172755536}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172755652}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172755741}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172755873}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172755960}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"font"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172756044}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":c"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172777974}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".font"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172815758}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172815861}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172815937}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172816007}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":m"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172816090}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172816186}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172816266}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" element"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172816323}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172817974}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":h"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172818071}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172818145}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172818215}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ounding"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172818323}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Client"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172818401}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Rect"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172851949}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"()."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172852011}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172852091}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172852174}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" scroll"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172852219}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":h"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172852295}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".sc"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866122}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866213}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866298}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866362}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866431}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866490}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866566}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866656}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866729}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" family"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866798}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172866871}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172883073}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".font"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172883154}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Family"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172883213}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"};\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172883287}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" }));\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172883367}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172883420}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172899194}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".close"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172899370}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172899481}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172899570}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172899643}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"JS"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172899704}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172922269}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172922371}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172922435}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172922521}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172934819}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172934888}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172934957}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172935028}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172935087}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172935145}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172956501}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172956602}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172961645}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172961718}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172961765}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172961872}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172976540}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172976702}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Measure"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172976828}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" title"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172976910}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" text"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172994755}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172994841}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" versus"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979172994988}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" container"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979173013704}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979173031895}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":1870,"ts_us":1792979173044996}}

data: {"id":"204bdb077567b3ac5698c995e6c1b881","object":"chat.completion.chunk","created":1792979155,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":550333,"completion_tokens":2923,"total_tokens":553256,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":549632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":2605,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1870,"ts_us":1792979173084086}}

data: [DONE]

