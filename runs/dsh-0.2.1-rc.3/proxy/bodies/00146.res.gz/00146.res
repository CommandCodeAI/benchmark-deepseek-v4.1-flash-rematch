data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979262220473}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"All"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979262866176}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979262978308}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979262991841}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979262991918}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cleanup"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979262991995}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dev"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979262992035}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" directory"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263009344}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263009393}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" leave"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263009437}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263023992}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263024076}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".html"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263024131}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263024189}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Verify"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263024235}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" real"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263040017}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"path"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263040062}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263064472}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_4lYtCalj3bGtfsomerj89905","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263088648}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263106552}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263106621}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263106687}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263106753}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263106811}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263121114}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"real"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263121163}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263121232}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263121306}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263139267}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" real"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263139317}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263155302}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" index"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263155385}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263155455}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263155550}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" du"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263169785}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263189672}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263189753}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263189805}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263205969}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263206011}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263206090}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263206166}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263219317}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263229959}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263230037}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263230083}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263230156}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263230233}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263269740}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Verify"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263269788}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" development"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263269844}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" directory"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263269898}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263269977}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" before"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263270060}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" cleanup"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263270127}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263270192}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2117,"ts_us":1792979263276675}}

data: {"id":"fd30f2e1d798aa17d2da1ea7dfb0fe20","object":"chat.completion.chunk","created":1792979261,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":562017,"completion_tokens":91,"total_tokens":562108,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":561664,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":17,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2117,"ts_us":1792979263301514}}

data: [DONE]

