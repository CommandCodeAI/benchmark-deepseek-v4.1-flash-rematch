data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726700062}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1lc6wqqs8dn2k3c9hppypqbo","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726700179}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726700242}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726719667}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726719754}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726720283}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726720330}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726748286}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726748377}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726748431}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726748546}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726766832}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"425"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726766950}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726766998}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"465"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726767049}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726790651}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726790794}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726791293}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726791415}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726826812}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"emplate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726826900}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726827114}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726827534}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726828122}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726828312}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726828389}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726828662}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726870845}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726870922}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"View"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726871080}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726871150}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" section"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726973867}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" markup"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726973923}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726974014}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2990,"ts_us":1792976726976650}}

data: {"id":"4f8314a2b89a81c4df551bc4ebb68f43","object":"chat.completion.chunk","created":1792976726,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":318144,"completion_tokens":69,"total_tokens":318213,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":310144,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2990,"ts_us":1792976726977015}}

data: [DONE]

