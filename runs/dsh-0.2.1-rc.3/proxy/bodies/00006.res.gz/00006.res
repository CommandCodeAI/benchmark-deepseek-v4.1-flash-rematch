data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456537709}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456537792}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser. Might install?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456537825}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Network maybe prohibited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456596178}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456596237}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" external libs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456596450}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/net for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456596627}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456685721}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able but development can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456686566}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456686621}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" npm? Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456686665}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright install possibly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456765459}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network. We don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456765526}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t need screenshots necessarily"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456766275}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456766351}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspection would help"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456835950}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe package has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456836030}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chromium?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456836146}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check /opt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456836782}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456889692}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rjy1q2orc61ijl0obhho8ey4","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456889784}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456889905}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456889957}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456918864}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456918913}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456918977}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456919005}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456928063}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456928140}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456928245}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456928309}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456928413}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456928861}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456929223}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456929272}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456958521}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456958603}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456958671}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456958716}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456970336}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456970479}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456970662}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456970729}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456971639}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456971715}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456971811}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456972657}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456991390}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456991466}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456991770}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974456991829}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457014250}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"depth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457014309}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457014584}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457014878}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457015072}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457015268}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457015339}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457015452}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"name"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457034261}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457034374}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457034429}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457034572}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457058743}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457058792}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457058841}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457058889}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457059431}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457059474}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457059529}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457059582}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457091582}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457091644}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457091749}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457091970}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457114224}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457114279}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457114312}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457114359}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457125456}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Search"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457125548}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457125620}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457126407}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457167861}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457167913}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" system"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457167957}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457168009}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457215812}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457215902}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1652,"ts_us":1792974457215976}}

data: {"id":"5c8f663d013eb772554324f10fa49470","object":"chat.completion.chunk","created":1792974456,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":15998,"completion_tokens":159,"total_tokens":16157,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":15872,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":54,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1652,"ts_us":1792974457216069}}

data: [DONE]

