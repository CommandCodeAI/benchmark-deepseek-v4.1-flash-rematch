data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978930280650}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Find"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931603411}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ings"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931854916}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931868053}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931868157}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Ext"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931868236}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"inction"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931898196}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931898283}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931898351}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931898414}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931899415}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931899522}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931915710}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931915776}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931915861}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Bug"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931915950}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931932238}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Tra"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931932330}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931958597}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931958668}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931958725}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931958779}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931968777}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" reference"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931968856}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931968913}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931986409}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" even"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978931986478}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" though"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932003394}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932003479}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932003541}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932018413}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932018505}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932041081}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932041163}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932041223}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Summary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932051619}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932051698}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932051752}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932051808}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932051860}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"series"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932075918}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932075969}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932079667}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" available"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932079733}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932093450}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932093512}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932115628}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932115707}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinction"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932115768}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932125923}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932143546}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932143644}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932143723}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" say"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932158432}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932183131}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Pre"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932183236}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"y"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932191106}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mean"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932191184}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932191237}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932191289}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932212981}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"98"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932213072}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932213130}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932213183}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932213234}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932213286}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"05"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932224426}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932224487}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" without"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932224543}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" noting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932240436}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932240507}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932255518}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932255572}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932272011}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932272076}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932272129}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wrong"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932288791}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932288868}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"those"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932288923}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932312937}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932313007}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932313064}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932320616}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932320704}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observation"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932338477}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"),"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932354746}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932354820}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932354878}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932354939}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932376074}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" say"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932376144}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932388014}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932388089}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932388133}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932388181}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" draw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932403224}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932418654}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" until"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932418724}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinction"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932418813}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932437225}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932437310}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932437367}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932437423}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932451595}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932451720}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932468380}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932468434}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932468500}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932468538}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932483762}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ism"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932483826}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"atch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932500739}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932500797}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932518561}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932518617}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932551132}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932551209}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932551274}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932551318}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932562559}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932562633}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932562689}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" based"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932562733}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932575526}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932575600}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" sample"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932575672}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932585404}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932585477}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932603878}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932603925}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932613059}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" draws"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932629458}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932647646}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932647711}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932647793}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932665009}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932665079}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" available"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932665131}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932701763}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932701856}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":">"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932701915}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932701969}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932702018}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932702088}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" point"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932710579}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932710655}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932727371}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932727469}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932742549}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932742603}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932742665}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932742729}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expected"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932742789}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932779369}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932779554}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932779625}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtitle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932779677}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932795173}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" indicate"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932795225}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932827105}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932827178}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932827250}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932827323}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932827383}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932827430}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bug"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932840159}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932840226}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932840262}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932840342}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Weather"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932840439}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932862428}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932880799}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932892143}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932892248}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932892316}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932892380}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932910337}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932910418}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932934153}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932934250}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wraps"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932940784}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932940856}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932960189}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932960273}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932960328}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932988961}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932989032}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932989086}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932989211}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"129"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978932989278}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933014072}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933014153}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933027237}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933027315}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933027368}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933027415}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933027471}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933038060}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933038132}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933051319}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933051410}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933096057}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933096127}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933096178}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" most"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933096227}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" recent"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933096271}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drift"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933097828}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933097891}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933097996}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933117062}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"dr"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933135780}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ift"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933149025}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Sentence"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933149073}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`)"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933184274}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933184365}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933184436}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933238955}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239055}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239127}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239193}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" starts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239278}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239371}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"By"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239437}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239518}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" close"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239599}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933239674}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" both"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933244287}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"...\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933244395}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933244480}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933258880}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Tw"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933276305}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"elve"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933276410}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" droughts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933276503}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933300644}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933300764}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933300837}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933317972}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933318098}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933318184}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Summary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933318698}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933318788}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" correct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933337864}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933337938}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933337990}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933354321}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933354451}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ensus"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933354548}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" status"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933365555}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933365623}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uppercase"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933365711}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933385611}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" CSS"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933385687}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933385754}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933385805}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933409549}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933409659}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933409726}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933423592}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933423661}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933423722}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933440356}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" padded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933453930}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933454013}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933468461}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pad"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933485391}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933502246}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933502337}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933518000}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933518106}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gives"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933518186}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933518243}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933533666}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933533757}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933533818}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933533918}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933534006}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933534065}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933551106}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933551186}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933565700}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933589824}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933598716}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933620985}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933621051}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933640199}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933640264}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933640318}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Ch"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933640368}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"arts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933640419}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933640467}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933647813}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933647875}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933665359}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933665433}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933665492}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933665547}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933665602}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933682907}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" many"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933683013}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933697302}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stack"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933714106}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933728679}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933728768}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933745076}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933762006}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933762086}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933777706}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933777780}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933777862}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933777949}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933778005}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933794028}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933794100}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933794248}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933816306}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933816398}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933816475}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933828393}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933851594}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933851683}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933851734}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933851789}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933861045}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" three"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933861123}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" coincide"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933878517}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933894152}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" glyph"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933894212}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933917574}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" offset"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933917619}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" horizontally"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933917667}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933931451}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933931518}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933931558}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933931649}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933945951}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933946004}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933946062}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933956241}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" continue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978933975493}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934007018}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934007183}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934034051}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934041903}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Tra"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934041978}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934067824}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934067903}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stop"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934074340}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934086143}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934123931}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934124023}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934124082}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934124135}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934124226}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934159953}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934160030}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934160083}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934160135}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934160201}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934160339}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934160410}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934182640}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/p"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934182722}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"red"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934182901}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934182964}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drop"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934209785}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934209846}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934209906}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934209978}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934210052}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934220134}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934220189}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934220264}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934220345}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934220402}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934239829}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934239914}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934263311}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934276876}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934292485}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934292566}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934292621}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expands"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934316688}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934316736}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934330151}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934330222}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934360055}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934360122}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" large"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934360165}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934360270}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934372936}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934372999}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934395624}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934395703}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934395762}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934395804}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934395864}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934407744}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934407822}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" title"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934407879}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934422433}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934422493}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934450259}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" meadow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934465227}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934465318}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934486745}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934486822}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" close"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934486867}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934486925}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" even"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934486988}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934487126}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934487196}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934501619}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934517647}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934517732}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934517812}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934517874}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" terminal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934517933}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" errors"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934538040}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934546314}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934546365}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934546442}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934546521}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934560266}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bug"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934560323}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934586998}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934587089}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934587139}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934630778}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Summary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934630856}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934630896}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" looks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934630933}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934630974}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934631008}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" available"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934631111}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" samples"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934631175}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934631213}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934654558}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" them"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934654698}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934668426}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934668505}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934689019}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934689125}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934689187}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"rait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934689371}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934689435}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934689507}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934689579}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934731203}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934731282}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934731489}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" coherent"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934731571}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934760331}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934760408}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934760465}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934760538}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934760641}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bug"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934777973}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934778044}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" In"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934778085}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934795299}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"build"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934795378}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934803529}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`,"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934803624}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934818450}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934818509}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934818595}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934834620}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934871772}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-label"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934871870}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934871941}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934872022}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934887123}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"pre"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934887227}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"y"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934902402}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934902487}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934919291}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"138"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934919386}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934919435}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934948306}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934948371}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934948410}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934948481}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934948577}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Tra"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934948642}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934957673}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" canv"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934957723}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ases"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934968177}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" say"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934968245}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934968287}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Pre"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934985918}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"y"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934986019}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mean"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978934986069}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935004388}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935020623}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935020678}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935020738}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935040697}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" better"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935040750}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935040785}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935040839}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935072436}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935072508}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" observed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935072692}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935072745}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935072801}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" critical"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935092939}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935093014}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935093076}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935093143}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935093225}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"hips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935097986}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935113242}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935126681}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935126746}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935144461}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" make"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935144537}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935168798}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" large"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935181648}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935181722}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935192705}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935192790}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" limit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935192890}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chip"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935209346}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935209430}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935229429}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935246567}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" summary"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935246659}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935267135}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935283996}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935284066}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935284184}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" grows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935299327}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935299407}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935313466}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935313532}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935328915}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935328994}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935329035}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935329097}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"One"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935346779}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935360474}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935360537}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935360585}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935360622}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935375026}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935375096}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" are"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935392240}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935392298}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935405917}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935405996}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935406065}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" weather"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935423849}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935438524}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935455090}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935455156}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935468719}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935468781}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" becomes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935468832}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extremely"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935484008}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935484084}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935484139}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" causing"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935484212}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935500175}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" entire"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935500245}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935519891}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935519947}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935531764}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expand"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935531857}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609371}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609458}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609517}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609592}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609658}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stretches"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609717}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609773}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609849}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935609933}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" start"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935616279}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" far"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935616352}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935616399}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935616483}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935633166}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extreme"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935645671}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935645759}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" settings"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935661044}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935661106}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935661147}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935661213}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" expected"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935661263}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935676634}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935676685}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935694929}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935695027}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935724638}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935724709}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935724757}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935725932}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" internal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935725996}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935726033}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935743524}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" preserve"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935743575}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935759795}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935759853}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935759911}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935776014}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intentionally"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935776093}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" removed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935791655}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935791719}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aesthetic"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935810049}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935823757}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" A"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935823804}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935823855}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935840720}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935840778}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" list"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935840816}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935856903}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" huge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935856983}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935857046}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935883254}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935883323}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935893203}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935893288}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935908394}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935908468}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935924965}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"24"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935925049}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935942994}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935943065}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935943117}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935943165}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935943211}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" polished"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935957057}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935957138}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935957191}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" requirement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935957242}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935957304}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" catastrophe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935972082}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" intervals"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978935990380}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936004467}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"urable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936004537}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936004596}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" setting"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936021679}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936044008}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936059628}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936059712}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936059757}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" results"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936059822}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936059875}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" many"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936095859}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936095966}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936096093}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Better"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936096174}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936096244}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" keep"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936096425}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936100198}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dashboard"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936100280}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" usable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936100343}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936116963}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936117052}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936117121}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Limit"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936117182}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936135939}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936136027}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936153944}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" display"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936154033}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936154103}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936154169}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" say"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936166306}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936166393}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936166459}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936166529}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936166585}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936166655}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936183593}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936183691}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936198837}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" type"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936213884}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"/gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936231821}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936231900}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936251312}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936251367}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936273172}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936273253}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936287798}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936287877}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936287917}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936301590}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" regardless"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936301667}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936301760}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936321405}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936321482}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936321522}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" summarize"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936347336}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936347407}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936354302}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936354357}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936354419}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936354480}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936354523}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936354567}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936365246}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936365309}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936376502}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936376566}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-led"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936376607}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936376658}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936376703}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936396222}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936396283}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936396333}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936431296}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936431354}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" many"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936441402}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936441459}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936451591}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936451662}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" hide"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936451735}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" some"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936470662}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936563785}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936563843}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936563909}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" accessible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936563952}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936563997}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564064}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564104}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564165}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564217}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564277}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564333}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" an"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564403}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" internal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564688}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936564765}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" better"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936568912}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" than"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936589239}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936614118}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936614179}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"900"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936627105}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936635466}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" tall"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936635523}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936651193}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936651246}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936651294}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936651343}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936651383}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936669070}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936669148}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936669204}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936669261}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936683822}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-led"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936683881}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936683954}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" {"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936684033}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936684102}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936684150}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936703458}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936703516}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"120"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936703567}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936721696}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936721745}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936721822}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936721902}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936721956}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936722043}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" }"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936734280}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936734381}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" again"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936734435}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936750309}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936750407}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936750463}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936763837}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936763905}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936763961}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936764020}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936764097}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936785012}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"51"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936799729}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936799781}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936814064}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936841671}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936841728}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936841789}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936841835}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936845154}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936845204}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936845269}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936845324}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936867176}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936867258}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936867299}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" preserves"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936867337}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936878056}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936893697}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" On"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936893765}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" dark"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936893824}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936909444}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936909562}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"bar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936909603}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" subtle"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936926050}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936926130}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936926187}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936926226}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936926293}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936942487}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" compromise"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936942537}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936942593}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936942650}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936958787}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936958844}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936958910}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"126"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936979300}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936990455}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936990534}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936990583}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978936990616}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937010554}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937010645}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937010730}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937010800}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937024343}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937024402}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fits"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937043958}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937044011}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937044047}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"51"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937059051}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937059098}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937072863}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937072941}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937072992}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937073035}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937073083}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"102"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937087954}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937088017}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937088075}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937088147}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"51"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937105242}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937105300}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937122335}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937122396}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" For"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937122441}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937136173}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937136256}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937136311}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937136366}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937136417}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937153749}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937153822}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937153884}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937169065}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937169140}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'t"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937187049}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" blow"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937187106}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" up"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937187156}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937202396}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937202465}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937202522}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937202587}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937202634}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" had"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937219266}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" previously"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937219345}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937219387}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937233246}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937233316}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"122"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937262987}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937263050}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937263093}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" changed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937267582}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937284819}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" none"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937284905}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937302206}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Re"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937302260}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"int"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937302295}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"roduce"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937316977}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937317035}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937317089}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937317143}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937317171}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937334626}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"128"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937334704}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937355592}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937355669}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937355727}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937368223}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" safer"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937368284}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937394103}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937394164}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937394230}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chips"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937394294}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" list"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937403123}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937417743}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937430521}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937430577}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937450495}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937450578}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937461548}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937461627}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937461685}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937478140}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937478211}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937478253}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937478304}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937478363}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937478411}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937494564}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937494630}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" height"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937515762}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937515844}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" become"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937531712}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fixed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937531769}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937541947}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937558572}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" positions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937576259}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" stable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937590142}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937606394}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937606449}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937606491}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937606553}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Use"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937623878}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937623946}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937624005}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"bar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937642520}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-width"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937642574}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937642653}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" thin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937642719}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937642768}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937642826}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"bar"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937656476}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-color"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937656533}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937656595}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" rgba"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937656641}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"(..."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937672544}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937672597}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" transparent"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937672640}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937690003}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937690055}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937690128}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" This"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937707626}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937707683}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937707722}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937721645}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" polish"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937721757}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937742825}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extremes"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937757296}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937757357}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Do"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937772688}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937772741}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937772783}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937772825}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937772871}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937788818}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937788925}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937806361}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937806453}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" drift"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937826504}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937839031}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937839122}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937839182}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937839279}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937839357}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Ext"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937860912}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"inct"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937860995}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937874606}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937892775}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937912140}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937912245}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937912301}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937927680}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937927745}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937927794}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937954342}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937954416}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" card"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937954570}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937954630}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937954680}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937973452}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937973518}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937973584}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" values"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937985544}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937985616}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lost"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978937985672}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938002098}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938002218}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938002282}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938014959}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938032207}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938032274}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938044526}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938044573}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938044613}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938044647}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938044687}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" trait"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938044723}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938060940}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938076068}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" capt"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938076147}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ions"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938093265}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938093341}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938110870}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" del"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938110920}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"tas"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938110970}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938124835}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938144773}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"—"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938144859}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938144920}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938144981}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938161980}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938173259}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938188838}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938188933}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938188995}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938189076}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938205132}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938205211}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938223869}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" history"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938223961}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938224017}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938253428}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938253499}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938253586}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938265272}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Chart"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938265352}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938272690}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938272767}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" It"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938286590}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938303667}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938303729}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938321481}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938321558}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" available"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938343429}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938343523}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938362188}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938362246}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" valid"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938362329}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938373452}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938373517}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Other"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938373571}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" edge"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938383845}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**:"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938383901}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938383968}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938400082}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938400140}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938400196}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938452128}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938452251}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" might"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938452456}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938475687}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" crowded"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938475742}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938494054}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938494119}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" future"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938510980}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938511062}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938523985}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938524040}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938524094}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938535734}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938545760}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938565051}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938565129}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" During"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938565197}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938565262}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938580542}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938580620}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938580681}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938595021}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938595091}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938595145}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938595206}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" timeline"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938611036}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" future"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938611099}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938631172}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" many"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938631285}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" circles"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938645112}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938664212}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938664284}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938664342}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938664405}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bulletin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938676226}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" queue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938700623}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938700675}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938711832}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" enormous"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938711920}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938711964}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938724773}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938724830}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938750726}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938750830}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938758820}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938758879}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938794719}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938794775}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938794817}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938805954}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938806005}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938806050}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938822769}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938846341}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" type"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938846424}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938863431}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938875208}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938893043}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938906293}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938906347}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938919785}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938919857}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938919907}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938937517}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938937589}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938937632}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938937678}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938958602}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938958671}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938958710}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938958777}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938958834}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bulletin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938958924}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938982720}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938993843}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938993899}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938993934}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978938993979}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939012312}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939012376}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"36"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939012426}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939018261}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939018343}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939018387}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"56"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939035519}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939035581}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":","},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939035624}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" queues"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939035692}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" manageable"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939035748}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939051203}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939051276}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939051326}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-forward"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939066597}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939081054}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bullet"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939081124}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"ins"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939097941}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939097994}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939098050}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939098120}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939098172}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939098212}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939129238}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" wash"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939129314}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" active"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939131961}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939132024}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939145858}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939163548}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939163615}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939163663}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" weather"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939163718}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939177737}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" updates"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939177788}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939194352}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" \n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939194426}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939194479}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Potential"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939194547}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" extreme"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300003}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300283}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300333}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300375}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300477}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300583}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300639}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300816}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300862}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300905}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939300949}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939301059}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"active"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939318591}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Effect"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939333941}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Type"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939334012}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939347704}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" picks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939347790}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939347879}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939348002}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939454505}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" bulletin"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939454557}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" queue"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939454655}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939454749}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939454786}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939454823}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939454862}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" Report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939454964}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939455117}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939455228}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":".\n\n"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939455300}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939455373}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"Report"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939455507}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939475568}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" ledger"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939475653}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939486176}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939502659}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939502719}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":" implement"},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939532194}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939532273}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id":"call_00_2po9qfYr8o0pcJBtI8xe0502","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939551890}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939566547}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939566644}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939566735}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939566797}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939566842}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939583101}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939583172}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" >>"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939583254}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939583317}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/style"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939599995}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939600080}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939600143}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939600212}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"CSS"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939600274}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"'\\n\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939600374}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939622332}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"led"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939622398}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939631553}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939631638}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"anel"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939631701}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939631755}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939631816}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-led"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939631874}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939649613}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939649725}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939649796}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" max"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939649848}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-height"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939649900}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939649957}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939664537}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"126"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939664623}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"px"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939664687}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939664755}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939664820}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" overflow"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939664863}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-y"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939687257}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939687312}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" auto"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939687359}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939687398}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939687439}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" padding"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939687509}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-right"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939697069}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939697157}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939697211}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939697254}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"px"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939716423}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939716508}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939716597}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" scroll"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939716668}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bar"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939716721}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939716764}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939733587}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" thin"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939733700}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939733777}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939733842}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" scroll"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939733924}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bar"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939734021}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-color"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939755166}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939755267}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" rgba"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939755338}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939755406}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"231"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939755479}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939770866}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939770929}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"236"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939771004}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939784118}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939784180}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"219"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939784250}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939784304}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939784384}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939784477}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939797761}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" transparent"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939797873}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939797965}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939798042}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939798112}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"led"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939798159}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939811241}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939811303}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"anel"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939811352}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939811408}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939811487}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-led"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939811557}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939826739}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"::-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939826800}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"webkit"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939826876}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-sc"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939826954}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939827016}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bar"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939827066}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939843933}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" width"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939844008}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939844056}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939844108}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939844192}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"px"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939880467}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939880568}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939880671}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939880732}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"led"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939880767}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939880816}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939880954}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"anel"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939880997}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939881044}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939881088}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-led"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939881172}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"ger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939881227}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"::-"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939904223}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"webkit"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939904290}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-sc"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939904372}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939904431}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"bar"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939904531}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"-th"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939904616}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"umb"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939910426}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939910487}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" background"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939910536}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939910653}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" rgba"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939910743}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939910830}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"231"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939925670}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939925777}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939925867}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"236"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939925937}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939926004}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939926090}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"219"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939942756}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939942845}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ."}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939942915}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939942993}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939943037}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939943105}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"CSS"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939958938}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939958998}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"python"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939959064}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939959111}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939959189}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/build"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939976334}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".py"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939976419}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939976472}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939976536}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939976589}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/ext"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939976626}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"inct"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939996024}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"report"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939996112}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939996179}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939996236}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978939996304}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940011028}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940011139}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940011199}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940011249}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940011317}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940011408}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940021471}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940021532}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940038155}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940038247}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940038322}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940038395}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940058801}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940058865}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940058953}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" event"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940059057}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" ledger"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940073436}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" height"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940073512}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940086008}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" extreme"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940086076}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":" runs"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940086129}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940104308}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","sla_metrics":{"ttft_ms":2288,"ts_us":1792978940104379}}

data: {"id":"5764829dfa78f815b5d62daf7d7c979c","object":"chat.completion.chunk","created":1792978929,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}],"system_fingerprint":"e72d3c7f663d3e1383b00b3884cb4501","usage":{"prompt_tokens":520566,"completion_tokens":1400,"total_tokens":521966,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":519552,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1195,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2288,"ts_us":1792978940141796}}

data: [DONE]

