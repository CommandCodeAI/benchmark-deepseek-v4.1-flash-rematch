data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514718625}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514718695}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test with Playwright. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514718720}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" create script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514769770}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514769933}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514769972}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514770048}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use server?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514862511}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file:// should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514862577}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" work. No network."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514862741}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use playwright package"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976514863465}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" global? `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515014361}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"playwright` CLI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515014433}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" installed; module might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515014581}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not be resolvable locally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515015447}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check `node -"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515109754}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"e require('playwright')"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515109852}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515110115}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_2kmgg3vhb85ty15540kp8pm0","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515110410}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515110517}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515110587}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515110853}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515111263}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515114792}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515115043}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515115113}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515116668}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515126479}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515126602}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515128439}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515130053}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"require"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515130119}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515130239}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515130304}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515130383}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515141545}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515141707}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515141844}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515142650}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ok"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515159429}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515159499}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515159754}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"catch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515159841}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515162146}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515162316}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515162432}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515162479}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515163002}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515163118}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515163525}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515163578}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515170395}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515170474}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"opt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515170579}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515170764}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515187310}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515187379}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rows"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515187481}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ers"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515187577}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515198310}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rom"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515198387}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ium"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515198448}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515198544}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"124"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515198895}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515198978}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515199020}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515200002}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515214479}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inux"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515214568}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515214619}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515214750}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515266179}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515266641}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515266899}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515267054}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515277185}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515277305}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515277368}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515277481}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515278710}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515278759}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515278844}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" module"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515278902}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" availability"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515370763}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515370816}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3075,"ts_us":1792976515370857}}

data: {"id":"2923ad7f8c551dc57e36efe1f5e38892","object":"chat.completion.chunk","created":1792976514,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":286265,"completion_tokens":158,"total_tokens":286423,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":281984,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":55,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3075,"ts_us":1792976515370953}}

data: [DONE]

